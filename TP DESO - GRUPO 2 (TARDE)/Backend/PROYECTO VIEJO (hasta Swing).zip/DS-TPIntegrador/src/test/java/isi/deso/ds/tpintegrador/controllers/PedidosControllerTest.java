package isi.deso.ds.tpintegrador.controllers;

import java.util.List;
import java.util.Arrays;
import org.mockito.Mock;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

import isi.deso.ds.tpintegrador.models.Pedido;
import isi.deso.ds.tpintegrador.models.Cliente;
import isi.deso.ds.tpintegrador.models.Coordenada;
import isi.deso.ds.tpintegrador.repository.PedidoDAO;

// ----- TESTING DE CONTROLADOR DE PEDIDOS -----

public class PedidosControllerTest {

    private PedidosController pedidosController;

    @Mock
    private PedidoDAO pedidoDAO;

    @BeforeEach
    public void setUp() {
        // Configuramos los mocks: inicializamos el mock de PedidoDAO y el controller antes de cada prueba.
        pedidoDAO = mock(PedidoDAO.class);
        pedidosController = new PedidosController(pedidoDAO);
    }

    // DESCRIPCIÓN DE TEST: verifica que la lista de pedidos obtenida del pedidoDAO no sea nula y coincida con los datos esperados. También valida que el metodo listarPedidos() del pedidoDAO se invoque una sola vez.
    @Test
    public void testMostrarListaPedidos() {
        // Creamos instancias de prueba (una lista de pedidos esperados para simular la respuesta del DAO):
        List<Pedido> pedidosEsperados = Arrays.asList(
                new Pedido("P001", new Cliente("C001", "Juan Perez", "20234567891", "juan@ejemplo.com", "Calle Falsa 123", new Coordenada(-34.603722, -58.381592))),
                new Pedido("P002", new Cliente("C002", "Maria Gomez", "20123456782", "maria@ejemplo.com", "Av. Siempre Viva 742", new Coordenada(-34.6083, -58.3712)))
        );

        // Cuando se llame a listarPedidos en el mock, devolveremos la lista de pedidos esperados:
        when(pedidoDAO.listarPedidos()).thenReturn(pedidosEsperados);

        // Ejecutamos el metodo de control que queremos probar:
        List<Pedido> resultado = pedidosController.mostrarListaPedidos();

        // Validaciones: verificamos que la lista no sea nula y que el resultado coincida con los pedidos esperados:
        assertNotNull(resultado, "La lista de pedidos no debería ser nula");
        assertEquals(pedidosEsperados, resultado, "La lista de pedidos debería coincidir con la esperada");

        // Verificamos que el metodo listarPedidos fue invocado exactamente una vez:
        verify(pedidoDAO, times(1)).listarPedidos();
    }

    // DESCRIPCIÓN DE TEST: verifica que la creación de un nuevo pedido sea exitosa y que el metodo crearPedido se invoque correctamente en el pedidoDAO.
    @Test
    public void testCrearPedido() {
        // Creamos instancia de prueba (un pedido para ser creado):
        Pedido nuevoPedido = new Pedido("P008", new Cliente("C008", "Lucia Herrera", "20890123458", "lucia@ejemplo.com", "Av. Corrientes 900", new Coordenada(-34.6350, -58.3850)));

        // Configuramos el mock para que devuelva true al intentar crear el pedido:
        when(pedidoDAO.crearPedido(nuevoPedido)).thenReturn(true);

        // Ejecutamos el metodo de control:
        boolean resultado = pedidosController.crearNuevoPedido(nuevoPedido);

        // Validaciones: verificamos que el resultado sea true, indicando que el pedido se creó exitosamente.
        assertTrue(resultado, "El pedido debería crearse correctamente");

        // Verificamos que el metodo crearPedido fue invocado una vez:
        verify(pedidoDAO, times(1)).crearPedido(nuevoPedido);
    }

    // DESCRIPCIÓN DE TEST: verifica que el pedido sea eliminado correctamente y que el metodo eliminarPedido del pedidoDAO sea llamado una sola vez.
    @Test
    public void testEliminarPedido() {
        // Creamos un ID de pedido para simular su eliminación:
        String idPedido = "1";

        // Configuramos el mock para que devuelva true al intentar eliminar el pedido:
        when(pedidoDAO.eliminarPedido(idPedido)).thenReturn(true);

        // Ejecutamos el metodo de control:
        boolean resultado = pedidosController.eliminarPedido(idPedido);

        // Validaciones: verificamos que el pedido se eliminó correctamente:
        assertTrue(resultado, "El pedido debería eliminarse correctamente");

        // Verificamos que el metodo eliminarPedido fue invocado una vez:
        verify(pedidoDAO, times(1)).eliminarPedido(idPedido);
    }

    // DESCRIPCIÓN DE TEST: asegura que un pedido puede ser encontrado correctamente por su ID y que el metodo buscarPedido sea invocado una vez.
    @Test
    public void testBuscarPedido() {
        // Creamos un ID de pedido y el vendedor esperado:
        String idPedido = "1";
        Pedido pedidoEsperado = new Pedido("P001", new Cliente("C001", "Juan Perez", "20234567891", "juan@ejemplo.com", "Calle Falsa 123", new Coordenada(-34.603722, -58.381592)));

        // Configuramos el mock para que devuelva el pedido esperado al buscarlo por ID:
        when(pedidoDAO.buscarPedido(idPedido)).thenReturn(pedidoEsperado);

        // Ejecutamos el metodo de control:
        Pedido resultado = pedidosController.buscarPedido(idPedido);

        // Validaciones: verificamos que el pedido encontrado no sea nulo y coincida con el esperado:
        assertNotNull(resultado, "El pedido debería encontrarse");
        assertEquals(pedidoEsperado, resultado, "El pedido encontrado debería coincidir con el esperado");

        // Verificamos que el metodo buscarPedido fue invocado una vez:
        verify(pedidoDAO, times(1)).buscarPedido(idPedido);
    }

}