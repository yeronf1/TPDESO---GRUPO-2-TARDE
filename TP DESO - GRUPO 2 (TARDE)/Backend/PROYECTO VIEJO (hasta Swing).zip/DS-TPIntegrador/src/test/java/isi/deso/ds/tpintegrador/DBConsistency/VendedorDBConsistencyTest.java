package isi.deso.ds.tpintegrador.DBConsistency;

import java.sql.*;
import java.util.Set;
import java.util.HashSet;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import isi.deso.ds.tpintegrador.config.ConexionDB;

// ----- TESTING DE CONSISTENCIA DE BASE DE DATOS -----

public class VendedorDBConsistencyTest {

    // DESCRIPCIÓN DE TEST: detecta posibles problemas de consistencia en la base de datos de VENDEDORES, como vendedores con el mismo nombre.
    @Test
    public void testNoDuplicadosNombre() throws SQLException {

        // Establecemos conexión con la base de datos REAL:
        try (Connection conn = ConexionDB.conectar()) {

            // Consulta SQL para obtener todos los nombres:
            String query = "SELECT nombre FROM vendedor";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {

                // Usamos un set para almacenar los nombres y verificar duplicados:
                Set<String> nombreSet = new HashSet<>();

                // Iteramos sobre los resultados:
                while (rs.next()) {
                    String nombre = rs.getString("nombre");

                    // Si el nombre ya está en el set, significa que es un duplicado:
                    if (!nombreSet.add(nombre)) {
                        fail("Se encontraron nombres duplicados en la base de datos: " + nombre);
                    }
                }
                // Si no encontramos duplicados, el test pasa.
            }
        }
    }

}


