package isi.deso.ds.tpintegrador.controllers;

import java.util.List;
import java.util.Arrays;
import org.mockito.Mock;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import isi.deso.ds.tpintegrador.models.Cliente;
import isi.deso.ds.tpintegrador.models.Coordenada;
import isi.deso.ds.tpintegrador.repository.ClienteDAO;

// ----- TESTING DE CONTROLADOR DE CLIENTES -----

public class ClienteControllerTest {

    private ClienteController clienteController;

    @Mock
    private ClienteDAO clienteDAO;

    @BeforeEach
    public void setUp() {
        // Configuramos los mocks: inicializamos el mock de clienteDAO y el controller antes de cada prueba.
        clienteDAO = mock(ClienteDAO.class);
        clienteController = new ClienteController(clienteDAO);
    }

    // DESCRIPCIÓN DE TEST: verifica que la lista de clientes obtenida del clienteDAO no sea nula y coincida con los datos esperados. También valida que el metodo listarCliente del clienteDAO se invoque una sola vez.
    @Test
    public void testMostrarListaClientes() {
        // Creamos instancias de prueba (una lista de clientes esperados para simular la respuesta del DAO):
        List<Cliente> clientesEsperados = Arrays.asList(
                new Cliente("1", "Juan Perez", "20234567891", "juan@ejemplo.com", "Calle Falsa 123", new Coordenada(-34.603722, -58.381592)),
                new Cliente("2", "Ana Gomez", "20345678912", "ana@ejemplo.com", "Avenida Siempreviva 456", new Coordenada(-34.603823, -58.382345))
        );

        // Cuando se llame a listarCliente en el mock, devolveremos la lista de clientes esperados:
        when(clienteDAO.listarCliente()).thenReturn(clientesEsperados);

        // Ejecutamos el metodo de control que queremos probar:
        List<Cliente> resultado = clienteController.mostrarListaClientes();

        // Validaciones: verificamos que la lista no sea nula y que el resultado coincida con los clientes esperados:
        assertNotNull(resultado, "La lista de clientes no debería ser nula");
        assertEquals(clientesEsperados, resultado, "La lista de clientes debería coincidir con la esperada");

        // Verificamos que el metodo listarCliente fue invocado exactamente una vez:
        verify(clienteDAO, times(1)).listarCliente();
    }

    // DESCRIPCIÓN DE TEST: verifica que la creación de un nuevo cliente sea exitosa y que el metodo crearCliente se invoque correctamente en el clienteDAO.
    @Test
    public void testCrearCliente() {
        // Creamos instancia de prueba (un cliente para ser creado):
        Cliente nuevoCliente = new Cliente("0", "Carlos Ruiz", "20456789123", "carlos@ejemplo.com", "Calle Verde 789", new Coordenada(-34.604122, -58.383112));

        // Configuramos el mock para que devuelva true al intentar crear el cliente:
        when(clienteDAO.crearCliente(nuevoCliente)).thenReturn(true);

        // Ejecutamos el metodo de control:
        boolean resultado = clienteController.crearCliente(nuevoCliente);

        // Validaciones: verificamos que el resultado sea true, indicando que el cliente se creó exitosamente.
        assertTrue(resultado, "El cliente debería crearse correctamente");

        // Verificamos que el metodo crearCliente fue invocado una vez:
        verify(clienteDAO, times(1)).crearCliente(nuevoCliente);
    }

    // DESCRIPCIÓN DE TEST: asegura que al actualizar un cliente, el metodo actualizarCliente sea invocado correctamente y la actualización sea exitosa.
    @Test
    public void testActualizarCliente() {
        // Creamos un cliente actualizado para simular la actualización:
        Cliente clienteActualizado = new Cliente("1", "Juan Carlos Perez", "20234567891", "juan.carlos@ejemplo.com", "Calle Verdadera 456", new Coordenada(-34.604722, -58.382592));

        // Configuramos el mock para que devuelva true al intentar actualizar el cliente:
        when(clienteDAO.actualizarCliente(clienteActualizado)).thenReturn(true);

        // Ejecutamos el metodo de control:
        boolean resultado = clienteController.actualizarCliente(clienteActualizado);

        // Validaciones: verificamos que la actualización se realizó correctamente:
        assertTrue(resultado, "El cliente debería actualizarse correctamente");

        // Verificamos que el metodo actualizarCliente fue invocado una vez:
        verify(clienteDAO, times(1)).actualizarCliente(clienteActualizado);
    }

    // DESCRIPCIÓN DE TEST: verifica que el cliente sea eliminado correctamente y que el metodo eliminarCliente del clienteDAO sea llamado una sola vez.
    @Test
    public void testEliminarCliente() {
        // Creamos un ID de cliente para simular su eliminación:
        String idCliente = "1";

        // Configuramos el mock para que devuelva true al intentar eliminar el cliente:
        when(clienteDAO.eliminarCliente(idCliente)).thenReturn(true);

        // Ejecutamos el metodo de control:
        boolean resultado = clienteController.eliminarCliente(idCliente);

        // Validaciones: verificamos que el cliente se eliminó correctamente:
        assertTrue(resultado, "El cliente debería eliminarse correctamente");

        // Verificamos que el metodo eliminarCliente fue invocado una vez:
        verify(clienteDAO, times(1)).eliminarCliente(idCliente);
    }

    // DESCRIPCIÓN DE TEST: asegura que un cliente puede ser encontrado correctamente por su ID y que el metodo buscarCliente sea invocado una vez.
    @Test
    public void testBuscarCliente() {
        // Creamos un ID de cliente y el cliente esperado:
        String idCliente = "1";
        Cliente clienteEsperado = new Cliente("1", "Juan Perez", "20234567891", "juan@ejemplo.com", "Calle Falsa 123", new Coordenada(-34.603722, -58.381592));

        // Configuramos el mock para que devuelva el cliente esperado al buscarlo por ID:
        when(clienteDAO.buscarCliente(idCliente)).thenReturn(clienteEsperado);

        // Ejecutamos el metodo de control:
        Cliente resultado = clienteController.buscarCliente(idCliente);

        // Validaciones: verificamos que el cliente encontrado no sea nulo y coincida con el esperado:
        assertNotNull(resultado, "El cliente debería encontrarse");
        assertEquals(clienteEsperado, resultado, "El cliente encontrado debería coincidir con el esperado");

        // Verificamos que el metodo buscarCliente fue invocado una vez:
        verify(clienteDAO, times(1)).buscarCliente(idCliente);
    }

    // DESCRIPCIÓN DE TEST: verifica que la búsqueda de un cliente por un parámetro específico (como el nombre) funcione correctamente.
    @Test
    public void testBuscarClientePorParametro() {
        // Definimos un parámetro de búsqueda (por ejemplo, "nombre") y su valor esperado:
        String parametro = "nombre";
        String valor = "Juan Perez";
        List<Cliente> clientesEsperados = List.of(
                new Cliente("1", "Juan Perez", "20234567891", "juan@ejemplo.com", "Calle Falsa 123", new Coordenada(-34.603722, -58.381592))
        );

        // Configuramos el mock para que devuelva la lista de clientes que coinciden con el parámetro:
        when(clienteDAO.buscarClientePorParametro(parametro, valor)).thenReturn(clientesEsperados);

        // Ejecutamos el metodo de control:
        List<Cliente> resultado = clienteController.buscarClientePorParametro(parametro, valor);

        // Validaciones: verificamos que la lista de clientes no sea nula y contenga elementos esperados:
        assertNotNull(resultado, "La lista de clientes no debería ser nula");
        assertFalse(resultado.isEmpty(), "La lista de clientes debería contener elementos");
        assertEquals(clientesEsperados, resultado, "La lista de clientes debería coincidir con la esperada");

        // Verificamos que el metodo buscarClientePorParametro fue invocado una vez:
        verify(clienteDAO, times(1)).buscarClientePorParametro(parametro, valor);
    }

}