package isi.deso.ds.tpintegrador.controllers;

import java.util.List;
import java.util.Arrays;
import org.mockito.Mock;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

import isi.deso.ds.tpintegrador.models.Vendedor;
import isi.deso.ds.tpintegrador.models.Coordenada;
import isi.deso.ds.tpintegrador.repository.VendedoresDAO;

// ----- TESTING DE CONTROLADOR DE VENDEDORES -----

public class VendedoresControllerTest {

    private VendedoresController vendedoresController;

    @Mock
    private VendedoresDAO vendedoresDAO;

    @BeforeEach
    public void setUp() {
        // Configuramos los mocks: inicializamos el mock de VendedoresDAO y el controller antes de cada prueba.
        vendedoresDAO = mock(VendedoresDAO.class);
        vendedoresController = new VendedoresController(vendedoresDAO);
    }

    // DESCRIPCIÓN DE TEST: verifica que la lista de vendedores obtenida del vendedoresDAO no sea nula y coincida con los datos esperados. También valida que el metodo listarVendedores() del vendedoresDAO se invoque una sola vez.
    @Test
    public void testMostrarListaVendedores() {
        // Creamos instancias de prueba (una lista de vendedores esperados para simular la respuesta del DAO):
        List<Vendedor> vendedoresEsperados = Arrays.asList(
                new Vendedor("V001", "La Dominga", "Javier de la Rosa 101", new Coordenada(-34.603722, -58.381592)),
                new Vendedor("V002", "El Nacional", "Ituzaingó 1090", new Coordenada(-34.6100, -58.3700))
        );

        // Cuando se llame a listarVendedores en el mock, devolveremos la lista de vendedores esperados:
        when(vendedoresDAO.listarVendedores()).thenReturn(vendedoresEsperados);

        // Ejecutamos el metodo de control que queremos probar:
        List<Vendedor> resultado = vendedoresController.mostrarListaVendedores();

        // Validaciones: verificamos que la lista no sea nula y que el resultado coincida con los vendedores esperados:
        assertNotNull(resultado, "La lista de vendedores no debería ser nula");
        assertEquals(vendedoresEsperados, resultado, "La lista de vendedores debería coincidir con la esperada");

        // Verificamos que el metodo listarVendedores fue invocado exactamente una vez:
        verify(vendedoresDAO, times(1)).listarVendedores();
    }

    // DESCRIPCIÓN DE TEST: verifica que la creación de un nuevo vendedor sea exitosa y que el metodo crearVendedor se invoque correctamente en el vendedoresDAO.
    @Test
    public void testCrearVendedor() {
        // Creamos instancia de prueba (un vendedor para ser creado):
        Vendedor nuevoVendedor = new Vendedor("V008", "La Terraza", "Belgrano 2001", new Coordenada(-34.6400, -58.3100));

        // Configuramos el mock para que devuelva true al intentar crear el vendedor:
        when(vendedoresDAO.crearVendedor(nuevoVendedor)).thenReturn(true);

        // Ejecutamos el metodo de control:
        boolean resultado = vendedoresController.crearNuevoVendedor(nuevoVendedor);

        // Validaciones: verificamos que el resultado sea true, indicando que el vendedor se creó exitosamente.
        assertTrue(resultado, "El vendedor debería crearse correctamente");

        // Verificamos que el metodo crearVendedor fue invocado una vez:
        verify(vendedoresDAO, times(1)).crearVendedor(nuevoVendedor);
    }

    // DESCRIPCIÓN DE TEST: asegura que al actualizar un vendedor, el metodo actualizarVendedor sea invocado correctamente y la actualización sea exitosa.
    @Test
    public void testActualizarVendedor() {
        // Creamos un vendedor actualizado para simular la actualización:
        Vendedor vendedorActualizado = new Vendedor("V008", "La Terraza Salvaje", "San Martín 2002", new Coordenada(-31.6400, -88.3100));

        // Configuramos el mock para que devuelva true al intentar actualizar el vendedor:
        when(vendedoresDAO.actualizarVendedor(vendedorActualizado)).thenReturn(true);

        // Ejecutamos el metodo de control:
        boolean resultado = vendedoresController.modificarVendedor(vendedorActualizado);

        // Validaciones: verificamos que la actualización se realizó correctamente:
        assertTrue(resultado, "El vendedor debería actualizarse correctamente");

        // Verificamos que el metodo actualizarVendedor fue invocado una vez:
        verify(vendedoresDAO, times(1)).actualizarVendedor(vendedorActualizado);
    }

    // DESCRIPCIÓN DE TEST: verifica que el vendedor sea eliminado correctamente y que el metodo eliminarVendedor del vendedoresDAO sea llamado una sola vez.
    @Test
    public void testEliminarVendedor() {
        // Creamos un ID de vendedor para simular su eliminación:
        String idVendedor = "1";

        // Configuramos el mock para que devuelva true al intentar eliminar el vendedor:
        when(vendedoresDAO.eliminarVendedor(idVendedor)).thenReturn(true);

        // Ejecutamos el metodo de control:
        boolean resultado = vendedoresController.eliminarVendedor(idVendedor);

        // Validaciones: verificamos que el vendedor se eliminó correctamente:
        assertTrue(resultado, "El vendedor debería eliminarse correctamente");

        // Verificamos que el metodo eliminarVendedor fue invocado una vez:
        verify(vendedoresDAO, times(1)).eliminarVendedor(idVendedor);
    }

    // DESCRIPCIÓN DE TEST: asegura que un vendedor puede ser encontrado correctamente por su ID y que el metodo buscarVendedor sea invocado una vez.
    @Test
    public void testBuscarVendedor() {
        // Creamos un ID de vendedor y el vendedor esperado:
        String idVendedor = "1";
        Vendedor vendedorEsperado = new Vendedor("V001", "La Dominga", "Javier de la Rosa 101", new Coordenada(-34.603722, -58.381592));

        // Configuramos el mock para que devuelva el vendedor esperado al buscarlo por ID:
        when(vendedoresDAO.buscarVendedor(idVendedor)).thenReturn(vendedorEsperado);

        // Ejecutamos el metodo de control:
        Vendedor resultado = vendedoresController.buscarVendedor(idVendedor);

        // Validaciones: verificamos que el vendedor encontrado no sea nulo y coincida con el esperado:
        assertNotNull(resultado, "El vendedor debería encontrarse");
        assertEquals(vendedorEsperado, resultado, "El vendedor encontrado debería coincidir con el esperado");

        // Verificamos que el metodo buscarVendedor fue invocado una vez:
        verify(vendedoresDAO, times(1)).buscarVendedor(idVendedor);
    }

    // DESCRIPCIÓN DE TEST: verifica que la búsqueda de un vendedor por un parámetro específico (como el nombre) funcione correctamente.
    @Test
    public void testBuscarVendedorPorParametro() {
        // Definimos un parámetro de búsqueda (por ejemplo, "nombre") y su valor esperado:
        String parametro = "nombre";
        String valor = "La Dominga";
        List<Vendedor> vendedoresEsperados = List.of(
                new Vendedor("V001", "La Dominga", "Javier de la Rosa 101", new Coordenada(-34.603722, -58.381592))
        );

        // Configuramos el mock para que devuelva la lista de vendedores que coinciden con el parámetro:
        when(vendedoresDAO.buscarVendedorPorParametro(parametro, valor)).thenReturn(vendedoresEsperados);

        // Ejecutamos el metodo de control:
        List<Vendedor> resultado = vendedoresController.buscarVendedorPorParametro(parametro, valor);

        // Validaciones: verificamos que la lista de vendedores no sea nula y contenga elementos esperados:
        assertNotNull(resultado, "La lista de vendedores no debería ser nula");
        assertFalse(resultado.isEmpty(), "La lista de vendedores debería contener elementos");
        assertEquals(vendedoresEsperados, resultado, "La lista de vendedores debería coincidir con la esperada");

        // Verificamos que el metodo buscarVendedorPorParametro fue invocado una vez:
        verify(vendedoresDAO, times(1)).buscarVendedorPorParametro(parametro, valor);
    }

}