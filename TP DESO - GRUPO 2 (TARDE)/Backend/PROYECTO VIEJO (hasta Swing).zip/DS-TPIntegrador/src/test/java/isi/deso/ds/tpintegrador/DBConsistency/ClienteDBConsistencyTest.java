package isi.deso.ds.tpintegrador.DBConsistency;

import java.sql.*;
import java.util.Set;
import java.util.HashSet;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import isi.deso.ds.tpintegrador.config.ConexionDB;

// ----- TESTING DE CONSISTENCIA DE BASE DE DATOS -----

public class ClienteDBConsistencyTest {

    // DESCRIPCIÓN DE TEST: detecta posibles problemas de consistencia en la base de datos de CLIENTES, como clientes con el mismo CUIT.
    @Test
    public void testNoDuplicadosCuit() throws SQLException {

        // Establecemos conexión con la base de datos REAL:
        try (Connection conn = ConexionDB.conectar()) {

            // Consulta SQL para obtener todos los CUITs:
            String query = "SELECT cuit FROM cliente";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {

                // Usamos un set para almacenar los CUITs y verificar duplicados:
                Set<String> cuitSet = new HashSet<>();

                // Iteramos sobre los resultados:
                while (rs.next()) {
                    String cuit = rs.getString("cuit");

                    // Si el CUIT ya está en el set, significa que es un duplicado:
                    if (!cuitSet.add(cuit)) {
                        fail("Se encontraron CUIT duplicados en la base de datos: " + cuit);
                    }
                }
                // Si no encontramos duplicados, el test pasa.
            }
        }
    }

}


