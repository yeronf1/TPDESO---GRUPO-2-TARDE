package isi.deso.ds.tpintegrador.controllers;

import java.util.List;
import java.util.Arrays;
import org.mockito.Mock;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

import isi.deso.ds.tpintegrador.models.*;
import isi.deso.ds.tpintegrador.repository.ItemsMenuDAO;

// ----- TESTING DE CONTROLADOR DE ÍTEMS MENÚ -----

public class ItemsMenuControllerTest {

    private ItemsMenuController itemsMenuController;

    @Mock
    private ItemsMenuDAO itemsMenuDAO;

    @BeforeEach
    public void setUp() {
        // Configuramos los mocks: inicializamos el mock de ItemsMenuDAO y el controller antes de cada prueba.
        itemsMenuDAO = mock(ItemsMenuDAO.class);
        itemsMenuController = new ItemsMenuController(itemsMenuDAO);
    }

    // DESCRIPCIÓN DE TEST: verifica que la lista de ItemsMenu obtenida del itemsMenuDAO no sea nula y coincida con los datos esperados. También valida que el metodo listarItemsMenu() del itemsMenuDAO se invoque una sola vez.
    @Test
    public void testMostrarListaItemsMenu() {
        // Creamos instancias de prueba (una lista de ItemsMenu esperados para simular la respuesta del DAO):
        List<ItemMenu> itemsMenuEsperados = Arrays.asList(
                new Bebida("IMB001", "Agua Mineral", "Descripción", 1200, 0.0, false, 500),
                new Plato("IMC001", "Pizza Napolitana", "Descripción", 10500, 2000, 1899, false, true)
        );

        // Cuando se llame a listarVendedores en el mock, devolveremos la lista de vendedores esperados:
        when(itemsMenuDAO.listarItemsMenu()).thenReturn(itemsMenuEsperados);

        // Ejecutamos el metodo de control que queremos probar:
        List<ItemMenu> resultado = itemsMenuController.mostrarListaItemsMenu();

        // Validaciones: verificamos que la lista no sea nula y que el resultado coincida con los ItemsMenu esperados:
        assertNotNull(resultado, "La lista de ItemsMenu no debería ser nula");
        assertEquals(itemsMenuEsperados, resultado, "La lista de ItemsMenu debería coincidir con la esperada");

        // Verificamos que el metodo listarItemsMenu fue invocado exactamente una vez:
        verify(itemsMenuDAO, times(1)).listarItemsMenu();
    }

    // DESCRIPCIÓN DE TEST: verifica que la creación de un nuevo ItemsMenu sea exitosa y que el metodo crearItemsMenu se invoque correctamente en el itemsMenuDAO.
    @Test
    public void testCrearItemsMenu() {
        // Creamos instancia de prueba (un ItemMenu para ser creado):
        ItemMenu nuevoItemMenu = new Bebida("IMB002", "Jugo de Pomelo", "Descripción", 1800, 0.0, true, 610);

        // Configuramos el mock para que devuelva true al intentar crear el ItemMenu:
        when(itemsMenuDAO.crearItemsMenu(nuevoItemMenu)).thenReturn(true);

        // Ejecutamos el metodo de control:
        boolean resultado = itemsMenuController.crearNuevoItemsMenu(nuevoItemMenu);

        // Validaciones: verificamos que el resultado sea true, indicando que el ItemMenu se creó exitosamente.
        assertTrue(resultado, "El ItemMenu debería crearse correctamente");

        // Verificamos que el metodo crearItemsMenu fue invocado una vez:
        verify(itemsMenuDAO, times(1)).crearItemsMenu(nuevoItemMenu);
    }

    // DESCRIPCIÓN DE TEST: asegura que al actualizar un ItemMenu, el metodo actualizarItemsMenu sea invocado correctamente y la actualización sea exitosa.
    @Test
    public void testActualizarItemMenu() {
        // Creamos un ItemMenu actualizado para simular la actualización:
        ItemMenu itemMenuActualizado = new Plato("IMC001", "Pizza Cebollada", "Descripción", 12500, 2200, 2099, false, true);

        // Configuramos el mock para que devuelva true al intentar actualizar el ItemMenu:
        when(itemsMenuDAO.actualizarItemsMenu(itemMenuActualizado)).thenReturn(true);

        // Ejecutamos el metodo de control:
        boolean resultado = itemsMenuController.actualizarItemMenu(itemMenuActualizado);

        // Validaciones: verificamos que la actualización se realizó correctamente:
        assertTrue(resultado, "El ItemMenu debería actualizarse correctamente");

        // Verificamos que el metodo actualizarItemsMenu fue invocado una vez:
        verify(itemsMenuDAO, times(1)).actualizarItemsMenu(itemMenuActualizado);
    }

    // DESCRIPCIÓN DE TEST: verifica que el ItemMenu sea eliminado correctamente y que el metodo eliminarItemsMenu del itemsMenuDAO sea llamado una sola vez.
    @Test
    public void testEliminarItemMenu() {
        // Creamos un ID de ItemMenu para simular su eliminación:
        String idItemMenu = "1";

        // Configuramos el mock para que devuelva true al intentar eliminar el ItemMenu:
        when(itemsMenuDAO.eliminarItemsMenu(idItemMenu)).thenReturn(true);

        // Ejecutamos el metodo de control:
        boolean resultado = itemsMenuController.eliminarItemsMenu(idItemMenu);

        // Validaciones: verificamos que el ItemMenu se eliminó correctamente:
        assertTrue(resultado, "El ItemMenu debería eliminarse correctamente");

        // Verificamos que el metodo eliminarVendedor fue invocado una vez:
        verify(itemsMenuDAO, times(1)).eliminarItemsMenu(idItemMenu);
    }

    // DESCRIPCIÓN DE TEST: asegura que un ItemMenu puede ser encontrado correctamente por su ID y que el metodo buscarItemsMenu sea invocado una vez.
    @Test
    public void testBuscarItemMenu() {
        // Creamos un ID de ItemMenu y el vendedor esperado:
        String idItemMenu = "1";
        ItemMenu itemMenuEsperado = new Bebida("IMB002", "Jugo de Pomelo", "Descripción", 1800, 0.0, true, 610);

        // Configuramos el mock para que devuelva el vendedor esperado al buscarlo por ID:
        when(itemsMenuDAO.buscarItemsMenu(idItemMenu)).thenReturn(itemMenuEsperado);

        // Ejecutamos el metodo de control:
        ItemMenu resultado = itemsMenuController.buscarItemsMenu(idItemMenu);

        // Validaciones: verificamos que el ItemMenu encontrado no sea nulo y coincida con el esperado:
        assertNotNull(resultado, "El ItemMenu debería encontrarse");
        assertEquals(itemMenuEsperado, resultado, "El ItemMenu encontrado debería coincidir con el esperado");

        // Verificamos que el metodo buscarItemsMenu fue invocado una vez:
        verify(itemsMenuDAO, times(1)).buscarItemsMenu(idItemMenu);
    }

    // DESCRIPCIÓN DE TEST: verifica que la búsqueda de un ItemMenu por un parámetro específico (como el nombre) funcione correctamente.
    @Test
    public void testBuscarItemMenuPorParametro() {
        // Definimos un parámetro de búsqueda (por ejemplo, "categoria") y su valor esperado:
        String parametro = "categoria";
        String valor = "COMIDA";
        List<ItemMenu> itemsMenuEsperados = List.of(
                new Plato("IMC005", "Helado de Dulce de Leche", "Descripción", 5700, 1000, 2400, false, true),
                new Plato("IMC006", "Lasaña de Espinaca", "Descripción", 8500, 800, 950, false, true),
                new Plato("IMC007", "Bife de Chorizo con Papas", "Descripción", 18500, 1500, 1200, true, false)
        );

        // Configuramos el mock para que devuelva la lista de ItemMenu que coinciden con el parámetro:
        when(itemsMenuDAO.buscarItemMenuporParametro(parametro, valor)).thenReturn(itemsMenuEsperados);

        // Ejecutamos el metodo de control:
        List<ItemMenu> resultado = itemsMenuController.buscarItemMenuporParametro(parametro, valor);

        // Validaciones: verificamos que la lista de ItemMenu no sea nula y contenga elementos esperados:
        assertNotNull(resultado, "La lista de ItemMenu no debería ser nula");
        assertFalse(resultado.isEmpty(), "La lista de ItemMenu debería contener elementos");
        assertEquals(itemsMenuEsperados, resultado, "La lista de ItemMenu debería coincidir con la esperada");

        // Verificamos que el metodo buscarItemMenuporParametro fue invocado una vez:
        verify(itemsMenuDAO, times(1)).buscarItemMenuporParametro(parametro, valor);
    }

}