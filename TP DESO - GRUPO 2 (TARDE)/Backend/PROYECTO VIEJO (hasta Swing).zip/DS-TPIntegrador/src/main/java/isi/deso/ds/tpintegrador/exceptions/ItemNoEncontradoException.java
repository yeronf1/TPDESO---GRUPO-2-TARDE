package isi.deso.ds.tpintegrador.exceptions;

public class ItemNoEncontradoException extends Exception {

    public ItemNoEncontradoException(String mensaje) {
        super(mensaje);
    }

}