package isi.deso.ds.tpintegrador.UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuLateral {

    public static JPanel crearMenuLateral(JFrame frameActual) {
        // Crear un panel vertical con espacio entre botones
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(230, 230, 250)); // Color de fondo suave (Lavender)
        panel.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.GRAY)); // Borde lateral derecho

        // Añadir un título o etiqueta al panel
        JLabel titulo = new JLabel("Menú");
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        titulo.setFont(new Font("Arial", Font.BOLD, 16));
        titulo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(titulo);

        // Espacio entre el título y los botones
        panel.add(Box.createVerticalStrut(15));

        // Crear y agregar botones al panel con un estilo uniforme
        agregarBotonAlMenu(panel, "Cliente", frameActual, ClienteUI.class);
        agregarBotonAlMenu(panel, "Vendedor", frameActual, VendedorUI.class);
        agregarBotonAlMenu(panel, "Items", frameActual, ItemsMenuUI.class);
        agregarBotonAlMenu(panel, "Pedido", frameActual, PedidoUI.class);

        return panel;
    }

    private static void agregarBotonAlMenu(JPanel panel, String texto, JFrame frameActual, Class<?> claseDestino) {
        JButton boton = new JButton(texto);
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);
        boton.setMaximumSize(new Dimension(120, 30)); // Tamaño máximo para uniformidad
        boton.setBackground(new Color(173, 216, 230)); // Color azul claro
        boton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.GRAY, 1),
                BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        boton.setFocusPainted(false);

        boton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frameActual.dispose(); // Cierra la ventana actual
                try {
                    // Invoca el metodo main de la clase correspondiente:
                    claseDestino.getMethod("main", String[].class).invoke(null, (Object) null);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        panel.add(boton);
        panel.add(Box.createVerticalStrut(10)); // Espacio entre botones
    }
}
