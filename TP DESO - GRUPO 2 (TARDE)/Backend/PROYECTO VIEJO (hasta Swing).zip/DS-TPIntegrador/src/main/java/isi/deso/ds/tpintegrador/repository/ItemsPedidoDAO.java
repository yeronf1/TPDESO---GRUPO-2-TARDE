package isi.deso.ds.tpintegrador.repository;

import java.util.ArrayList;

import isi.deso.ds.tpintegrador.models.ItemMenu;
import isi.deso.ds.tpintegrador.models.ItemPedido;
import isi.deso.ds.tpintegrador.exceptions.ItemNoEncontradoException;

public interface ItemsPedidoDAO {

    ArrayList<ItemPedido> listarItemsPedidos();
    ArrayList<ItemMenu> filtrar(String filtroCategoria) throws ItemNoEncontradoException;
    ArrayList<ItemMenu> ordenarPorNombreAscendente () throws ItemNoEncontradoException;
    ArrayList<ItemMenu> ordenarPorNombreDescendente () throws ItemNoEncontradoException;
    ArrayList<ItemMenu> ordenarPorprecioAscendente () throws ItemNoEncontradoException;
    ArrayList<ItemMenu> ordenarPorprecioDescendente () throws ItemNoEncontradoException;
    ArrayList<ItemMenu> buscarPorRangoPrecio(double precioInferior,double precioSuperior) throws ItemNoEncontradoException;
    ArrayList<ItemMenu> buscarPorRestaurante(String IDvendedor) throws ItemNoEncontradoException;

}
