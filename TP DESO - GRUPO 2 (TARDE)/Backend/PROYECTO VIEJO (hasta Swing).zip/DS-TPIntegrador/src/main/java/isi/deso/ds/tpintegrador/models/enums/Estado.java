package isi.deso.ds.tpintegrador.models.enums;

public enum Estado {
    EN_PROCESO, RECIBIDO, EN_ENVIO, ENTREGADO
}
