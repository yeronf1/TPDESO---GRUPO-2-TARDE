package isi.deso.ds.tpintegrador.controllers;

import java.util.List;

import isi.deso.ds.tpintegrador.models.Cliente;
import isi.deso.ds.tpintegrador.repository.ClienteDAO;

public class ClienteController {

    private final ClienteDAO clienteDAO;

    public ClienteController(ClienteDAO clienteDAO) {
        this.clienteDAO = clienteDAO;
    }

    public List<Cliente> mostrarListaClientes() {
        return clienteDAO.listarCliente();
    }

    public boolean crearCliente(Cliente cliente) {
        return clienteDAO.crearCliente(cliente);
    }

    public boolean actualizarCliente(Cliente cliente) {
        return clienteDAO.actualizarCliente(cliente);
    }

    public boolean eliminarCliente(String id) {
        return clienteDAO.eliminarCliente(id);
    }

    public Cliente buscarCliente(String id) {
        return clienteDAO.buscarCliente(id);
    }

    public List<Cliente> buscarClientePorParametro(String parametro, String valor) {
        return clienteDAO.buscarClientePorParametro(parametro, valor);
    }
}
