package isi.deso.ds.tpintegrador.models;

import java.math.BigDecimal;
import java.math.RoundingMode;

import isi.deso.ds.tpintegrador.models.enums.TipoItem;

public class Bebida extends ItemMenu {

    private double graduacionAlcoholica;
    private boolean esGaseosa;
    private double volumen; // Volumen en ML.

    // GETTERS Y SETTERS:

    public double getGraduacionAlcoholica() {
        return graduacionAlcoholica;
    }

    public void setGraduacionAlcoholica(double graduacionAlcoholica) {
        this.graduacionAlcoholica = graduacionAlcoholica;
    }

    public boolean getEsGaseosa() {
        return esGaseosa;
    }

    public void setEsGaseosa(boolean esGaseosa) {
        this.esGaseosa = esGaseosa;
    }

    public double getVolumen() {
        return volumen;
    }

    public void setVolumen(double volumen) {
        this.volumen = volumen;
    }

    // CONSTRUCTORES:

    public Bebida(){

    }

    public Bebida(String id, String nombre, String descripcion, double precio, double graduacionAlcoholica, boolean esGaseosa, double volumen) {
        super(id, nombre, descripcion, precio, TipoItem.BEBIDA);
        this.graduacionAlcoholica = graduacionAlcoholica;
        this.esGaseosa = esGaseosa;
        this.volumen = volumen;
    }

    // MÉTODOS DE CONSIGNA:

    @Override
    public double peso() {
        double peso = volumen; // Inicialmente, asumimos que toda bebida que no es gaseosa ni tiene alcohol, se multiplica por un factor de 1.0.

        if (graduacionAlcoholica > 0) {
            peso *= 0.99;
        } else if (esGaseosa) {
            peso *= 1.04;
        }

        peso *= 1.2;

        // Redondeamos el peso a dos decimales
        BigDecimal bd = new BigDecimal(peso);
        bd = bd.setScale(2, RoundingMode.HALF_UP); // Redondeo hacia el entero más cercano

        return bd.doubleValue(); // Devolvemos el valor redondeado como double
    }

    @Override
    public boolean esComida(){
        return false;
    }

    @Override
    public  boolean esBebida(){
        return true;
    }

    @Override
    public  boolean aptoVegetariano(){
        return true; // Acá nosotros asumimos que todas las bebidas son aptas para vegetarianos.
    }

}
