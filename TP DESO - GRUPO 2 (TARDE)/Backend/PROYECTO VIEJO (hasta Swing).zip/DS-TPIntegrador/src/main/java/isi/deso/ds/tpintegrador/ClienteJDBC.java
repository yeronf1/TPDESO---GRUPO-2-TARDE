package isi.deso.ds.tpintegrador;

import java.sql.*;
import java.util.List;
import java.util.ArrayList;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;

import isi.deso.ds.tpintegrador.models.Cliente;
import isi.deso.ds.tpintegrador.models.Coordenada;
import isi.deso.ds.tpintegrador.config.ConexionDB;
import isi.deso.ds.tpintegrador.repository.ClienteDAO;

public class ClienteJDBC implements ClienteDAO {

    @Override
    public List<Cliente> listarCliente() {
        List<Cliente> clientes = new ArrayList<>();
        String query = "SELECT * FROM cliente";

        // Obtenemos la conexión desde la clase ConexionDB:
        try (Connection conn = ConexionDB.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            // Iteramos sobre el resultado de la consulta:
            while (rs.next()) {
                Cliente cliente = new Cliente(
                        rs.getString("id"),
                        rs.getString("nombre"),
                        rs.getString("cuit"),
                        rs.getString("email"),
                        rs.getString("direccion"),
                        new Coordenada(rs.getDouble("lat"), rs.getDouble("lng"))
                );
                clientes.add(cliente);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar clientes: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Opcionalmente, cerramos la conexión de forma explícita:
            ConexionDB.desconectar();
        }

        return clientes;
    }



    @Override
    public boolean crearCliente(Cliente cliente) {
        String query = "INSERT INTO cliente (nombre, cuit, email, direccion, lat, lng) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            // Seteamos los parámetros del PreparedStatement:
            stmt.setString(1, cliente.getNombre());
            stmt.setString(2, cliente.getCuit());
            stmt.setString(3, cliente.getEmail());
            stmt.setString(4, cliente.getDireccion());
            // Ponemos que las coordenadas se seteen inicialmente a null ya que éstas deberían de ser asociadas en torno a la dirección del cliente (mediante Google Maps, por ejemplo):
            stmt.setNull(5,1);
            stmt.setNull(6,1);

            int affectedRows = stmt.executeUpdate();

            // Verificamos si se ha insertado al menos una fila:
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        // Obtenemos el ID generado por la base de datos:
                        int idGenerado = generatedKeys.getInt(1);
                        // Convertimos el ID numérico a String con el formato "C001", "C002", etc.
                        cliente.setId("C00" + idGenerado);
                        return true;  // Retornamos true si la inserción fue exitosa.
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al crear cliente: " + e.getMessage());
            e.printStackTrace();
        }
        return false;  // Retornamos false si hubo algún error.
    }

    @Override
    public boolean actualizarCliente(Cliente cliente) {
        String query = "UPDATE cliente SET nombre = ?, cuit = ?, email = ?, direccion = ?, lat = ?, lng = ? WHERE id = ?";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, cliente.getNombre());
            pstmt.setString(2, cliente.getCuit());
            pstmt.setString(3, cliente.getEmail());
            pstmt.setString(4, cliente.getDireccion());
            pstmt.setDouble(5, cliente.getCoordenadas().getLAT());
            pstmt.setDouble(6, cliente.getCoordenadas().getLNG());
            pstmt.setString(7, cliente.getId());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar cliente: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean eliminarCliente(String id) {
        String query = "DELETE FROM cliente WHERE id = ?";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, id);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar cliente: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Cliente buscarCliente(String id) {
        Cliente cliente = null;
        String query = "SELECT * FROM cliente WHERE id = ?";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    cliente = new Cliente(
                            rs.getString("id"),
                            rs.getString("nombre"),
                            rs.getString("cuit"),
                            rs.getString("email"),
                            rs.getString("direccion"),
                            new Coordenada(rs.getDouble("lat"), rs.getDouble("lng"))
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar cliente: " + e.getMessage());
            e.printStackTrace();
        }
        return cliente;
    }

    @Override
    public List<Cliente> buscarClientePorParametro(String parametro, String valor) {
        List<Cliente> clientes = new ArrayList<>();
        String query = "SELECT * FROM cliente WHERE " + parametro + " = ?";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, valor);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Cliente cliente = new Cliente(
                            rs.getString("id"),
                            rs.getString("nombre"),
                            rs.getString("cuit"),
                            rs.getString("email"),
                            rs.getString("direccion"),
                            new Coordenada(rs.getDouble("lat"), rs.getDouble("lng"))
                    );
                    clientes.add(cliente);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar cliente por parámetro: " + e.getMessage());
            e.printStackTrace();
        }
        return clientes;
    }

}