package isi.deso.ds.tpintegrador;

import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

import isi.deso.ds.tpintegrador.models.*;
import isi.deso.ds.tpintegrador.models.enums.Estado;
import isi.deso.ds.tpintegrador.repository.PedidoDAO;
import isi.deso.ds.tpintegrador.exceptions.ItemNoEncontradoException;

public class PedidosMemory implements PedidoDAO {

    private final List<Pedido> pedidos = new ArrayList<>();
    ArrayList<Pedido> pedidosFiltradosPorEstado = new ArrayList<>();
    ItemsPedidoMemory itemsPedidoMemory = new ItemsPedidoMemory();
    ClienteMemory clienteMemory = new ClienteMemory();

    public PedidosMemory(){

        // PEDIDO 1:

        pedido1.agregarADetalle(itemsPedidoMemory.itemPedido1_1);
        pedido1.agregarADetalle(itemsPedidoMemory.itemPedido1_2);
        pedido1.agregarADetalle(itemsPedidoMemory.itemPedido1_3);
        pedido1.agregarADetalle(itemsPedidoMemory.itemPedido1_4);
        pedido1.setFormaDePago(new Transferencia());
        pedido1.setEstadoPedido(Estado.RECIBIDO);

        // PEDIDO 2:

        pedido2.agregarADetalle(itemsPedidoMemory.itemPedido2_1);
        pedido2.agregarADetalle(itemsPedidoMemory.itemPedido2_2);
        pedido2.agregarADetalle(itemsPedidoMemory.itemPedido2_3);
        pedido2.agregarADetalle(itemsPedidoMemory.itemPedido2_4);
        pedido2.setFormaDePago(new Transferencia());
        pedido2.setEstadoPedido(Estado.RECIBIDO);

        // PEDIDO 3:

        pedido3.agregarADetalle(itemsPedidoMemory.itemPedido3_1);
        pedido3.agregarADetalle(itemsPedidoMemory.itemPedido3_2);
        pedido3.agregarADetalle(itemsPedidoMemory.itemPedido3_3);
        pedido3.agregarADetalle(itemsPedidoMemory.itemPedido3_4);
        pedido3.setFormaDePago(new Transferencia());
        pedido3.setEstadoPedido(Estado.RECIBIDO);

        // PEDIDO 4:

        pedido4.agregarADetalle(itemsPedidoMemory.itemPedido4_1);
        pedido4.agregarADetalle(itemsPedidoMemory.itemPedido4_2);
        pedido4.agregarADetalle(itemsPedidoMemory.itemPedido4_3);
        pedido4.agregarADetalle(itemsPedidoMemory.itemPedido4_4);
        pedido4.setFormaDePago(new Transferencia());
        pedido4.setEstadoPedido(Estado.RECIBIDO);

        // PEDIDO 5:

        pedido5.agregarADetalle(itemsPedidoMemory.itemPedido5_1);
        pedido5.agregarADetalle(itemsPedidoMemory.itemPedido5_2);
        pedido5.agregarADetalle(itemsPedidoMemory.itemPedido5_3);
        pedido5.agregarADetalle(itemsPedidoMemory.itemPedido5_4);
        pedido5.setFormaDePago(new Transferencia());
        pedido5.setEstadoPedido(Estado.RECIBIDO);

        // PEDIDO 6:

        pedido6.agregarADetalle(itemsPedidoMemory.itemPedido6_1);
        pedido6.agregarADetalle(itemsPedidoMemory.itemPedido6_2);
        pedido6.agregarADetalle(itemsPedidoMemory.itemPedido6_3);
        pedido6.agregarADetalle(itemsPedidoMemory.itemPedido6_4);
        pedido6.setFormaDePago(new Transferencia());
        pedido6.setEstadoPedido(Estado.RECIBIDO);

        // PEDIDO 7:

        pedido7.agregarADetalle(itemsPedidoMemory.itemPedido7_1);
        pedido7.agregarADetalle(itemsPedidoMemory.itemPedido7_2);
        pedido7.agregarADetalle(itemsPedidoMemory.itemPedido7_3);
        pedido7.agregarADetalle(itemsPedidoMemory.itemPedido7_4);
        pedido7.setFormaDePago(new Transferencia());
        pedido7.setEstadoPedido(Estado.RECIBIDO);

        // PEDIDO 8:

        pedido8.agregarADetalle(itemsPedidoMemory.itemPedido8_1);
        pedido8.agregarADetalle(itemsPedidoMemory.itemPedido8_2);
        pedido8.agregarADetalle(itemsPedidoMemory.itemPedido8_3);
        pedido8.agregarADetalle(itemsPedidoMemory.itemPedido8_4);
        pedido8.setFormaDePago(new Transferencia());
        pedido8.setEstadoPedido(Estado.RECIBIDO);

        // Agregado de los pedidos a la lista general de pedidos:

        pedidos.add(pedido1);
        pedidos.add(pedido2);
        pedidos.add(pedido3);
        pedidos.add(pedido4);
        pedidos.add(pedido5);
        pedidos.add(pedido6);
        pedidos.add(pedido7);
        pedidos.add(pedido8);

    }

    @Override
    public List<Pedido> listarPedidos() {
        return new ArrayList<>(pedidos);
    }

    @Override
    public boolean crearPedido(Pedido pedido) {
        return pedidos.add(pedido);
    }

    @Override
    public boolean eliminarPedido(String id) {
        return pedidos.removeIf(p -> p.getIdPedido().equals(id));
    }

    @Override
    public Pedido buscarPedido(String filtro) {
        return pedidos.stream()
                .filter(p -> p.getIdPedido().equals(filtro) || p.getCliente().getNombre().equalsIgnoreCase(filtro))
                .findFirst()
                .orElse(null);
    }

    @Override
    public ArrayList<Pedido> filtrarPorEstado(String estado) throws ItemNoEncontradoException {
        pedidosFiltradosPorEstado = pedidos.stream().filter(pedido -> (pedido.getEstadoPedido().name()).equalsIgnoreCase(estado)).collect(Collectors.toCollection(ArrayList::new));

        if(pedidosFiltradosPorEstado.isEmpty()){
            throw new ItemNoEncontradoException("\nNo se encontaron pedidos con el estado " + estado + ".");
        }

        return pedidosFiltradosPorEstado;
    }

    // Los siguientes métodos están vagamente implementados porque los que nos interesa implementar son los de la clase PedidosJDBC; acá sólo necesitamos que estén las implementaciones para que no fallen.

    public boolean actualizarEstadoPedido(String idPedido, Estado nuevoEstado){
        return true;
    }

    public boolean actualizarDetallePedido(String idPedido, List<ItemPedido> itemsActualizados){
        return true;
    }

    public Pedido getPedidoById(String idPedido){
        return new Pedido();
    }

    @Override
    public List<ItemMenu> obtenerItemsMenu() throws SQLException {
        return List.of();
    }

    // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    // SIMULACION DE BASE DE DATOS DE PEDIDOS:

    // Ejemplos de pedidos:

    Pedido pedido1 = new Pedido("P001", clienteMemory.cliente1);
    Pedido pedido2 = new Pedido("P002", clienteMemory.cliente2);
    Pedido pedido3 = new Pedido("P003", clienteMemory.cliente3);
    Pedido pedido4 = new Pedido("P004", clienteMemory.cliente4);
    Pedido pedido5 = new Pedido("P005", clienteMemory.cliente5);
    Pedido pedido6 = new Pedido("P006", clienteMemory.cliente6);
    Pedido pedido7 = new Pedido("P007", clienteMemory.cliente7);
    Pedido pedido8 = new Pedido("P008", clienteMemory.cliente8);

}
