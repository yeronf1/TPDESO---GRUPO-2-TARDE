package isi.deso.ds.tpintegrador.models.enums;

public enum TipoItem {
    COMIDA, BEBIDA
}
