package isi.deso.ds.tpintegrador.models;

import java.math.BigDecimal;
import java.math.RoundingMode;

import isi.deso.ds.tpintegrador.models.enums.TipoItem;

public class Plato extends ItemMenu {

    private double peso;
    private int calorias;
    private boolean aptoCeliaco;
    private boolean aptoVegetariano;

    // GETTERS Y SETTERS:

    // No existe un metodo 'getPeso' porque para eso esta el metodo 'peso()' que devuelve el atributo 'peso' con sus respectivas modificaciones.

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public int getCalorias() {
        return calorias;
    }

    public void setCalorias(int calorias) {
        this.calorias = calorias;
    }

    public boolean getAptoCeliaco() {
        return aptoCeliaco;
    }

    public void setAptoCeliaco(boolean aptoCeliaco) {
        this.aptoCeliaco = aptoCeliaco;
    }

    public boolean getAptoVegetariano() {
        return aptoVegetariano;
    }

    public void setAptoVegetariano(boolean aptoVegetariano) {
        this.aptoVegetariano = aptoVegetariano;
    }

    // CONSTRUCTORES:

    public Plato(){

    }

    public Plato(String id, String nombre, String descripcion ,double precio, double peso, int calorias, boolean aptoCeliaco, boolean aptoVegetariano) {
        super(id, nombre, descripcion ,precio, TipoItem.COMIDA);
        this.peso = peso;
        this.calorias = calorias;
        this.aptoCeliaco = aptoCeliaco;
        this.aptoVegetariano = aptoVegetariano;
    }

    // MÉTODOS DE CONSIGNA:

    @Override
    public double peso(){
        double nuevoPeso = this.peso *= 1.1;

        // Usamos BigDecimal para redondear a dos decimales
        BigDecimal bd = new BigDecimal(nuevoPeso);
        bd = bd.setScale(2, RoundingMode.HALF_UP); // Redondeo hacia el entero más cercano

        return bd.doubleValue(); // Devolvemos el valor redondeado como double
    }

    @Override
    public boolean esComida(){
        return true;
    }

    @Override
    public  boolean esBebida(){
        return false;
    }

    @Override
    public  boolean aptoVegetariano(){
        return this.aptoVegetariano;
    }

}