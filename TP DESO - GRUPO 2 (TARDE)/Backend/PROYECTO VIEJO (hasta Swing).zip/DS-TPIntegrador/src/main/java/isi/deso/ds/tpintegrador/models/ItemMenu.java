package isi.deso.ds.tpintegrador.models;

import isi.deso.ds.tpintegrador.models.enums.TipoItem;

public abstract class ItemMenu {

    private String id;
    private Vendedor vendedor;
    private String nombre;
    private String descripcion;
    private double precio;
    private Categoria categoria;

    public abstract double peso();
    public abstract boolean esComida();
    public abstract boolean esBebida();
    public abstract boolean aptoVegetariano();

    // GETTERS Y SETTERS:

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Vendedor getVendedor() { return vendedor; }

    public void setVendedor(Vendedor vendedor) { this.vendedor = vendedor; }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    // CONSTRUCTORES:

    public ItemMenu(){

    }

    public ItemMenu(String id, String nombre, String descripcion ,double precio, TipoItem tipoItem) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.categoria = new Categoria();
        this.categoria.setTipoItem(tipoItem);
    }
}
