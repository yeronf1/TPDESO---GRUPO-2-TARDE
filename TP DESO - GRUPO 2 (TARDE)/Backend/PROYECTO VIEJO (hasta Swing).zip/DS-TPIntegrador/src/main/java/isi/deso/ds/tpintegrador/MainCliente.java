package isi.deso.ds.tpintegrador;

import isi.deso.ds.tpintegrador.models.Cliente;

import java.util.ArrayList;
import java.util.Iterator;

public class MainCliente {

    public static void main(String[] args) {

        // Generamos una instancia de ItemsPedidoMemory para poder acceder a todas las instancias creadas dentro de esa clase (aquellas que simulan la base de datos).
        ItemsPedidoMemory itemsPedidoMemory = new ItemsPedidoMemory();

        // Generamos un ArrayList y agregamos los clientes manualmente ya que son pocos (en un futuro implementaremos un metodo de agregado automático).
        ArrayList<Cliente> arregloClientes = new ArrayList<>();

        arregloClientes.add(itemsPedidoMemory.cl1);
        arregloClientes.add(itemsPedidoMemory.cl2);
        arregloClientes.add(itemsPedidoMemory.cl3);

        System.out.println("Se han cargado 3 clientes a la lista de clientes.");
        System.out.println("\nLISTA DE CLIENTES:");
        for (Cliente cliente : arregloClientes) {
            System.out.println("* ID: " + cliente.getId() + " - " + cliente.getNombre() + " (DIRECCION: " + cliente.getDireccion() + ").");
        }

        // Creamos un nombre de cliente al azar que buscaremos en la lista de clientes ya creada.
        String clienteABuscar = "Francisco";
        System.out.print("\nSe buscaran clientes llamados: " + clienteABuscar + ".");
        // La implementacion realizada tambien sirve para buscar por ID ingresado, este es solo un ejemplo.
        
        Iterator<Cliente> iterator = arregloClientes.iterator();

        // Declaramos un nuevo objeto tipo cliente que irá tomando el valor de cada objeto cliente en la ArrayList (en cada iteración) para poder ir comparando con el cliente buscado.
        Cliente buscado;

        boolean bandera = true;
        
        while(iterator.hasNext() && bandera){

            buscado = iterator.next();
            
            // Buscamos por el nombre o ID aleatorio antes creado.
            if(clienteABuscar.equalsIgnoreCase(buscado.getNombre()) || clienteABuscar.equalsIgnoreCase(buscado.getId())){
                
                System.out.println("\nSe ha encontrado un cliente con el nombre: " + clienteABuscar + ".");

                // Eliminamos el elemento actual que tomó la variable iterator (es decir, el cliente buscado).
                iterator.remove();

                System.out.println("El cliente " + clienteABuscar + " ha sido eliminado de la lista de clientes.");

                System.out.println("\nLISTA DE CLIENTES:");
                for (Cliente cliente : arregloClientes) {
                    System.out.println("* ID: " + cliente.getId() + " - " + cliente.getNombre() + " (DIRECCION: " + cliente.getDireccion() + ").");
                }

                bandera = false;
                // Una vez que terminamos el proceso de búsqueda, salimos del bucle seteando la bandera a falso.
            }
        }
        
        if(bandera){
            System.out.println("No existe un cliente con el nombre: " + clienteABuscar + ".");
        }
    }
}
