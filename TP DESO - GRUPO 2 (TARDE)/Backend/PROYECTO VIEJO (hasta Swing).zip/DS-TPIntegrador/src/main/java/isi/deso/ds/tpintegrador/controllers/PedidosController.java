package isi.deso.ds.tpintegrador.controllers;

import java.util.List;
import java.sql.SQLException;

import isi.deso.ds.tpintegrador.models.Pedido;
import isi.deso.ds.tpintegrador.models.ItemMenu;
import isi.deso.ds.tpintegrador.models.enums.Estado;
import isi.deso.ds.tpintegrador.repository.PedidoDAO;

public class PedidosController {

    private final PedidoDAO pedidosDAO;

    public PedidosController(PedidoDAO pedidosDAO) {
        this.pedidosDAO = pedidosDAO;
    }

    public List<Pedido> mostrarListaPedidos() {
        return pedidosDAO.listarPedidos();
    }

    public boolean crearNuevoPedido(Pedido nuevoPedido) {
        return pedidosDAO.crearPedido(nuevoPedido);
    }

    public boolean eliminarPedido(String id) {
        return pedidosDAO.eliminarPedido(id);
    }

    public Pedido buscarPedido(String filtro) {
        return pedidosDAO.buscarPedido(filtro);
    }

    public boolean actualizarEstadoPedido(String idPedido, Estado nuevoEstado) {
        return pedidosDAO.actualizarEstadoPedido(idPedido, nuevoEstado);
    }

    public Pedido getPedidoById(String idPedido) {
        return pedidosDAO.getPedidoById(idPedido);
    }

    public boolean actualizarDetallePedido(Pedido pedido) {
        return pedidosDAO.actualizarDetallePedido(pedido.getIdPedido(), pedido.getPedidosDetalle());
    }

    public List<ItemMenu> obtenerItemsMenu() throws SQLException {
        return pedidosDAO.obtenerItemsMenu();
    }

}
