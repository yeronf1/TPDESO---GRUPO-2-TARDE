package isi.deso.ds.tpintegrador.models;

import java.util.Observer;
import java.util.Observable;

public class Cliente implements Observer {
    
    private String id;
    private String nombre;
    private String cuit;
    private String email;
    private String direccion;
    private Coordenada coordenadas;  
    
    // GETTERS Y SETTERS:

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Coordenada getCoordenadas() {
        return coordenadas;
    }

    public void setCoordenadas(Coordenada coordenadas) {
        this.coordenadas = coordenadas;
    }

    // CONSTRUCTORES:

    public Cliente(){
    }

    public Cliente(String id, String nombre, String cuit, String email, String direccion, Coordenada coordenadas) {
        this.id = id;
        this.nombre = nombre;
        this.cuit = cuit;
        this.email = email;
        this.direccion = direccion;
        this.coordenadas = coordenadas;
    }

    @Override
    public void update(Observable o, Object arg) {
        System.out.println("\n(EL SIGUIENTE MENSAJE SÓLO SERÁ VISUALIZABLE EN LA INTERFAZ CLIENTE).");
        System.out.println("Tu pedido ha sido aceptado y está en estado: " + ((Pedido)o).getEstadoPedido() + ".");
    }

}