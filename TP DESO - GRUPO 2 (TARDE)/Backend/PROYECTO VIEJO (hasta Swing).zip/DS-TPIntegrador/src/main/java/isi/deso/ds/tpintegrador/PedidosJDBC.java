package isi.deso.ds.tpintegrador;

import java.sql.*;
import java.util.List;
import java.util.ArrayList;
import java.time.LocalDateTime;

import isi.deso.ds.tpintegrador.models.*;
import isi.deso.ds.tpintegrador.models.enums.Estado;
import isi.deso.ds.tpintegrador.repository.PedidoDAO;
import isi.deso.ds.tpintegrador.config.ConexionDB;
import isi.deso.ds.tpintegrador.exceptions.ItemNoEncontradoException;

public class PedidosJDBC implements PedidoDAO {

    @Override
    public List<Pedido> listarPedidos() {
        List<Pedido> pedidos = new ArrayList<>();

        String query = """
    SELECT * FROM pedido p
    INNER JOIN cliente c ON p.id_cliente = c.id
    INNER JOIN pago Pg ON p.id_pago = Pg.id_pago
    """;

        String queryItemsPedido = """
    SELECT * FROM itemPedido ip
    INNER JOIN items_menu mi ON ip.id_item = mi.id
    WHERE ip.id_pedido = ?;
    """;

        try (Connection conn = ConexionDB.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)
        ) {
            while (rs.next()) {
                Pedido pedido = new Pedido(rs.getString("id_pedido"),new Cliente(rs.getString("id_cliente"), rs.getString("nombre"), rs.getString("cuit"), rs.getString("email"), rs.getString("direccion"), new Coordenada(rs.getDouble("lat"), rs.getDouble("lng"))));

                // Obtención de forma de pago:
                if (rs.getString("alias") != null) {
                    LocalDateTime fechaPago = rs.getTimestamp("fechaPago").toLocalDateTime();
                    pedido.setFormaDePago(new MercadoPago(rs.getString("id_pago"), fechaPago, rs.getString("alias")));
                } else {
                    LocalDateTime fechaPago = rs.getTimestamp("fechaPago").toLocalDateTime();
                    pedido.setFormaDePago(new Transferencia(rs.getString("id_pago"), fechaPago, rs.getString("cuit"), rs.getString("cbu")));
                }

                pedido.setEstadoPedido(Estado.valueOf(rs.getString("estado")));

                // Consulta para obtener los ItemPedido relacionados con este Pedido:
                try (PreparedStatement ps = conn.prepareStatement(queryItemsPedido)) {
                    ps.setString(1, rs.getString("id"));  // id del pedido actual

                    try (ResultSet rsItemsPedido = ps.executeQuery()) {
                        while (rsItemsPedido.next()) {
                            ItemPedido itemPedido = new ItemPedido();
                            itemPedido.setCodigo(rsItemsPedido.getString("codigo"));
                            String tipoItem = rsItemsPedido.getString("categoria");
                            if ("COMIDA".equalsIgnoreCase(tipoItem)) {
                                itemPedido.setItemMenu(
                                        new Plato(
                                                rsItemsPedido.getString("id"),
                                                rsItemsPedido.getString("nombre"),
                                                rsItemsPedido.getString("descripcion"),
                                                rsItemsPedido.getDouble("precio"),
                                                rsItemsPedido.getDouble("peso"),
                                                rsItemsPedido.getInt("calorias"),
                                                rsItemsPedido.getBoolean("apto_celiaco"),
                                                rsItemsPedido.getBoolean("apto_vegetariano")));
                            } else {
                                itemPedido.setItemMenu(
                                        new Bebida(rs.getString("id"),
                                                rsItemsPedido.getString("nombre"),
                                                rsItemsPedido.getString("descripcion"),
                                                rsItemsPedido.getDouble("precio"),
                                                rsItemsPedido.getDouble("graduacion_alcoholica"),
                                                rsItemsPedido.getBoolean("es_gaseosa"),
                                                rsItemsPedido.getDouble("volumen"))
                                );
                            }

                            // Agregamos el ítem pedido al detalle de pedido:
                            pedido.agregarADetalle(itemPedido);
                        }
                    }
                }
                // Busco el total del pedido en la base de datos:
                pedido.setTotal(rs.getDouble("total"));

                // Agregamos el pedido a la lista de pedidos:
                pedidos.add(pedido);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar pedidos: " + e.getMessage());
            e.printStackTrace();
        }

        return pedidos;
    }

    @Override
    public boolean crearPedido(Pedido pedido) {
        String insertarClienteQuery = "INSERT INTO cliente (nombre) VALUES (?)";
        String insertarPagoQuery = "INSERT INTO pago (fechaPago, alias, cuit, cbu) VALUES (?, ?, ?, ?)";
        String insertarPedidoQuery = "INSERT INTO pedido (id_cliente, total, id_pago, estado) VALUES (?, ?, ?, ?)";
        String insertarItemPedidoQuery = "INSERT INTO itemPedido (id_pedido, id_item) VALUES (?, ?)";

        try (Connection conn = ConexionDB.conectar()) {
            // Iniciamos la transacción:
            conn.setAutoCommit(false);

            // Insertamos cliente asociado al pedido:
            int clienteId;
            try (PreparedStatement stmtCliente = conn.prepareStatement(insertarClienteQuery, Statement.RETURN_GENERATED_KEYS)) {
                stmtCliente.setString(1, "ClienteActual");  // Nombre del cliente
                int affectedRows = stmtCliente.executeUpdate();

                if (affectedRows > 0) {
                    try (ResultSet generatedKeys = stmtCliente.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            clienteId = generatedKeys.getInt(1);  // Obtenemos el ID del cliente recién insertado.
                        } else {
                            conn.rollback();
                            throw new SQLException("Fallo al obtener el ID del nuevo cliente.");
                        }
                    }
                } else {
                    conn.rollback();
                    throw new SQLException("Fallo al insertar el nuevo cliente.");
                }
            }

            // Insertamos el pago:
            int pagoId;
            try (PreparedStatement stmtPago = conn.prepareStatement(insertarPagoQuery, Statement.RETURN_GENERATED_KEYS)) {
                LocalDateTime fechaPago = LocalDateTime.now();
                stmtPago.setTimestamp(1, Timestamp.valueOf(fechaPago));

                if (pedido.getFormaDePago() instanceof MercadoPago) {
                    MercadoPago mercadoPago = (MercadoPago) pedido.getFormaDePago();
                    stmtPago.setString(2, mercadoPago.getAlias());
                    stmtPago.setNull(3, Types.VARCHAR);  // 'cuit' no aplica para MercadoPago
                    stmtPago.setNull(4, Types.VARCHAR);  // 'cbu' no aplica para MercadoPago
                } else if (pedido.getFormaDePago() instanceof Transferencia) {
                    Transferencia transferencia = (Transferencia) pedido.getFormaDePago();
                    stmtPago.setNull(2, Types.VARCHAR);  // 'alias' no aplica para Transferencia
                    stmtPago.setString(3, transferencia.getCuit());
                    stmtPago.setString(4, transferencia.getCbu());
                }

                int affectedRows = stmtPago.executeUpdate();

                if (affectedRows > 0) {
                    try (ResultSet generatedKeys = stmtPago.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            pagoId = generatedKeys.getInt(1);  // Obtenemos el ID del nuevo pago.
                        } else {
                            conn.rollback();
                            throw new SQLException("Fallo al obtener el ID del nuevo pago.");
                        }
                    }
                } else {
                    conn.rollback();
                    throw new SQLException("Fallo al insertar el nuevo pago.");
                }
            }

            // Insertamos el pedido:
            int pedidoId;
            try (PreparedStatement pstmtPedido = conn.prepareStatement(insertarPedidoQuery, Statement.RETURN_GENERATED_KEYS)) {
                pstmtPedido.setInt(1, clienteId);
                pstmtPedido.setDouble(2, pedido.getTotal());
                pstmtPedido.setInt(3, pagoId);  // Asociamos el pago al pedido.
                pstmtPedido.setString(4, pedido.getEstadoPedido().toString());

                int affectedRows = pstmtPedido.executeUpdate();

                if (affectedRows > 0) {
                    try (ResultSet generatedKeys = pstmtPedido.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            pedidoId = generatedKeys.getInt(1);  // Obtenemos el ID del nuevo pedido.
                            pedido.setIdPedido("P00" + pedidoId);  // Asignamos el ID generado al pedido.
                        } else {
                            conn.rollback();
                            throw new SQLException("Fallo al obtener el ID del nuevo pedido.");
                        }
                    }
                } else {
                    conn.rollback();
                    throw new SQLException("Fallo al insertar el nuevo pedido.");
                }
            }

            // Insertamos los ítems del pedido utilizando el ID real:
            try (PreparedStatement pstmtItems = conn.prepareStatement(insertarItemPedidoQuery)) {
                for (ItemPedido item : pedido.getPedidosDetalle()) {
                    // Recuperamos el ID real del ItemMenu de la base de datos basado en su nombre:
                    int idItem = obtenerIdRealDelItem(conn, item.getItemMenu().getNombre());  // Recuperamos el ID real desde la base de datos.

                    pstmtItems.setInt(1, pedidoId);  // ID del pedido
                    pstmtItems.setInt(2, idItem);    // ID real del ítem
                    pstmtItems.addBatch();  // Agregamos al batch de inserciones.
                }

                // Ejecutamos el batch de inserciones:
                pstmtItems.executeBatch();
            }

            // Confirmamos la transacción:
            conn.commit();
            return true;

        } catch (SQLException e) {
            System.err.println("Error al crear pedido: " + e.getMessage());
            e.printStackTrace();
        }

        return false;
    }

    public boolean actualizarEstadoPedido(String idPedido, Estado nuevoEstado) {
        String query = "UPDATE pedido SET estado = ? WHERE id_pedido = ?";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, nuevoEstado.toString());
            stmt.setString(2, idPedido);

            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el estado del pedido: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean actualizarDetallePedido(String idPedido, List<ItemPedido> itemsActualizados) {
        String deleteItemsQuery = "DELETE FROM itemPedido WHERE id_pedido = ?";
        String insertItemQuery = """
        INSERT INTO itemPedido (id_pedido, id_item, codigo) 
        VALUES (?, ?, ?)
    """;
        String updateTotalQuery = "UPDATE pedido SET total = ? WHERE id_pedido = ?";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement psDelete = conn.prepareStatement(deleteItemsQuery)) {

            // Eliminamos los ítems existentes del pedido:
            psDelete.setString(1, idPedido);
            psDelete.executeUpdate();

            // Insertamos los ítems actualizados:
            try (PreparedStatement psInsert = conn.prepareStatement(insertItemQuery)) {
                double nuevoTotal = 0.0;

                for (ItemPedido item : itemsActualizados) {
                    psInsert.setString(1, idPedido);
                    psInsert.setString(2, item.getItemMenu().getId());
                    psInsert.setString(3, item.getCodigo());
                    psInsert.addBatch();

                    // Calculamos el nuevo total:
                    nuevoTotal += item.getItemMenu().getPrecio();
                }
                psInsert.executeBatch();

                // Actualizamos el total del pedido en la tabla `pedido`:
                try (PreparedStatement psUpdateTotal = conn.prepareStatement(updateTotalQuery)) {
                    psUpdateTotal.setDouble(1, nuevoTotal);
                    psUpdateTotal.setString(2, idPedido);
                    psUpdateTotal.executeUpdate();
                }
            }
            return true;

        } catch (SQLException e) {
            System.err.println("Error al actualizar el detalle del pedido: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean eliminarPedido(String id) {
        String query = "DELETE FROM pedido WHERE id_pedido = ?";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, id);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar pedido: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Pedido buscarPedido(String filtro) {
        String query = """
    SELECT *
    FROM pedido p
    INNER JOIN cliente c ON p.id_cliente = c.id
    INNER JOIN pago Pg ON p.id_pago = Pg.id_pago
    WHERE p.id_pedido = ? OR c.nombre = ?
    """;

        String queryItemsPedido = """
    SELECT *
    FROM itemPedido ip
    INNER JOIN items_menu mi ON ip.id_item = mi.id
    WHERE ip.id_pedido = ?
    """;

        Pedido pedido = null;

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            // Establecemos los parámetros de la consulta:
            stmt.setString(1, filtro);  // Filtro por id_pedido
            stmt.setString(2, filtro);  // Filtro por nombre

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    pedido = new Pedido(rs.getString("id"), new Cliente(
                            rs.getString("id_cliente"),
                            rs.getString("nombre"),
                            rs.getString("cuit"),
                            rs.getString("email"),
                            rs.getString("direccion"),
                            new Coordenada(rs.getDouble("lat"), rs.getDouble("lng"))
                    ));

                    // Forma de pago:
                    if (rs.getString("alias") != null) {
                        LocalDateTime fechaPago = rs.getTimestamp("fechaPago").toLocalDateTime();
                        pedido.setFormaDePago(new MercadoPago(rs.getString("id_pago"), fechaPago, rs.getString("alias")));
                    } else {
                        LocalDateTime fechaPago = rs.getTimestamp("fechaPago").toLocalDateTime();
                        pedido.setFormaDePago(new Transferencia(rs.getString("id_pago"), fechaPago, rs.getString("cuit"), rs.getString("cbu")));
                    }

                    // Estado del pedido:
                    pedido.setEstadoPedido(Estado.valueOf(rs.getString("estado")));

                    // Obtenemos los ItemPedido relacionados con este Pedido:
                    try (PreparedStatement ps = conn.prepareStatement(queryItemsPedido)) {
                        ps.setString(1, filtro);

                        try (ResultSet rsItemsPedido = ps.executeQuery()) {
                            while (rsItemsPedido.next()) {
                                ItemPedido itemPedido = new ItemPedido();
                                itemPedido.setCodigo(rsItemsPedido.getString("codigo"));
                                String tipoItem = rsItemsPedido.getString("categoria");

                                if ("COMIDA".equalsIgnoreCase(tipoItem)) {
                                    itemPedido.setItemMenu(new Plato(
                                            rsItemsPedido.getString("id"),
                                            rsItemsPedido.getString("nombre"),
                                            rsItemsPedido.getString("descripcion"),
                                            rsItemsPedido.getDouble("precio"),
                                            rsItemsPedido.getDouble("peso"),
                                            rsItemsPedido.getInt("calorias"),
                                            rsItemsPedido.getBoolean("apto_celiaco"),
                                            rsItemsPedido.getBoolean("apto_vegetariano")
                                    ));
                                } else {
                                    itemPedido.setItemMenu(new Bebida(
                                            rsItemsPedido.getString("id"),
                                            rsItemsPedido.getString("nombre"),
                                            rsItemsPedido.getString("descripcion"),
                                            rsItemsPedido.getDouble("precio"),
                                            rsItemsPedido.getDouble("graduacion_alcoholica"),
                                            rsItemsPedido.getBoolean("es_gaseosa"),
                                            rsItemsPedido.getDouble("volumen")
                                    ));
                                }

                                pedido.agregarADetalle(itemPedido);
                            }
                        }
                    }

                    // Total del pedido:
                    pedido.setTotal(rs.getDouble("total"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return pedido;
    }

    @Override
    public Pedido getPedidoById(String idPedido) {
        Pedido pedido = null;
        String query = """
        SELECT * FROM pedido p
        INNER JOIN cliente c ON p.id_cliente = c.id
        INNER JOIN pago Pg ON p.id_pago = Pg.id_pago
        WHERE p.id_pedido = ?;
    """;

        String queryItemsPedido = """
        SELECT * FROM itemPedido ip
        INNER JOIN items_menu mi ON ip.id_item = mi.id
        WHERE ip.id_pedido = ?;
    """;

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement psPedido = conn.prepareStatement(query)) {
            psPedido.setString(1, idPedido);
            try (ResultSet rs = psPedido.executeQuery()) {
                if (rs.next()) {
                    pedido = new Pedido(rs.getString("id_pedido"),
                            new Cliente(rs.getString("id_cliente"), rs.getString("nombre"), rs.getString("cuit"),
                                    rs.getString("email"), rs.getString("direccion"),
                                    new Coordenada(rs.getDouble("lat"), rs.getDouble("lng"))));

                    // Configuramos forma de pago:
                    LocalDateTime fechaPago = rs.getTimestamp("fechaPago").toLocalDateTime();
                    if (rs.getString("alias") != null) {
                        pedido.setFormaDePago(new MercadoPago(rs.getString("id_pago"), fechaPago, rs.getString("alias")));
                    } else {
                        pedido.setFormaDePago(new Transferencia(rs.getString("id_pago"), fechaPago, rs.getString("cuit"), rs.getString("cbu")));
                    }

                    pedido.setEstadoPedido(Estado.valueOf(rs.getString("estado")));

                    // Cargamos detalles del pedido:
                    try (PreparedStatement psItems = conn.prepareStatement(queryItemsPedido)) {
                        psItems.setString(1, idPedido);
                        try (ResultSet rsItems = psItems.executeQuery()) {
                            while (rsItems.next()) {
                                ItemPedido itemPedido = new ItemPedido();
                                itemPedido.setCodigo(rsItems.getString("codigo"));
                                if ("COMIDA".equalsIgnoreCase(rsItems.getString("categoria"))) {
                                    itemPedido.setItemMenu(new Plato(rsItems.getString("id"),
                                            rsItems.getString("nombre"),
                                            rsItems.getString("descripcion"),
                                            rsItems.getDouble("precio"),
                                            rsItems.getDouble("peso"),
                                            rsItems.getInt("calorias"),
                                            rsItems.getBoolean("apto_celiaco"),
                                            rsItems.getBoolean("apto_vegetariano")));
                                } else {
                                    itemPedido.setItemMenu(new Bebida(rsItems.getString("id"),
                                            rsItems.getString("nombre"),
                                            rsItems.getString("descripcion"),
                                            rsItems.getDouble("precio"),
                                            rsItems.getDouble("graduacion_alcoholica"),
                                            rsItems.getBoolean("es_gaseosa"),
                                            rsItems.getDouble("volumen")));
                                }
                                pedido.agregarADetalle(itemPedido);
                            }
                        }
                    }

                    // Configuramos total:
                    pedido.setTotal(rs.getDouble("total"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener el pedido por ID: " + e.getMessage());
            e.printStackTrace();
        }
        return pedido;
    }

    public List<ItemMenu> obtenerItemsMenu() throws SQLException {
        List<ItemMenu> itemsMenu = new ArrayList<>();
        String query = "SELECT * FROM items_menu";  // Consulta para obtener todos los ítems del menú.

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                ItemMenu item;

                // Determinamos la subclase según el tipo de ítem:
                String tipoItem = rs.getString("categoria");
                if ("COMIDA".equalsIgnoreCase(tipoItem)) {
                    item = new Plato(
                            rs.getString("id"),
                            rs.getString("nombre"),
                            rs.getString("descripcion"),
                            rs.getDouble("precio"),
                            rs.getDouble("peso"),
                            rs.getInt("calorias"),
                            rs.getBoolean("apto_celiaco"),
                            rs.getBoolean("apto_vegetariano")
                    );
                } else if ("BEBIDA".equalsIgnoreCase(tipoItem)) {
                    item = new Bebida(
                            rs.getString("id"),
                            rs.getString("nombre"),
                            rs.getString("descripcion"),
                            rs.getDouble("precio"),
                            rs.getDouble("graduacion_alcoholica"),
                            rs.getBoolean("es_gaseosa"),
                            rs.getDouble("volumen")
                    );
                } else {
                    throw new IllegalArgumentException("Tipo de ítem desconocido: " + tipoItem);
                }

                // Agregamos el ítem a la lista:
                itemsMenu.add(item);
            }
        }
        return itemsMenu;
    }

    @Override
    public ArrayList<Pedido> filtrarPorEstado(String estado) throws ItemNoEncontradoException {
        ArrayList<Pedido> pedidosFiltradosPorEstado = new ArrayList<>();

        String query = """
    SELECT *
    FROM pedido p
    INNER JOIN cliente c ON p.id_cliente = c.id
    INNER JOIN pago Pg ON p.id_pago = Pg.id_pago
    WHERE LOWER(p.estado) = LOWER(?)
    """;

        String queryItemsPedido = """
    SELECT *
    FROM itemPedido ip
    INNER JOIN items_menu mi ON ip.id_item = mi.id
    WHERE ip.id_pedido = ?
    """;

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, estado);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Pedido pedido = new Pedido();
                    pedido.setIdPedido(rs.getString("id"));
                    pedido.setCliente(new Cliente(
                            rs.getString("id_cliente"),
                            rs.getString("nombre"),
                            rs.getString("cuit"),
                            rs.getString("email"),
                            rs.getString("direccion"),
                            new Coordenada(rs.getDouble("lat"), rs.getDouble("lng"))
                    ));

                    // Forma de pago:
                    if (rs.getString("alias") != null) {
                        LocalDateTime fechaPago = rs.getTimestamp("fechaPago").toLocalDateTime();
                        pedido.setFormaDePago(new MercadoPago(
                                rs.getString("id_pago"),
                                fechaPago,
                                rs.getString("alias")
                        ));
                    } else {
                        LocalDateTime fechaPago = rs.getTimestamp("fechaPago").toLocalDateTime();
                        pedido.setFormaDePago(new Transferencia(
                                rs.getString("id_pago"),
                                fechaPago,
                                rs.getString("cuit"),
                                rs.getString("cbu")
                        ));
                    }

                    // Estado del pedido:
                    pedido.setEstadoPedido(Estado.valueOf(rs.getString("estado")));

                    // Obtenemos los ItemPedido relacionados con este Pedido:
                    try (PreparedStatement ps = conn.prepareStatement(queryItemsPedido)) {
                        ps.setString(1, rs.getString("id"));  // id del pedido

                        try (ResultSet rsItemsPedido = ps.executeQuery()) {
                            while (rsItemsPedido.next()) {
                                ItemPedido itemPedido = new ItemPedido();
                                itemPedido.setCodigo(rsItemsPedido.getString("codigo"));
                                String tipoItem = rsItemsPedido.getString("categoria");

                                if ("COMIDA".equalsIgnoreCase(tipoItem)) {
                                    itemPedido.setItemMenu(new Plato(
                                            rsItemsPedido.getString("id"),
                                            rsItemsPedido.getString("nombre"),
                                            rsItemsPedido.getString("descripcion"),
                                            rsItemsPedido.getDouble("precio"),
                                            rsItemsPedido.getDouble("peso"),
                                            rsItemsPedido.getInt("calorias"),
                                            rsItemsPedido.getBoolean("apto_celiaco"),
                                            rsItemsPedido.getBoolean("apto_vegetariano")
                                    ));
                                } else {
                                    itemPedido.setItemMenu(new Bebida(
                                            rsItemsPedido.getString("id"),
                                            rsItemsPedido.getString("nombre"),
                                            rsItemsPedido.getString("descripcion"),
                                            rsItemsPedido.getDouble("precio"),
                                            rsItemsPedido.getDouble("graduacion_alcoholica"),
                                            rsItemsPedido.getBoolean("es_gaseosa"),
                                            rsItemsPedido.getDouble("volumen")
                                    ));
                                }

                                pedido.agregarADetalle(itemPedido);
                            }
                        }
                    }

                    // Total del pedido:
                    pedido.setTotal(rs.getDouble("total"));
                    pedidosFiltradosPorEstado.add(pedido);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al filtrar pedidos por estado: " + e.getMessage(), e);
        }

        if (pedidosFiltradosPorEstado.isEmpty()) {
            throw new ItemNoEncontradoException("No se encontraron pedidos con el estado " + estado + ".");
        }

        return pedidosFiltradosPorEstado;
    }

    // Metodo para obtener el ID real del ítem desde la base de datos:
    private int obtenerIdRealDelItem(Connection conn, String nombreItem) throws SQLException {
        String query = "SELECT id FROM items_menu WHERE nombre = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nombreItem);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");  // Retorna el ID real del ítem.
                } else {
                    throw new SQLException("Ítem no encontrado: " + nombreItem);
                }
            }
        }
    }

}