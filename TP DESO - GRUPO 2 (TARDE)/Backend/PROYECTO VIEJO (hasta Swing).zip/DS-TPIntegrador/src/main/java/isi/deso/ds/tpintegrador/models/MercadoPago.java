package isi.deso.ds.tpintegrador.models;

import java.time.LocalDateTime;

public class MercadoPago extends Pago {

    private String alias;

    // GETTERS Y SETTERS:

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    // CONSTRUCTORES:

    public MercadoPago() {
        super();
    }

    public MercadoPago(String id, String alias) {
        super(id);
        this.alias = alias;
    }

    public MercadoPago(String id, LocalDateTime fechaPago, String alias) {
        super(id, fechaPago);
        this.alias = alias;
    }

    // MÉTODOS DE CONSIGNA:

    @Override
    public double calcularRecargo(double total){
        return total * 1.04; // Le aplicamos el 4% de recargo.
    }
}
