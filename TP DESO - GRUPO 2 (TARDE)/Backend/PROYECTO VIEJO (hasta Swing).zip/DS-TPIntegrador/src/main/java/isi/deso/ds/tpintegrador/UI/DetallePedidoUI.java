package isi.deso.ds.tpintegrador.UI;

import java.awt.*;
import javax.swing.*;
import java.util.List;
import java.util.ArrayList;

import isi.deso.ds.tpintegrador.models.Pedido;
import isi.deso.ds.tpintegrador.models.ItemPedido;

public class DetallePedidoUI extends JDialog {
    private Pedido pedido; // Mantenemos una referencia al pedido.
    private PedidoUI pedidoUI; // Mantenemos una referencia a la interfaz de actualizacion.

    public DetallePedidoUI(Frame parent, Pedido pedido, PedidoUI pedidoUI) {
        super(parent, "DETALLE DE PEDIDO", true);
        this.pedido = pedido;
        this.pedidoUI = pedidoUI;

        // Configuramos el panel principal:
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // Cambiamos a BoxLayout para apilar verticalmente

        // Agregamos el título del pedido:
        JLabel tituloLabel = new JLabel("Detalle del Pedido " + pedido.getIdPedido() + ":");
        panel.add(tituloLabel);

        // Creamos un panel para los ítems:
        JPanel itemsPanel = new JPanel();
        itemsPanel.setLayout(new BoxLayout(itemsPanel, BoxLayout.Y_AXIS)); // Usar BoxLayout para ítems

        // Creamos un JCheckBox para cada ítem del pedido:
        List<JCheckBox> checkBoxes = new ArrayList<>();
        for (ItemPedido itemPedido : pedido.getPedidosDetalle()) {
            JCheckBox checkBox = new JCheckBox(itemPedido.getItemMenu().getNombre() +
                    " (Código: " + itemPedido.getCodigo() + ")");
            checkBox.setSelected(true);
            checkBoxes.add(checkBox);
            itemsPanel.add(checkBox);
        }

        // Creamos un JScrollPane y agregamos el panel de ítems a él:
        JScrollPane scrollPane = new JScrollPane(itemsPanel);
        scrollPane.setPreferredSize(new Dimension(280, 150));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        panel.add(scrollPane);

        // Creamos un panel para el botón "Guardar" y lo centramos:
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton guardarButton = new JButton("Guardar");

        guardarButton.addActionListener(e -> {
            double totalNuevo = 0.0;

            // Lista temporal para los ítems seleccionados
            ArrayList<ItemPedido> itemsSeleccionados = new ArrayList<>();

            // Recorremos los checkboxes para determinar cuáles están seleccionados:
            for (int i = 0; i < checkBoxes.size(); i++) {
                ItemPedido itemPedido = pedido.getPedidosDetalle().get(i);
                if (checkBoxes.get(i).isSelected()) {
                    itemsSeleccionados.add(itemPedido); // Añadimos el ítem a la lista de seleccionados.
                    totalNuevo += itemPedido.getItemMenu().getPrecio(); // Calculamos el total.
                }
            }

            // Actualizar el modelo del pedido
            pedido.setPedidoDetalle(itemsSeleccionados);
            pedido.setTotal(totalNuevo);

            // Persistir los cambios en la base de datos
            if (pedidoUI.getController().actualizarDetallePedido(pedido)) {
                JOptionPane.showMessageDialog(this, "Pedido actualizado correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar el pedido.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            // Actualizar la tabla en PedidoUI
            pedidoUI.actualizarTabla(pedido);

            dispose(); // Cerrar el diálogo
        });

        buttonPanel.add(guardarButton);

        // Agregamos el panel del botón al panel principal:
        panel.add(buttonPanel);

        // Configuramos la ventana
        add(panel);
        setSize(300, 200);
        setLocationRelativeTo(parent);
        setVisible(true);
    }
}
