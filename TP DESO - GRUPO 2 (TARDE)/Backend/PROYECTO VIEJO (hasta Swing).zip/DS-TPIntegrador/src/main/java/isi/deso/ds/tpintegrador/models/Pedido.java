package isi.deso.ds.tpintegrador.models;

import java.util.ArrayList;
import java.util.Observable;

import isi.deso.ds.tpintegrador.models.enums.Estado;

public class Pedido extends Observable {
    private String idPedido;
    private Cliente cliente;
    private ArrayList<ItemPedido> pedidosDetalle;
    private double total;
    private Pago formaDePago;
    private Estado estadoPedido;

    // GETTERS Y SETTERS:

    public String getIdPedido() {
            return idPedido;
    }

    public void setIdPedido(String idPedido) {
        this.idPedido = idPedido;
    }

    public Cliente getCliente() {
        return cliente;
    }
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    public ArrayList<ItemPedido> getPedidosDetalle() {
        return pedidosDetalle;
    }

    // El siguiente metodo 'setPedidoDetalle' no es necesario desde nuestra forma de implementacion, pero lo dejamos porque no esta de mas tener un metodo para ya pasarle un detalle completo y cargarlo a un pedido.
    public void setPedidoDetalle(ArrayList<ItemPedido> pedidoDetalle) {
        this.pedidosDetalle = pedidoDetalle;
    }

    // El siguiente metodo no haria falta dado que tenemos el metodo 'calcularTotal'.
    public double getTotal() {
        return total;
    }

    // El siguiente metodo 'setTotal' no es necesario desde nuestra forma de implementacion, pero lo dejamos porque no esta de mas tener un metodo para asignar el precio de un pedido si es que hay complicaciones o problemas por otro lado.
    public void setTotal(double total) {
        this.total = total;
    }

    public Pago getFormaDePago() {
        return formaDePago;
    }

    public void setFormaDePago(Pago formaDePago) {
        this.formaDePago = formaDePago;
    }

    public Estado getEstadoPedido() {
        return estadoPedido;
    }

    public void setEstadoPedido(Estado estadoPedido) {
        this.estadoPedido = estadoPedido;
    }

    // CONSTRUCTORES:

    public Pedido() {
    }

    public Pedido(String idPedido, Cliente cliente) {
        this.idPedido = idPedido;
        this.cliente = cliente;
        this.pedidosDetalle = new ArrayList<>();
        this.total = 0.0;
        this.estadoPedido = Estado.EN_PROCESO;
        // Esta incializacion con ese estado 'EN_PROCESO' es provisoria y no estara en el futuro. Esta hecha ya que, para los casos de uso de la etapa 3, no se les calcula
        // el total y, por consecuencia, no se les setea el estado 'RECIBIDO' (es decir, tienen todos estado NULL), lo cual nos da problemas con el metodo de filtrado por estado.

        this.addObserver(cliente);
    }

    // METODOS DE CONSIGNA:

    public void agregarADetalle(ItemPedido item){
        total += item.getItemMenu().getPrecio(); // Por cada item agregado a un detalle de un pedido, sumamos su precio para, eventualmente, obtener el precio total del pedido.
        this.pedidosDetalle.add(item);
    }

    public double calcularTotal(){

        double totalConRecargo = total;

        if(formaDePago != null){
            totalConRecargo = formaDePago.calcularRecargo(total);
        }

        return totalConRecargo;
    }

    public void cambiarEstadoPedido(){
        setEstadoPedido((Estado.EN_ENVIO));
        setChanged();
        notifyObservers();
    }

}
