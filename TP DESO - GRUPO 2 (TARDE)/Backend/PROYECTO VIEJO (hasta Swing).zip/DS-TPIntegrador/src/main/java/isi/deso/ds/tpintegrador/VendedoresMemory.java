package isi.deso.ds.tpintegrador;

import java.util.List;
import java.util.ArrayList;

import isi.deso.ds.tpintegrador.models.Vendedor;
import isi.deso.ds.tpintegrador.models.Coordenada;
import isi.deso.ds.tpintegrador.repository.VendedoresDAO;

public class VendedoresMemory implements VendedoresDAO {
    private List<Vendedor> vendedores = new ArrayList<>();

    public VendedoresMemory(){
        vendedores.add(vendedor1);
        vendedores.add(vendedor2);
        vendedores.add(vendedor3);
        vendedores.add(vendedor4);
        vendedores.add(vendedor5);
        vendedores.add(vendedor6);
        vendedores.add(vendedor7);
        vendedores.add(vendedor8);
    }

    @Override
    public List<Vendedor> listarVendedores() {
        return new ArrayList<>(vendedores);
    }

    @Override
    public boolean crearVendedor(Vendedor vendedor) {
        if (buscarVendedor(vendedor.getId()) == null) { // Verificar si el ID ya existe
            return vendedores.add(vendedor);
        }
        return false; // No se agregó porque el ID ya existe.

    }

    @Override
    public boolean actualizarVendedor(Vendedor vendedor) {
        Vendedor existente = buscarVendedor(vendedor.getId());
        if (existente != null) {
            existente.setNombre(vendedor.getNombre());
            existente.setDireccion(vendedor.getDireccion());
            existente.setCoordenadas(vendedor.getCoordenadas());
            return true;
        }
        return false;
    }

    @Override
    public boolean eliminarVendedor(String id) {
        Vendedor vendedor = buscarVendedor(id);
        if (vendedor != null) {
            return vendedores.remove(vendedor);
        }
        return false;
    }

    @Override
    public Vendedor buscarVendedor(String filtro) {
        for (Vendedor vendedor : vendedores) {
            if (vendedor.getId().equals(filtro)) {
                return vendedor;
            }
        }
        return null;
    }

    @Override
    public List<Vendedor> buscarVendedorPorParametro(String parametro, String valor) {
        List<Vendedor> resultado = new ArrayList<>();

        for (Vendedor vendedor : vendedores) {

            switch (parametro.toLowerCase()) {
                case "id":
                    if (vendedor.getId().equals(valor)) resultado.add(vendedor);
                    break;
                case "nombre":
                    if (vendedor.getNombre().equalsIgnoreCase(valor)) resultado.add(vendedor);
                    break;
                case "dirección":
                    if  (vendedor.getDireccion().toLowerCase().contains(valor.toLowerCase())) resultado.add(vendedor);
                    break;
            }
        }
        return resultado;
    }


    // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    // SIMULACION DE BASE DE DATOS DE VENDEDORES:

    // Ejemplos de Vendedores:
    Vendedor vendedor1 = new Vendedor("V001", "La Dominga", "Javier de la Rosa 101", new Coordenada(-34.603722, -58.381592));
    Vendedor vendedor2 = new Vendedor("V002", "El Nacional", "Ituzaingó 1090", new Coordenada(-34.6100, -58.3700));
    Vendedor vendedor3 = new Vendedor("V003", "Paprika", "San Martin 1707", new Coordenada(-34.6150, -58.3600));
    Vendedor vendedor4 = new Vendedor("V004", "Bilbao Amarras", "Calle 1º de Enero 27", new Coordenada(-34.6200, -58.3500));
    Vendedor vendedor5 = new Vendedor("V005", "Dr. Jekyll", "Marcial Candioti 3414", new Coordenada(-34.6250, -58.3400));
    Vendedor vendedor6 = new Vendedor("V006", "La Cabaña", "Av. Libertador 5900", new Coordenada(-34.6300, -58.3300));
    Vendedor vendedor7 = new Vendedor("V007", "El Almacén", "Calle Florida 102", new Coordenada(-34.6350, -58.3200));
    Vendedor vendedor8 = new Vendedor("V008", "La Terraza", "Belgrano 2001", new Coordenada(-34.6400, -58.3100));

}