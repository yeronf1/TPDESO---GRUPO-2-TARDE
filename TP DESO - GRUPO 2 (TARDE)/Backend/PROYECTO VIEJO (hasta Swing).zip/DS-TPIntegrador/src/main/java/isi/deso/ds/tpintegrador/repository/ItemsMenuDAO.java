package isi.deso.ds.tpintegrador.repository;

import java.util.List;

import isi.deso.ds.tpintegrador.models.ItemMenu;

public interface ItemsMenuDAO {

    List<ItemMenu> listarItemsMenu();
    boolean crearItemsMenu ( ItemMenu item);
    boolean actualizarItemsMenu(ItemMenu item);
    boolean eliminarItemsMenu(String id);
    ItemMenu buscarItemsMenu(String id);
    List<ItemMenu> buscarItemMenuporParametro(String parametro, String valor);

}