package isi.deso.ds.tpintegrador.models;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public abstract class Pago {

    private String id;
    private LocalDateTime fechaPago;

    public abstract double calcularRecargo(double total);

    // GETTERS Y SETTERS:

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFechaPago() {
        return fechaPago.format(DateTimeFormatter.ofPattern("dd/MM/yyyy - HH:mm:ss")); // Le damos un formato legible a la fecha del pago.
    }

    public void setFechaPago() {
        this.fechaPago = LocalDateTime.now();
    }

    // CONSTRUCTORES:

    public Pago(){
        this.fechaPago = LocalDateTime.now();
    }

    public Pago(String id) {
        this.id = id;
        this.fechaPago = LocalDateTime.now();
    }

    public Pago (String id, LocalDateTime fechaPago){
        this.id = id;
        this.fechaPago = fechaPago;
    }

}
