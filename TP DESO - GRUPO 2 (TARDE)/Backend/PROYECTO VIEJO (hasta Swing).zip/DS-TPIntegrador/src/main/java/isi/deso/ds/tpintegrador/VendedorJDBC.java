package isi.deso.ds.tpintegrador;

import java.util.List;
import java.util.ArrayList;
import java.sql.*;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import isi.deso.ds.tpintegrador.models.Vendedor;
import isi.deso.ds.tpintegrador.models.Coordenada;
import isi.deso.ds.tpintegrador.config.ConexionDB;
import isi.deso.ds.tpintegrador.repository.VendedoresDAO;

public class VendedorJDBC implements VendedoresDAO {

    @Override
    public List<Vendedor> listarVendedores() {
        List<Vendedor> vendedores = new ArrayList<>();
        String query = "SELECT * FROM vendedor";

        try (Connection conn = ConexionDB.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Vendedor vendedor = new Vendedor(
                        rs.getString("id"),
                        rs.getString("nombre"),
                        rs.getString("direccion"),
                        new Coordenada(rs.getDouble("lat"), rs.getDouble("lng"))
                );
                vendedores.add(vendedor);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar vendedores: " + e.getMessage());
            e.printStackTrace();
        } finally {
        // Opcionalmente, cerramos la conexión de forma explícita:
        ConexionDB.desconectar();
    }
        return vendedores;
    }

    @Override
    public boolean crearVendedor(Vendedor vendedor) {
        String query = "INSERT INTO vendedor (nombre, direccion, lat, lng) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConexionDB.conectar();
             // Solicitamos que se devuelvan las claves generadas:
             PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            // Seteamos los parámetros del PreparedStatement:
            pstmt.setString(1, vendedor.getNombre());
            pstmt.setString(2, vendedor.getDireccion());
            pstmt.setNull(3, java.sql.Types.DOUBLE);
            pstmt.setNull(4, java.sql.Types.DOUBLE);

            int affectedRows = pstmt.executeUpdate();

            // Verificamos si se ha insertado al menos una fila:
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        // Obtenemos el ID generado por la base de datos:
                        int idGenerado = generatedKeys.getInt(1);
                        // Convertimos el ID numérico a String con el formato "V001", "V002", etc.
                        vendedor.setId("V00" + idGenerado);
                        return true;  // Retornamos true si la inserción fue exitosa
                    }
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al crear vendedor: " + e.getMessage());
            e.printStackTrace();
        }
        return false; // Retornamos false si hubo algún error
    }


    @Override
    public boolean actualizarVendedor(Vendedor vendedor) {
        String query = "UPDATE vendedor SET nombre = ?, direccion = ?, lat = ?, lng = ? WHERE id = ?";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, vendedor.getNombre());
            pstmt.setString(2, vendedor.getDireccion());
            pstmt.setDouble(3, vendedor.getCoordenadas().getLAT());
            pstmt.setDouble(4, vendedor.getCoordenadas().getLNG());
            pstmt.setString(5, vendedor.getId());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("Error al modificar vendedor: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean eliminarVendedor(String id) {
        String query = "DELETE FROM vendedor WHERE id = ?";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, id);
            pstmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.err.println("Error al eliminar vendedor: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // ID O NOMBRE
    @Override
    public Vendedor buscarVendedor(String filtro) {
        String query = "SELECT * FROM vendedor WHERE id = ?";
        Vendedor vendedor = null;

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            // Establecemos el parámetro de la consulta:
            stmt.setString(1, filtro);

            try (ResultSet rs = stmt.executeQuery()) {
                // Verificamos si hay un resultado:
                if (rs.next()) {
                    // Creamos el objeto Cliente a partir del resultado:
                    vendedor = new Vendedor(
                            rs.getString("id"),
                            rs.getString("nombre"),
                            rs.getString("direccion"),
                            new Coordenada(rs.getDouble("lat"), rs.getDouble("lng"))
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar vendedor: " + e.getMessage());
            e.printStackTrace();
        }

        return vendedor;
    }

    @Override
    public List<Vendedor> buscarVendedorPorParametro(String parametro, String valor) {
        List<Vendedor> resultado = new ArrayList<>();

        // Generamos la consulta dinámica basada en el parámetro:
        String query;
        switch (parametro.toLowerCase()) {
            case "id":
                query = "SELECT * FROM vendedor WHERE id = ?";
                break;
            case "nombre":
                query = "SELECT * FROM vendedor WHERE LOWER(nombre) = LOWER(?)";
                break;
            case "dirección":
                query = "SELECT * FROM vendedor WHERE LOWER(direccion) LIKE LOWER(?)";
                valor = "%" + valor + "%";
                break;
            default:
                System.out.println("Parámetro no válido: " + parametro);
                return resultado; // Retornamos lista vacía si el parámetro no es válido.
        }

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            // Asignamos el valor del parámetro:
            stmt.setString(1, valor);

            try (ResultSet rs = stmt.executeQuery()) {
                // Procesamos el resultado:
                while (rs.next()) {
                    Vendedor vendedor = new Vendedor(
                            rs.getString("id"),
                            rs.getString("nombre"),
                            rs.getString("direccion"),
                            new Coordenada(rs.getDouble("lat"), rs.getDouble("lng"))
                    );
                    resultado.add(vendedor);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar vendedor por parámetro: " + e.getMessage());
            e.printStackTrace();
        }
        return resultado;
    }
}