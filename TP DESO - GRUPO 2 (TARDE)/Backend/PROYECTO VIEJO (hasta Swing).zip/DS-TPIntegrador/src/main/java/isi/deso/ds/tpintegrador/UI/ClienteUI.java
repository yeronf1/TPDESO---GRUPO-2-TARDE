package isi.deso.ds.tpintegrador.UI;

import java.awt.*;
import javax.swing.*;
import java.util.List;
import javax.swing.table.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import isi.deso.ds.tpintegrador.ClienteJDBC;
import isi.deso.ds.tpintegrador.models.Cliente;
import isi.deso.ds.tpintegrador.repository.ClienteDAO;
import isi.deso.ds.tpintegrador.controllers.ClienteController;

public class ClienteUI extends JFrame {

    private final ClienteController controller;
    private JTextField campoBusqueda;
    private JButton botonCrear;
    private JTable tablaClientes;
    private static DefaultTableModel modeloTabla;
    private JComboBox<String> comboBusqueda; // ComboBox para seleccionar el parámetro de búsqueda.

    // Clase main para ejecutar interfaz:
    public static void main(String[] args) {

        ClienteDAO clienteDAO = new ClienteJDBC();// Instanciamos un DAO asociado a su implementacion.
        ClienteController clienteController = new ClienteController(clienteDAO); // Instanciamos un controlador utilizando el DAO recien creado en su constructor.

        SwingUtilities.invokeLater(() -> {
            ClienteUI ui = new ClienteUI(clienteController); // Instanciamos la interfaz pasandole el controlador recien creado como argumento.
            ui.setVisible(true); // Hacemos visible la interfaz al usuario.
        });
    }

    public ClienteUI(ClienteController controller) {
        this.controller = controller;
        iniciarUI(); // Para inicializar la interfaz.
    }

    private void iniciarUI() {
        setTitle("Gestión de Clientes");
        setSize(1200, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Para centrar la ventana.

        // Configuración del Layout principal:
        setLayout(new BorderLayout());

        // Creamos y agregamos el menú lateral para moverse entre interfaces:
        JPanel menuLateral = MenuLateral.crearMenuLateral(this);
        add(menuLateral, BorderLayout.WEST);

        // Panel superior que contiene el título, botón de crear y buscador:
        JPanel panelSuperior = new JPanel(new BorderLayout());

        // Sub-panel para el título:
        JPanel panelTitulo = new JPanel();
        panelTitulo.setLayout(new BoxLayout(panelTitulo, BoxLayout.Y_AXIS));
        panelTitulo.setBackground(new Color(0x2169AC));
        panelTitulo.setPreferredSize(new Dimension(0, 50));

        JLabel tituloPrincipal = new JLabel("Lista de Clientes");
        tituloPrincipal.setForeground(Color.WHITE);
        tituloPrincipal.setFont(new Font("Arial", Font.BOLD, 18));
        tituloPrincipal.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Acomodamos el titlo en su panel (centrado):
        panelTitulo.add(Box.createVerticalGlue()); // Espacio flexible arriba.
        panelTitulo.add(tituloPrincipal);
        panelTitulo.add(Box.createVerticalGlue()); // Espacio flexible abajo.

        // Añadimos el titlePanel al lado superior del panel superior:
        panelSuperior.add(panelTitulo, BorderLayout.NORTH);

        // Sub-panel para el botón "Crear Nuevo Pedido" alineado a la izquierda:
        JPanel panelIzquierdo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelIzquierdo.setBorder(BorderFactory.createEmptyBorder(10, 88, 0, 0));

        botonCrear = new JButton("Crear nuevo cliente");
        botonCrear.setMargin(new Insets(0, 0, 0, 0)); // Le sacamos bordes internos al boton.
        panelIzquierdo.add(botonCrear); // Agregamos el boton al panel izquierdo.

        // Sub-panel para el campo 'buscador' alineado a la derecha:
        JPanel panelDerecho = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelDerecho.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel searchLabel = new JLabel("Buscador:");
        String[] criteriosBusqueda = {"ID", "Nombre", "CUIT", "Email", "Direccion"};
        comboBusqueda = new JComboBox<>(criteriosBusqueda);
        campoBusqueda = new JTextField(20);

        panelDerecho.add(searchLabel); // Agregamos el texto 'Buscador' al panel.
        panelDerecho.add(comboBusqueda); // Agregamos el selector combo de busqueda al panel.
        panelDerecho.add(campoBusqueda); // Agregamos el campo de busqueda al panel.

        // Añadimos los sub-paneles al panel superior:
        panelSuperior.add(panelIzquierdo, BorderLayout.WEST);
        panelSuperior.add(panelDerecho, BorderLayout.EAST);

        // Agregamos márgenes al panel superior para que coincida con los de la tabla:
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

        // Añadimos el panel superior al BorderLayout.NORTH del panel principal:
        add(panelSuperior, BorderLayout.NORTH);

        // Configuramos la tabla:
        String[] columnNames = {"ID", "Nombre", "Dirección", "Email", "CUIT", "Acción 1", "Acción 2"}; // Las acciones 1 y 2 corresponden a editar y eliminar respectivamente.
        modeloTabla = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5 || column == 6; // Hacemos que solo las celdas de editar y eliminar sean editables (presionables).
            }
        };

        tablaClientes = new JTable(modeloTabla); // Declaramos un nuevo panel de tabla con el modelo que creamos antes.
        tablaClientes.setRowHeight(30); // Le damos la altura que queremos a las filas de la tabla.

        // Configuramos la altura de la fila de los encabezados de las columnas:
        JTableHeader encabezado = tablaClientes.getTableHeader();
        encabezado.setPreferredSize(new Dimension(encabezado.getWidth(), 40));
        encabezado.setDefaultRenderer(new encabezadoPersonalizado());

        // Cambiamos el color de los bordes externos del encabezado para que coincida con el color de los bordes externos de la tabla:
        encabezado.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        // Establecemos el color de la cuadrícula y lo mostramos:
        tablaClientes.setGridColor(Color.BLACK);
        tablaClientes.setShowGrid(true);

        // Creamos un borde personalizado para la tabla:
        tablaClientes.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.BLACK, 2),
                BorderFactory.createEmptyBorder(0, 0, 2, 0)
        ));

        // Configuramos los anchos específicos para cada columna:
        tablaClientes.getColumnModel().getColumn(0).setPreferredWidth(30);
        tablaClientes.getColumnModel().getColumn(1).setPreferredWidth(150);
        tablaClientes.getColumnModel().getColumn(2).setPreferredWidth(100);
        tablaClientes.getColumnModel().getColumn(3).setPreferredWidth(100);
        tablaClientes.getColumnModel().getColumn(4).setPreferredWidth(100);
        tablaClientes.getColumnModel().getColumn(5).setPreferredWidth(120);
        tablaClientes.getColumnModel().getColumn(6).setPreferredWidth(120);

        // Creamos un renderizador para centrar todos los textos dentro de la tabla:
        DefaultTableCellRenderer renderizadoCentrado = new DefaultTableCellRenderer();
        renderizadoCentrado.setHorizontalAlignment(SwingConstants.CENTER);

        // Aplicamos el renderizador a todas las columnas:
        for (int i = 0; i < tablaClientes.getColumnCount(); i++) {
            tablaClientes.getColumnModel().getColumn(i).setCellRenderer(renderizadoCentrado);
        }

        // Añadimos boton de "Editar" en la columna de "Accion 1":
        tablaClientes.getColumn("Acción 1").setCellRenderer(new BotonRenderer());
        tablaClientes.getColumn("Acción 1").setCellEditor(new BotonEditor(new JCheckBox(), "Editar"));

        // Añadimos boton de "Eliminar" en la columna de "Accion 2":
        tablaClientes.getColumn("Acción 2").setCellRenderer(new BotonRenderer());
        tablaClientes.getColumn("Acción 2").setCellEditor(new BotonEditor(new JCheckBox(), "Eliminar"));

        // Le agregamos una barra de scroll a la tabla de clientes
        JScrollPane panelScroll = new JScrollPane(tablaClientes);
        panelScroll.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        add(panelScroll, BorderLayout.CENTER);

        // Creamos los listeners (de eventos) de los botones:
        assert botonCrear != null;
        botonCrear.addActionListener(e -> crearCliente());
        assert campoBusqueda != null;
        campoBusqueda.addActionListener(e -> buscarCliente());

        tablaClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = tablaClientes.rowAtPoint(evt.getPoint());
                int column = tablaClientes.columnAtPoint(evt.getPoint());
                if (column == 5) { // Columna "Editar"
                    editarCliente(row);
                } else if (column == 6) { // Columna "Eliminar"
                    eliminarCliente(row);
                }
            }
        });

        cargarDatosEnTabla();
    }

    // Metodo para cargar datos en la tabla al iniciar la interfaz:
     public void cargarDatosEnTabla() {

        modeloTabla.setRowCount(0); // Limpiamos tabla antes de cargar nuevos datos.

        // Obtenemos la lista de clientes del controlador y los añadimos a la tabla:
        for (Cliente cliente : controller.mostrarListaClientes()) {
            modeloTabla.addRow(new Object[]{
                    cliente.getId(),
                    cliente.getNombre(),
                    cliente.getDireccion(),
                    cliente.getEmail(),
                    cliente.getCuit(),
                    "Editar",
                    "Eliminar"
            });
        }
    }

    public void crearCliente() {
        JTextField nombreField = new JTextField();
        JTextField cuitField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField direccionField = new JTextField();

        Object[] message = {
                "Nombre:", nombreField,
                "CUIT:", cuitField,
                "Email:", emailField,
                "Dirección:", direccionField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Crear nuevo cliente", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String nombre = nombreField.getText().trim();
            String cuit = cuitField.getText().trim();
            String email = emailField.getText().trim();
            String direccion = direccionField.getText().trim();

            if (!nombre.isEmpty() && !cuit.isEmpty() && !email.isEmpty() && !direccion.isEmpty()) {
                Cliente nuevoCliente = new Cliente("C00" + (modeloTabla.getRowCount() + 1), nombre, cuit, email, direccion, null);
                controller.crearCliente(nuevoCliente);
                JOptionPane.showMessageDialog(this, "Cliente creado exitosamente.");
                cargarDatosEnTabla(); // Actualiza la tabla después de crear
            } else {
                JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            }
        }
    }

    public void editarCliente(int row) {
        String idCliente = (String) modeloTabla.getValueAt(row, 0);
        Cliente cliente = controller.buscarCliente(idCliente);

        if (cliente != null) {
            JTextField nombreField = new JTextField(cliente.getNombre());
            JTextField cuitField = new JTextField(cliente.getCuit());
            JTextField emailField = new JTextField(cliente.getEmail());
            JTextField direccionField = new JTextField(cliente.getDireccion());

            Object[] message = {
                    "Nombre:", nombreField,
                    "CUIT:", cuitField,
                    "Email:", emailField,
                    "Dirección:", direccionField
            };

            int option = JOptionPane.showConfirmDialog(this, message, "Editar cliente", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                cliente.setNombre(nombreField.getText().trim());
                cliente.setCuit(cuitField.getText().trim());
                cliente.setEmail(emailField.getText().trim());
                cliente.setDireccion(direccionField.getText().trim());
                if (controller.actualizarCliente(cliente)) {
                    JOptionPane.showMessageDialog(this, "Cliente editado exitosamente.");
                } else {
                    JOptionPane.showMessageDialog(this, "Error al editar el cliente.");
                }
                cargarDatosEnTabla(); // Actualizamos la tabla después de editar
            }
        }
    }

    public void eliminarCliente(int row) {
        String idCliente = (String) modeloTabla.getValueAt(row, 0); // Obtenemos el ID del cliente de la fila seleccionada.

        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Está seguro que desea eliminar este cliente?", "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (controller.eliminarCliente(idCliente)) {
                JOptionPane.showMessageDialog(this, "Cliente eliminado exitosamente.");
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar el cliente.");
            }

            cargarDatosEnTabla(); // Actualizamos la tabla después de eliminar.
        }
    }

    public void buscarCliente() {
        // Este metodo es para buscar clientes por cualquiera sea el dato querido:
        String filtro = campoBusqueda.getText().trim();
        String parametro = (String) comboBusqueda.getSelectedItem(); // Obtener el parámetro seleccionado

        // Si el campo de búsqueda está vacío, se restauran todos los clientes:
        if (filtro.isEmpty()) {
            cargarDatosEnTabla(); // Vuelve a cargar todos los clientes si no hay filtro.
            return; // Hecho eso, salimos del metodo.
        }

        // Si se ha ingresado un filtro de busqueda, se procede a buscar:
        assert parametro != null;
        List<Cliente> resultados = controller.buscarClientePorParametro(parametro.toLowerCase(), filtro);

        modeloTabla.setRowCount(0); // Limpiamos el modelo de la tabla actual para que solo se visualice el cliente encontrado.

        for (Cliente cliente : resultados) {

            // Añadimos el cliente encontrado al modelo de tabla y mostramos sus detalles:
            modeloTabla.addRow(new Object[]{
                    cliente.getId(),
                    cliente.getNombre(),
                    cliente.getDireccion(),
                    cliente.getEmail(),
                    cliente.getCuit(),
                    "Editar",
                    "Eliminar"
            });
        }

        if (resultados.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No se encontraron resultados.");
            cargarDatosEnTabla(); // Mostramos todos los clientes si no se encontraron resultados.
        }
    }

    // Clase interna para renderizado del encabezado de tablas:
    static class encabezadoPersonalizado extends DefaultTableCellRenderer {

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

            JLabel campo = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            campo.setHorizontalAlignment(JLabel.CENTER);
            campo.setOpaque(true);
            campo.setBackground(new Color(0x4C60A2)); // Fondo del encabezado
            campo.setForeground(Color.WHITE); // Color del texto

            // Cambiamos la fuente del texto de los encabezados:
            Font headerFont = new Font("Arial", Font.BOLD, 14);
            campo.setFont(headerFont); // Aplicamos la fuente al encabezado.

            // Establecemos color del borde del encabezado:
            campo.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, Color.BLACK));

            return campo;
        }
    }

    // Clase interna para renderizar botones
    static class BotonRenderer extends JButton implements TableCellRenderer {
        public BotonRenderer() {
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText(value == null ? "" : value.toString());
            return this;
        }
    }

    // Clase interna para manejar la acción de los botones:
    class BotonEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
        private final JButton boton;
        private final String tipoAccion; // Puede ser "Editar" o "Eliminar".
        private int filaSeleccionada;

        public BotonEditor(JCheckBox checkBox, String tipoAccion) {
            this.boton = new JButton();
            this.boton.addActionListener(this);
            this.tipoAccion = tipoAccion;
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.filaSeleccionada = row;
            boton.setText(value == null ? "" : value.toString());
            return boton;
        }

        @Override
        public Object getCellEditorValue() {
            return boton.getText();
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                switch (tipoAccion) {
                    case "Editar":
                        editarCliente(filaSeleccionada);
                        break;

                    case "Eliminar":
                        // Detener la edición activa antes de modificar el modelo
                        if (tablaClientes.isEditing()) {
                            tablaClientes.getCellEditor().stopCellEditing();
                        }
                        eliminarCliente(filaSeleccionada);
                        break;
                }
            } catch (IndexOutOfBoundsException ex) {
                System.err.println("Error de índice: " + ex.getMessage());
            } finally {
                fireEditingStopped(); // Nos aseguramos de que la edición se detenga después de la acción.
            }
        }

    }
}