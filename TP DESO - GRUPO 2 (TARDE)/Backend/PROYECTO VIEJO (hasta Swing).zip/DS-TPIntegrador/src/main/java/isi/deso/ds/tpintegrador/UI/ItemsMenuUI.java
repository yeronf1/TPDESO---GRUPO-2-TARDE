package isi.deso.ds.tpintegrador.UI;

import java.util.List;
import java.util.ArrayList;
import java.util.Objects;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import isi.deso.ds.tpintegrador.models.*;
import isi.deso.ds.tpintegrador.ItemsMenuJDBC;
import isi.deso.ds.tpintegrador.repository.ItemsMenuDAO;
import isi.deso.ds.tpintegrador.controllers.ItemsMenuController;

public class ItemsMenuUI extends JFrame {

    private ItemsMenuController controller;
    private JTextField campoBusqueda;
    private JButton botonCrear;
    private JTable tablaItemsMenu;
    private static DefaultTableModel modeloTabla;
    private JComboBox<String> comboBusqueda; // ComboBox para seleccionar el parámetro de búsqueda.

    // Clase main para ejecutar interfaz:
    public static void main(String[] args) {
        ItemsMenuDAO itemsMenuDAO = new ItemsMenuJDBC(); // Instanciamos un DAO asociado a su implementacion.
        ItemsMenuController itemsMenuController = new ItemsMenuController(itemsMenuDAO); // Instanciamos un controlador utilizando el DAO recien creado en su constructor.

        SwingUtilities.invokeLater(() -> {
            ItemsMenuUI ui = new ItemsMenuUI(itemsMenuController); // Instanciamos la interfaz pasandole el controlador recien creado como argumento.
            ui.setVisible(true); // Hacemos visible la interfaz al usuario.
        });
    }

    public ItemsMenuUI(ItemsMenuController controller) {
        this.controller = controller;
        iniciarUI();
        // loadTableData();
    }

    private void iniciarUI() {

        setTitle("Gestión de Items de menú");
        setSize(1600, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Para centrar la ventana.

        // Configuración del Layout principal:
        setLayout(new BorderLayout());

        // Creamos y agregamos el menú lateral para moverse entre interfaces:
        JPanel menuLateral = MenuLateral.crearMenuLateral(this);
        add(menuLateral,BorderLayout.WEST);

        // Panel superior que contiene el título, botón de crear y buscador:
        JPanel panelSuperior = new JPanel(new BorderLayout());

        // Sub-panel para el título:
        JPanel panelTitulo = new JPanel();
        panelTitulo.setLayout(new BoxLayout(panelTitulo, BoxLayout.Y_AXIS));
        panelTitulo.setBackground(new Color(0x2169AC));
        panelTitulo.setPreferredSize(new Dimension(0, 50));

        JLabel tituloPrincipal = new JLabel("Lista de Items de menú");
        tituloPrincipal.setForeground(Color.WHITE);
        tituloPrincipal.setFont(new Font("Arial", Font.BOLD, 18));
        tituloPrincipal.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Acomodamos el titlo en su panel (centrado):
        panelTitulo.add(Box.createVerticalGlue()); // Espacio flexible arriba.
        panelTitulo.add(tituloPrincipal);
        panelTitulo.add(Box.createVerticalGlue()); // Espacio flexible abajo.

        // Añadimos el titlePanel al lado superior del panel superior:
        panelSuperior.add(panelTitulo, BorderLayout.NORTH);

        // Sub-panel para el botón "Crear Nuevo vendedor" alineado a la izquierda:
        JPanel panelIzquierdo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelIzquierdo.setBorder(BorderFactory.createEmptyBorder(10, 88, 0, 0));

        botonCrear = new JButton("Crear nuevo ítem de menú");
        botonCrear.setMargin(new Insets(0, 0, 0, 0)); // Le sacamos bordes internos al boton.
        panelIzquierdo.add(botonCrear); // Agregamos el boton al panel izquierdo.

        // Sub-panel para el campo 'buscador' alineado a la derecha:
        JPanel panelDerecho = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelDerecho.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel searchLabel = new JLabel("Buscador:");
        String[] criteriosBusqueda = {"ID", "Nombre", "Categoria"};
        comboBusqueda = new JComboBox<>(criteriosBusqueda);
        campoBusqueda = new JTextField(20);

        panelDerecho.add(searchLabel); // Agregamos el texto 'Buscador' al panel.
        panelDerecho.add(comboBusqueda); // Agregamos el selector combo de busqueda al panel.
        panelDerecho.add(campoBusqueda); // Agregamos el campo de busqueda al panel.

        // Añadimos los sub-paneles al panel superior:
        panelSuperior.add(panelIzquierdo, BorderLayout.WEST);
        panelSuperior.add(panelDerecho, BorderLayout.EAST);

        // Agregamos márgenes al panel superior para que coincida con los de la tabla:
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

        // Añadimos el panel superior al BorderLayout.NORTH del panel principal:
        add(panelSuperior, BorderLayout.NORTH);

        // Configuramos la tabla:
        String[] columnNames = {"ID", "Nombre", "Categoría","Descripción", "Precio", "Grad. alcohólica (%)", "Volumen (ml)", "Calorías (cal)", "Peso (grs)", "¿Apto vegetariano?",
                "¿Apto celíaco?", "¿Es gaseosa?","Acción 1", "Acción 2"}; // Las acciones 1 y 2 corresponden a editar y eliminar respectivamente.
        modeloTabla = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 12 || column == 13; // Hacemos que solo las celdas de editar y eliminar sean editables (presionables).
            }
        };

        tablaItemsMenu = new JTable(modeloTabla); // Declaramos un nuevo panel de tabla con el modelo que creamos antes.
        tablaItemsMenu.setRowHeight(30); // Le damos la altura que queremos a las filas de la tabla.

        // Configuramos la altura de la fila de los encabezados de las columnas:
        JTableHeader encabezado = tablaItemsMenu.getTableHeader();
        encabezado.setPreferredSize(new Dimension(encabezado.getWidth(), 40));
        encabezado.setDefaultRenderer(new PedidoUI.encabezadoPersonalizado());

        // Cambiamos el color de los bordes externos del encabezado para que coincida con el color de los bordes externos de la tabla:
        encabezado.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        // Establecemos el color de la cuadrícula y lo mostramos:
        tablaItemsMenu.setGridColor(Color.BLACK);
        tablaItemsMenu.setShowGrid(true);

        // Creamos un borde personalizado para la tabla:
        tablaItemsMenu.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.BLACK, 2),
                BorderFactory.createEmptyBorder(0, 0, 2, 0)
        ));

        // Configuramos los anchos específicos para cada columna:
        tablaItemsMenu.getColumnModel().getColumn(0).setPreferredWidth(30);
        tablaItemsMenu.getColumnModel().getColumn(1).setPreferredWidth(150);
        tablaItemsMenu.getColumnModel().getColumn(2).setPreferredWidth(100);
        tablaItemsMenu.getColumnModel().getColumn(3).setPreferredWidth(130);
        tablaItemsMenu.getColumnModel().getColumn(4).setPreferredWidth(70);
        tablaItemsMenu.getColumnModel().getColumn(5).setPreferredWidth(140);
        tablaItemsMenu.getColumnModel().getColumn(6).setPreferredWidth(100);
        tablaItemsMenu.getColumnModel().getColumn(7).setPreferredWidth(100);
        tablaItemsMenu.getColumnModel().getColumn(8).setPreferredWidth(80);
        tablaItemsMenu.getColumnModel().getColumn(9).setPreferredWidth(140);
        tablaItemsMenu.getColumnModel().getColumn(10).setPreferredWidth(120);
        tablaItemsMenu.getColumnModel().getColumn(11).setPreferredWidth(90);
        tablaItemsMenu.getColumnModel().getColumn(12).setPreferredWidth(70);
        tablaItemsMenu.getColumnModel().getColumn(13).setPreferredWidth(70);

        // Creamos un renderizador para centrar todos los textos dentro de la tabla:
        DefaultTableCellRenderer renderizadoCentrado = new DefaultTableCellRenderer();
        renderizadoCentrado.setHorizontalAlignment(SwingConstants.CENTER);

        // Aplicamos el renderizador a todas las columnas:
        for (int i = 0; i < tablaItemsMenu.getColumnCount(); i++) {
            tablaItemsMenu.getColumnModel().getColumn(i).setCellRenderer(renderizadoCentrado);
        }

        // Añadimos boton de "Editar" en la columna de "Accion 1":
        tablaItemsMenu.getColumn("Acción 1").setCellRenderer(new BotonRenderer());
        tablaItemsMenu.getColumn("Acción 1").setCellEditor(new BotonEditor(new JCheckBox(), "Editar"));

        // Añadimos boton de "Eliminar" en la columna de "Accion 2":
        tablaItemsMenu.getColumn("Acción 2").setCellRenderer(new BotonRenderer());
        tablaItemsMenu.getColumn("Acción 2").setCellEditor(new BotonEditor(new JCheckBox(), "Eliminar"));

        // Le agregamos una barra de scroll a la tabla de vendedores:
        JScrollPane panelScroll = new JScrollPane(tablaItemsMenu);
        panelScroll.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        add(panelScroll, BorderLayout.CENTER);

        // Creamos los listeners (de eventos) de los botones:
        assert botonCrear != null;
        botonCrear.addActionListener(e -> crearItemMenu());

        assert campoBusqueda != null;
        campoBusqueda.addActionListener(e -> buscarItemMenu());

        tablaItemsMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = tablaItemsMenu.rowAtPoint(evt.getPoint());
                int column = tablaItemsMenu.columnAtPoint(evt.getPoint());
                if (column == 12) { // Columna "Editar".
                    editarItemMenu(row);
                } else if (column == 13) { // Columna "Eliminar".
                    eliminarItemMenu(row);
                }
            }
        });

        cargarDatosEnTabla();

    }

    // Metodo para cargar datos en la tabla al iniciar la interfaz:
    public void cargarDatosEnTabla() {
        modeloTabla.setRowCount(0); // Limpiamos tabla antes de cargar nuevos datos.

        // Obtenemos la lista de items menú del controlador y los añadimos a la tabla:
        for (ItemMenu itemMenu : controller.mostrarListaItemsMenu()) {
            Object[] rowData = new Object[14]; // Array para contener todos los datos de la fila.
            rowData[0] = itemMenu.getId();
            rowData[1] = itemMenu.getNombre();
            rowData[2] = itemMenu.getCategoria().getTipoItem();
            rowData[3] = itemMenu.getDescripcion();
            rowData[4] = "$" + itemMenu.getPrecio();

            // Comprobamos la categoría y agregamos los datos correspondientes
            if (itemMenu instanceof Plato) {
                Plato comida = (Plato) itemMenu; // Hacemos el casting
                rowData[5] = "-"; // Espacio para la graduación alcohólica (no tiene).
                rowData[6] = "-"; // Espacio para el volumen (no tiene).
                rowData[7] = comida.getCalorias();
                rowData[8] = comida.peso();
                rowData[9] = comida.aptoVegetariano() ? "Sí" : "No";
                rowData[10] = comida.getAptoCeliaco() ? "Sí" : "No";
                rowData[11] = "-";
            } else if (itemMenu instanceof Bebida) {
                Bebida bebida = (Bebida) itemMenu; // Hacemos el casting
                rowData[5] = ((Bebida) itemMenu).getGraduacionAlcoholica(); // Graduación alcohólica
                rowData[6] = bebida.getVolumen();
                rowData[7] = "-"; // Espacio para calorías (no tiene).
                rowData[8] = bebida.peso();
                rowData[9] = "Sí"; // Asumimos que todas las bebidas son vegetarianas.
                rowData[10] = "Sí"; // Asumimos que todas las bebidas son aptas para celíacos.
                rowData[11] = bebida.getEsGaseosa() ? "Sí" : "No";
            }

            // Añadimos las acciones de editar y eliminar:
            rowData[12] = "Editar";
            rowData[13] = "Eliminar";

            // Añadimos la fila a la tabla:
            modeloTabla.addRow(rowData);
        }
    }

    public void crearItemMenu() {
        JTextField nombreField = new JTextField(15);
        JTextField descripcionField = new JTextField(15);
        JTextField precioField = new JTextField(10);
        JTextField graduacionAlcoholicaField = new JTextField(10);
        JTextField volumenField = new JTextField(10);
        JTextField caloriasField = new JTextField(10);
        JTextField pesoField = new JTextField(10);

        JComboBox<String> categoriaComboBox = new JComboBox<>(new String[]{"COMIDA", "BEBIDA"});
        JComboBox<String> aptoVegetarianoComboBox = new JComboBox<>(new String[]{"Sí", "No"});
        JComboBox<String> aptoCeliacoComboBox = new JComboBox<>(new String[]{"Sí", "No"});
        JComboBox<String> esGaseosaComboBox = new JComboBox<>(new String[]{"Sí", "No"});

        // Panel principal con GridBagLayout (para más orden en la ventana):
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Campos generales:
        gbc.gridx = 0;
        gbc.gridy = 0;
        mainPanel.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(nombreField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        mainPanel.add(new JLabel("Categoría:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(categoriaComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        mainPanel.add(new JLabel("Descripción:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(descripcionField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        mainPanel.add(new JLabel("Precio:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(precioField, gbc);

        // Panel para campos específicos de "COMIDA":
        JPanel comidaPanel = new JPanel(new GridBagLayout());
        gbc.gridx = 0;
        gbc.gridy = 0;
        comidaPanel.add(new JLabel("Calorías (cal):"), gbc);
        gbc.gridx = 1;
        comidaPanel.add(caloriasField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        comidaPanel.add(new JLabel("Peso (grs):"), gbc);
        gbc.gridx = 1;
        comidaPanel.add(pesoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        comidaPanel.add(new JLabel("¿Apto vegetariano?"), gbc);
        gbc.gridx = 1;
        comidaPanel.add(aptoVegetarianoComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        comidaPanel.add(new JLabel("¿Apto celíaco?"), gbc);
        gbc.gridx = 1;
        comidaPanel.add(aptoCeliacoComboBox, gbc);

        // Panel para campos específicos de "BEBIDA":
        JPanel bebidaPanel = new JPanel(new GridBagLayout());
        gbc.gridx = 0;
        gbc.gridy = 0;
        bebidaPanel.add(new JLabel("Graduación Alcohólica (%):"), gbc);
        gbc.gridx = 1;
        bebidaPanel.add(graduacionAlcoholicaField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        bebidaPanel.add(new JLabel("Volumen (ml):"), gbc);
        gbc.gridx = 1;
        bebidaPanel.add(volumenField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        bebidaPanel.add(new JLabel("¿Es gaseosa?"), gbc);
        gbc.gridx = 1;
        bebidaPanel.add(esGaseosaComboBox, gbc);

        // Añadimos los paneles específicos, inicialmente ocultando el de bebidas:
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        mainPanel.add(comidaPanel, gbc);
        mainPanel.add(bebidaPanel, gbc);
        comidaPanel.setVisible(true);
        bebidaPanel.setVisible(false);

        // Listener para mostrar/ocultar paneles según categoría seleccionada:
        categoriaComboBox.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                boolean esComida = "COMIDA".equals(categoriaComboBox.getSelectedItem());
                comidaPanel.setVisible(esComida);
                bebidaPanel.setVisible(!esComida);
                mainPanel.revalidate();
                mainPanel.repaint();
            }
        });

        // Cuadro de diálogo para la creación de ítem:
        int option = JOptionPane.showConfirmDialog(this, mainPanel, "Crear nuevo ítem de menú", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String nombre = nombreField.getText().trim();
            String descripcion = descripcionField.getText().trim();
            String precioText = precioField.getText().trim();
            String graduacionAlcoholicaText = graduacionAlcoholicaField.getText().trim();
            String volumenText = volumenField.getText().trim();
            String caloriasText = caloriasField.getText().trim();
            String pesoText = pesoField.getText().trim();

            // Validación de campos numéricos:
            try {
                double precio = Double.parseDouble(precioText);
                double graduacionAlcoholica = graduacionAlcoholicaText.isEmpty() ? 0 : Double.parseDouble(graduacionAlcoholicaText);
                double volumen = volumenText.isEmpty() ? 0 : Double.parseDouble(volumenText);
                int calorias = caloriasText.isEmpty() ? 0 : Integer.parseInt(caloriasText);
                double peso = pesoText.isEmpty() ? 0 : Double.parseDouble(pesoText);

                if (!nombre.isEmpty() && !descripcion.isEmpty() && !precioText.isEmpty() && categoriaComboBox.getSelectedItem() != null) {
                    String categoria = (String) categoriaComboBox.getSelectedItem();
                    boolean esVegetariano = Objects.equals(aptoVegetarianoComboBox.getSelectedItem(), "Sí");
                    boolean esCeliaco = Objects.equals(aptoCeliacoComboBox.getSelectedItem(), "Sí");
                    boolean esGaseosa = Objects.equals(esGaseosaComboBox.getSelectedItem(), "Sí");

                    if (categoria.equals("COMIDA")) {
                        Plato nuevoItemMenu = new Plato("IMC00" + (modeloTabla.getRowCount() + 1), nombre, descripcion, precio, peso, calorias, esCeliaco, esVegetariano);
                        controller.crearNuevoItemsMenu(nuevoItemMenu);
                    } else if (categoria.equals("BEBIDA")) {
                        Bebida nuevoItemMenu = new Bebida("IMB00" + (modeloTabla.getRowCount() + 1), nombre, descripcion, precio, graduacionAlcoholica, esGaseosa, volumen);
                        controller.crearNuevoItemsMenu(nuevoItemMenu);
                    }

                    JOptionPane.showMessageDialog(this, "Ítem de menú creado exitosamente.");
                    cargarDatosEnTabla();
                } else {
                    JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos de texto obligatorios.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Asegúrese de que los campos de precio, graduación alcohólica, volumen, calorías y peso sean numéricos.");
            }
        }
    }

    public void editarItemMenu(int row) {
        String idItemMenu = (String) modeloTabla.getValueAt(row, 0);
        ItemMenu itemMenu = controller.buscarItemsMenu(idItemMenu);

        if (itemMenu != null) {
            // Creamos campos de texto para cada atributo que se desea editar:
            JTextField nombreField = new JTextField(itemMenu.getNombre());
            JTextField descripcionField = new JTextField(itemMenu.getDescripcion());
            JTextField precioField = new JTextField(String.valueOf(itemMenu.getPrecio()));

            // Creamos checkboxes y campos de texto que se usarán luego según la categoría del item.
            JCheckBox aptoVegetarianoCheckBox = null;
            JCheckBox aptoCeliacoCheckBox = null;
            JCheckBox esGaseosaCheckBox = null;
            JTextField caloriasField = null;
            JTextField pesoField = null;
            JTextField graduacionAlcoholicaField = null;
            JTextField volumenField = null;

            // Creamos un ArrayList para los componentes del diálogo:
            java.util.List<Object> message = new ArrayList<>();
            message.add("Nombre:");
            message.add(nombreField);
            message.add("Descripción:");
            message.add(descripcionField);
            message.add("Precio:");
            message.add(precioField);

            // Comprobamos la categoría para mostrar los campos específicos:
            if (itemMenu instanceof Plato) { // Si es de tipo comida.
                aptoVegetarianoCheckBox = new JCheckBox("Apto Vegetariano", ((Plato) itemMenu).aptoVegetariano());
                aptoCeliacoCheckBox = new JCheckBox("Apto Celiaco", ((Plato) itemMenu).getAptoCeliaco());
                caloriasField = new JTextField(String.valueOf(((Plato) itemMenu).getCalorias()));
                pesoField = new JTextField(String.valueOf(((Plato) itemMenu).peso()));

                message.add("Calorías:");
                message.add(caloriasField);
                message.add("Peso:");
                message.add(pesoField);
                message.add(aptoVegetarianoCheckBox);
                message.add(aptoCeliacoCheckBox);


            } else if (itemMenu instanceof Bebida) { // Si es de tipo bebida.
                esGaseosaCheckBox = new JCheckBox("Es Gaseosa", ((Bebida) itemMenu).getEsGaseosa());
                graduacionAlcoholicaField = new JTextField(String.valueOf(((Bebida) itemMenu).getGraduacionAlcoholica()));
                volumenField = new JTextField(String.valueOf(((Bebida) itemMenu).getVolumen()));

                message.add("Graduación Alcohólica:");
                message.add(graduacionAlcoholicaField);
                message.add("Volumen:");
                message.add(volumenField);
                message.add(esGaseosaCheckBox);
            }

            int option = JOptionPane.showConfirmDialog(this, message.toArray(), "Editar ítem menú", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                // Actualizar los atributos del itemMenu con los valores ingresados:
                itemMenu.setNombre(nombreField.getText().trim());
                itemMenu.setDescripcion(descripcionField.getText().trim());

                // Manejo de la conversión del precio:
                try {
                    double precio = Double.parseDouble(precioField.getText().trim());
                    itemMenu.setPrecio(precio);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "El precio debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; // Salir si hay error en el precio.
                }

                // Actualizar los valores específicos según la categoría:
                if (itemMenu instanceof Plato) {
                    ((Plato) itemMenu).setAptoVegetariano(aptoVegetarianoCheckBox.isSelected());
                    ((Plato) itemMenu).setAptoCeliaco(aptoCeliacoCheckBox.isSelected());

                    try {
                        int calorias = Integer.parseInt(caloriasField.getText().trim());
                        ((Plato) itemMenu).setCalorias(calorias);
                        double peso = Double.parseDouble(pesoField.getText().trim());
                        ((Plato) itemMenu).setPeso(peso);
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(this, "Las calorías y el peso deben ser valores numéricos válidos.", "Error", JOptionPane.ERROR_MESSAGE);
                        return; // Salir si hay error en calorías o peso.
                    }

                } else if (itemMenu instanceof Bebida) {
                    ((Bebida) itemMenu).setEsGaseosa(esGaseosaCheckBox.isSelected());

                    try {
                        double graduacionAlcoholica = Double.parseDouble(graduacionAlcoholicaField.getText().trim());
                        ((Bebida) itemMenu).setGraduacionAlcoholica(graduacionAlcoholica);
                        double volumen = Double.parseDouble(volumenField.getText().trim());
                        ((Bebida) itemMenu).setVolumen(volumen);
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(this, "La graduación alcohólica y el volumen deben ser valores numéricos válidos.", "Error", JOptionPane.ERROR_MESSAGE);
                        return; // Salir si hay error en graduación o volumen.
                    }
                }

                // Actualizar en el controlador
                if (controller.actualizarItemMenu(itemMenu)) {
                    JOptionPane.showMessageDialog(this, "Ítem editado exitosamente.");
                } else {
                    JOptionPane.showMessageDialog(this, "Error al editar el ítem.");
                }
                cargarDatosEnTabla(); // Actualizamos la tabla después de editar.
            }
        } else {
            JOptionPane.showMessageDialog(this, "Ítem no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void eliminarItemMenu(int row) {
        String idItemMenu = (String) modeloTabla.getValueAt(row, 0); // Obtenemos el ID del item de la fila seleccionada.

        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Está seguro que desea eliminar este ítem?", "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (controller.eliminarItemsMenu(idItemMenu)) {
                JOptionPane.showMessageDialog(this, "ítem eliminado exitosamente.");
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar el ítem.");
            }
            cargarDatosEnTabla(); // Actualizamos la tabla después de eliminar.
        }
    }

    public void buscarItemMenu() {
        // Este metodo es para buscar items del menú por cualquiera sea el dato querido:
        String filtro = campoBusqueda.getText().trim();
        String parametro = (String) comboBusqueda.getSelectedItem(); // Obtener el parámetro seleccionado

        // Si el campo de búsqueda está vacío, se restauran todos los ítems del menú:
        if (filtro.isEmpty()) {
            cargarDatosEnTabla(); // Vuelve a cargar todos los ítems del menú si no hay filtro.
            return; // Hecho eso, salimos del metodo.
        }

        // Si se ha ingresado un filtro de busqueda, se procede a buscar:
        assert parametro != null;
        List<ItemMenu> resultados = controller.buscarItemMenuporParametro(parametro.toLowerCase(), filtro);

        modeloTabla.setRowCount(0); // Limpiamos el modelo de la tabla actual para que solo se visualice el ítem encontrado.

        for (ItemMenu itemMenu : resultados) {
            // Añadimos el ítem encontrado al modelo de tabla y mostramos todos sus detalles:
            modeloTabla.addRow(new Object[]{
                    itemMenu.getId(),
                    itemMenu.getNombre(),
                    itemMenu.getCategoria().getTipoItem(),
                    itemMenu.getDescripcion(),
                    "$" + itemMenu.getPrecio(),
                    itemMenu instanceof Bebida ? ((Bebida) itemMenu).getGraduacionAlcoholica() : "-", // Graduación alcohólica, solo si es una Bebida.
                    itemMenu instanceof Bebida ? ((Bebida) itemMenu).getVolumen() : "-", // Volumen, solo si es una Bebida.
                    itemMenu instanceof Plato ? ((Plato) itemMenu).getCalorias() : "-", // Calorías, solo si es un Plato.
                    itemMenu instanceof Plato ? ((Plato) itemMenu).peso() : "-", // Peso, solo si es un Plato.
                    itemMenu.aptoVegetariano() ? "Sí" : "No", // Aptos vegetarianos.
                    itemMenu instanceof Plato ? (((Plato) itemMenu).getAptoCeliaco() ? "Sí" : "No") : "-", // Aptos celiacos sólo para comidas.
                    itemMenu instanceof Bebida ? (((Bebida) itemMenu).getEsGaseosa() ? "Sí" : "No") : "-", // Es gaseosa, solo si es una bebida.
                    "Editar",
                    "Eliminar"
            });
        }

        if (resultados.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No se encontraron resultados.");
            cargarDatosEnTabla(); // Mostramos todos los ítems del menú si no se encontraron resultados.
        }
    }

    // Clase interna para renderizado del encabezado de tablas:
    static class encabezadoPersonalizado extends DefaultTableCellRenderer {

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

            JLabel campo = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            campo.setHorizontalAlignment(JLabel.CENTER);
            campo.setOpaque(true);
            campo.setBackground(new Color(0x4C60A2)); // Fondo del encabezado
            campo.setForeground(Color.WHITE); // Color del texto

            // Cambiamos la fuente del texto de los encabezados:
            Font headerFont = new Font("Arial", Font.BOLD, 14);
            campo.setFont(headerFont); // Aplicamos la fuente al encabezado.

            // Establecemos color del borde del encabezado:
            campo.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, Color.BLACK));

            return campo;
        }
    }

    // Clase interna para renderizar botones
    static class BotonRenderer extends JButton implements TableCellRenderer {
        public BotonRenderer() {
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText(value == null ? "" : value.toString());
            return this;
        }
    }

    // Clase interna para manejar la acción de los botones:
    class BotonEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
        private final JButton boton;
        private final String tipoAccion; // Puede ser "Editar" o "Eliminar".
        private int filaSeleccionada;

        public BotonEditor(JCheckBox checkBox, String tipoAccion) {
            this.boton = new JButton();
            this.boton.addActionListener(this);
            this.tipoAccion = tipoAccion;
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.filaSeleccionada = row;
            boton.setText(value == null ? "" : value.toString());
            return boton;
        }

        @Override
        public Object getCellEditorValue() {
            return boton.getText();
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            switch (tipoAccion) {
                case "Editar":
                    //editarVendedor(filaSeleccionada);
                    break;

                case "Eliminar":
                    //eliminarVendedor(filaSeleccionada);
                    break;
            }
            fireEditingStopped(); // Termina la edición para que se actualice la tabla.
        }
    }
}