package isi.deso.ds.tpintegrador;
import isi.deso.ds.tpintegrador.models.*;
import isi.deso.ds.tpintegrador.repository.ItemsMenuDAO;

import java.util.ArrayList;
import java.util.List;

public class ItemsMenuMemory implements ItemsMenuDAO {
    private static List<ItemMenu> itemsMenu = new ArrayList<>();

    public ItemsMenuMemory() {
        itemsMenu.add(bebida1);
        itemsMenu.add(bebida2);
        itemsMenu.add(bebida3);
        itemsMenu.add(bebida4);
        itemsMenu.add(bebida5);
        itemsMenu.add(bebida6);
        itemsMenu.add(bebida7);
        itemsMenu.add(bebida8);
        itemsMenu.add(bebida9);
        itemsMenu.add(bebida10);
        itemsMenu.add(bebida11);
        itemsMenu.add(bebida12);
        itemsMenu.add(bebida13);
        itemsMenu.add(bebida14);
        itemsMenu.add(bebida15);
        itemsMenu.add(bebida16);

        itemsMenu.add(plato1);
        itemsMenu.add(plato2);
        itemsMenu.add(plato3);
        itemsMenu.add(plato4);
        itemsMenu.add(plato5);
        itemsMenu.add(plato6);
        itemsMenu.add(plato7);
        itemsMenu.add(plato8);
        itemsMenu.add(plato9);
        itemsMenu.add(plato10);
        itemsMenu.add(plato11);
        itemsMenu.add(plato12);
        itemsMenu.add(plato13);
        itemsMenu.add(plato14);
        itemsMenu.add(plato15);
        itemsMenu.add(plato16);

    }

    @Override
    public List<ItemMenu> listarItemsMenu() {
        return itemsMenu;
    }

    @Override
    public boolean crearItemsMenu(ItemMenu item) {
        if (buscarItemsMenu(item.getId()) == null) { // Verificar si el ID ya existe
            return itemsMenu.add(item);
        }
        return false; // No se agregó porque el ID ya existe
    }

    @Override
    public boolean actualizarItemsMenu(ItemMenu item) {
        ItemMenu existente = buscarItemsMenu(item.getId());
        if (existente != null) {
            existente.setNombre(item.getNombre());
            existente.setDescripcion(item.getDescripcion());
            existente.setPrecio(item.getPrecio());

            // Verifica la categoría y actualiza los atributos específicos
            if (existente instanceof Plato && item instanceof Plato) {
                Plato platoExistente = (Plato) existente;
                Plato platoNuevo = (Plato) item;
                platoExistente.setCalorias(platoNuevo.getCalorias());
                platoExistente.setPeso(platoNuevo.peso());
                platoExistente.setAptoCeliaco(platoNuevo.getAptoCeliaco());
                platoExistente.setAptoVegetariano(platoNuevo.getAptoVegetariano());
            } else if (existente instanceof Bebida && item instanceof Bebida) {
                Bebida bebidaExistente = (Bebida) existente;
                Bebida bebidaNueva = (Bebida) item;
                bebidaExistente.setGraduacionAlcoholica(bebidaNueva.getGraduacionAlcoholica());
                bebidaExistente.setEsGaseosa(bebidaNueva.getEsGaseosa());
                bebidaExistente.setVolumen(bebidaNueva.getVolumen());
            }

            return true;
        }
        return false;
    }

    @Override
    public boolean eliminarItemsMenu(String id) {
        ItemMenu itemMenu = buscarItemsMenu(id);
        if (itemMenu != null) {
            return itemsMenu.remove(itemMenu);
        }
        return false;
    }

    @Override
    public ItemMenu buscarItemsMenu(String id) {
        for (ItemMenu item : itemsMenu) {
            if (item.getId().equals(id)) {
                return item;
            }
        }
        return null;
    }

    @Override
    public List<ItemMenu> buscarItemMenuporParametro(String parametro, String valor) {
        List<ItemMenu> resultado = new ArrayList<>();

        for (ItemMenu itemMenu : itemsMenu) {

            switch (parametro.toLowerCase()) {
                case "id":
                    if (itemMenu.getId().equalsIgnoreCase(valor)) resultado.add(itemMenu);
                    break;
                case "nombre":
                    if (itemMenu.getNombre().equalsIgnoreCase(valor)) resultado.add(itemMenu);
                    break;
                case "categoría":
                    if (itemMenu.getCategoria().getTipoItem().toString().equals(valor)) resultado.add(itemMenu);
                    break;
            }
        }
        return resultado;
    }

    // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    // SIMULACION DE BASE DE DATOS DE ITEMS MENÚ:

    // Ejemplos de Bebidas:
    Bebida bebida1 = new Bebida("IMB001", "Agua Mineral", "Descripción", 1200, 0.0, false, 500);
    Bebida bebida2 = new Bebida("IMB002", "Jugo de Pomelo", "Descripción", 1800, 0.0, true, 610);
    Bebida bebida3 = new Bebida("IMB003", "Whisky", "Descripción", 20000, 55, false, 920);
    Bebida bebida4 = new Bebida("IMB004", "Cerveza negra", "Descripción", 700, 7.5, false, 250);
    Bebida bebida5 = new Bebida("IMB005", "Fernet", "Descripción", 12000, 45, false, 750);
    Bebida bebida6 = new Bebida("IMB006", "Coca Cola", "Descripción", 850, 0.0, true, 600);
    Bebida bebida7 = new Bebida("IMB007", "Ron Blanco", "Descripción", 15000, 40, false, 700);
    Bebida bebida8 = new Bebida("IMB008", "Limonada Casera", "Descripción", 1200, 0.0, false, 500);
    Bebida bebida9 = new Bebida("IMB009", "Cerveza IPA", "Descripción", 950, 5.0, false, 473);
    Bebida bebida10 = new Bebida("IMB0010", "Gaseosa de Naranja", "Descripción", 700, 0.0, true, 500);
    Bebida bebida11 = new Bebida("IMB0011", "Gin Tonic", "Descripción", 18000, 37.5, false, 750);
    Bebida bebida12 = new Bebida("IMB0012", "Sidra Espumante", "Descripción", 2200, 4.5, false, 750);
    Bebida bebida13 = new Bebida("IMB0013", "Agua Tónica", "Descripción", 900, 0.0, true, 350);
    Bebida bebida14 = new Bebida("IMB0014", "Vino Malbec", "Descripción", 25000, 13.5, false, 750);
    Bebida bebida15 = new Bebida("IMB0015", "Vodka", "Descripción", 18000, 40, false, 700);
    Bebida bebida16 = new Bebida("IMB0016", "Ron con Coca", "Descripción", 9000, 35, true, 500);

    // Ejemplos de Platos:
    Plato plato1 = new Plato("IMC001", "Pizza Napolitana", "Descripción", 10500, 2000, 1899, false, true);
    Plato plato2 = new Plato("IMC002", "Sorrentinos de 4 quesos", "Descripción", 9350, 750, 1500, false, true);
    Plato plato3 = new Plato("IMC003", "Matambre a la pizza", "Descripción", 12150, 1200, 1050, true, false);
    Plato plato4 = new Plato("IMC004", "Sushi", "Descripción", 12000, 500, 850, false, false);
    Plato plato5 = new Plato("IMC005", "Helado de Dulce de Leche", "Descripción", 5700, 1000, 2400, false, true);
    Plato plato6 = new Plato("IMC006", "Lasaña de Espinaca", "Descripción", 8500, 800, 950, false, true);
    Plato plato7 = new Plato("IMC007", "Bife de Chorizo con Papas", "Descripción", 18500, 1500, 1200, true, false);
    Plato plato8 = new Plato("IMC008", "Ensalada César", "Descripción", 5000, 400, 600, true, true);
    Plato plato9 = new Plato("IMC009", "Risotto de Hongos", "Descripción", 11000, 650, 850, false, true);
    Plato plato10 = new Plato("IMC0010", "Pollo al Champiñón", "Descripción", 12750, 900, 1050, true, false);
    Plato plato11 = new Plato("IMC0011", "Tarta de Verduras", "Descripción", 6000, 700, 750, false, true);
    Plato plato12 = new Plato("IMC0012", "Empanadas de Carne", "Descripción", 4000, 500, 650, false, false);
    Plato plato13 = new Plato("IMC0013", "Hamburguesa Vegana", "Descripción", 9500, 450, 800, true, true);
    Plato plato14 = new Plato("IMC0014", "Papas Fritas con Cheddar", "Descripción", 3700, 300, 500, false, true);
    Plato plato15 = new Plato("IMC0015", "Brownie con Helado", "Descripción", 5700, 250, 1200, false, true);
    Plato plato16 = new Plato("IMC0016", "Chinchulines a la mostaza", "Descripción", 8000, 1450, 1400, true, false);
}