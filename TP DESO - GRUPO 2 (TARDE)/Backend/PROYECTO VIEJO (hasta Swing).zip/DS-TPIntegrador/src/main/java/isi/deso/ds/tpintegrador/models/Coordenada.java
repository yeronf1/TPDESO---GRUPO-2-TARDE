package isi.deso.ds.tpintegrador.models;

public class Coordenada {

    private double lat;
    private double lng;

    // GETTERS Y SETTERS:

    public double getLAT(){
        return lat;
    }

    public void setLAT(double LAT){
        lat = LAT;
    }

    public double getLNG(){
        return lng;
    }

    public void setLNG(double LNG){
        lng = LNG;
    }

    // CONSTRUCTORES:

    public Coordenada(){
    }

    public Coordenada(double x, double y){
        lng = x;
        lat = y;
    }
}