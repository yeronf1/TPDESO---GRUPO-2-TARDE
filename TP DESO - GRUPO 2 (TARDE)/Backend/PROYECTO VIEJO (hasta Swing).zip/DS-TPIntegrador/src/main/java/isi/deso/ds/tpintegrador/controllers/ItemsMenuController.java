package isi.deso.ds.tpintegrador.controllers;

import java.util.List;

import isi.deso.ds.tpintegrador.models.ItemMenu;
import isi.deso.ds.tpintegrador.repository.ItemsMenuDAO;

public class ItemsMenuController {

    private final ItemsMenuDAO itemsMenuDAO;

    public ItemsMenuController(ItemsMenuDAO itemsMenuDAO) {
        this.itemsMenuDAO = itemsMenuDAO;
    }

    public List<ItemMenu> mostrarListaItemsMenu() {
        return itemsMenuDAO.listarItemsMenu();
    }

    public boolean crearNuevoItemsMenu(ItemMenu item) {
        return itemsMenuDAO.crearItemsMenu(item);
    }

    public boolean actualizarItemMenu(ItemMenu item) {
        return itemsMenuDAO.actualizarItemsMenu(item);
    }

    public boolean eliminarItemsMenu(String id) {
        return itemsMenuDAO.eliminarItemsMenu(id);
    }

    public ItemMenu buscarItemsMenu(String id) {
        return itemsMenuDAO.buscarItemsMenu(id);
    }

    public List<ItemMenu> buscarItemMenuporParametro(String parametro, String valor) {
        return itemsMenuDAO.buscarItemMenuporParametro(parametro, valor);
    }

}