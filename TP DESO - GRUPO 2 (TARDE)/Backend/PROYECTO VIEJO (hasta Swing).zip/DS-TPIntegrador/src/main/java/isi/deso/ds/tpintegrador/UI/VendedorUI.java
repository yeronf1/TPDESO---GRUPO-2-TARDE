package isi.deso.ds.tpintegrador.UI;

import java.awt.*;
import javax.swing.*;
import java.util.List;
import java.util.Random;
import javax.swing.table.*;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import isi.deso.ds.tpintegrador.VendedorJDBC;
import isi.deso.ds.tpintegrador.models.Vendedor;
import isi.deso.ds.tpintegrador.models.Coordenada;
import isi.deso.ds.tpintegrador.controllers.VendedoresController;
import isi.deso.ds.tpintegrador.repository.VendedoresDAO;

public class VendedorUI extends JFrame {

    private VendedoresController controller;
    private JTextField campoBusqueda;
    private JButton botonCrear;
    private JTable tablaVendedores;
    private static DefaultTableModel modeloTabla;
    private JComboBox<String> comboBusqueda; // ComboBox para seleccionar el parámetro de búsqueda.

    // Clase main para ejecutar interfaz:
    public static void main(String[] args) {
        VendedoresDAO vendedoresDAO = new VendedorJDBC(); // Instanciamos un DAO asociado a su implementacion.
        VendedoresController vendedoresController = new VendedoresController(vendedoresDAO); // Instanciamos un controlador utilizando el DAO recien creado en su constructor.

        SwingUtilities.invokeLater(() -> {
            VendedorUI ui = new VendedorUI(vendedoresController); // Instanciamos la interfaz pasandole el controlador recien creado como argumento.
            ui.setVisible(true); // Hacemos visible la interfaz al usuario.
        });
    }

    public VendedorUI(VendedoresController controller) {
        this.controller = controller;
        iniciarUI();
    }

    private void iniciarUI() {

        setTitle("Gestión de Vendedores");
        setSize(1200, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Para centrar la ventana.

        // Configuración del Layout principal:
        setLayout(new BorderLayout());

        // Creamos y agregamos el menú lateral para moverse entre interfaces:
        JPanel menuLateral = MenuLateral.crearMenuLateral(this);
        add(menuLateral,BorderLayout.WEST);

        // Panel superior que contiene el título, botón de crear y buscador:
        JPanel panelSuperior = new JPanel(new BorderLayout());

        // Sub-panel para el título:
        JPanel panelTitulo = new JPanel();
        panelTitulo.setLayout(new BoxLayout(panelTitulo, BoxLayout.Y_AXIS));
        panelTitulo.setBackground(new Color(0x2169AC));
        panelTitulo.setPreferredSize(new Dimension(0, 50));

        JLabel tituloPrincipal = new JLabel("Lista de Vendedores");
        tituloPrincipal.setForeground(Color.WHITE);
        tituloPrincipal.setFont(new Font("Arial", Font.BOLD, 18));
        tituloPrincipal.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Acomodamos el titlo en su panel (centrado):
        panelTitulo.add(Box.createVerticalGlue()); // Espacio flexible arriba.
        panelTitulo.add(tituloPrincipal);
        panelTitulo.add(Box.createVerticalGlue()); // Espacio flexible abajo.

        // Añadimos el titlePanel al lado superior del panel superior:
        panelSuperior.add(panelTitulo, BorderLayout.NORTH);

        // Sub-panel para el botón "Crear Nuevo vendedor" alineado a la izquierda:
        JPanel panelIzquierdo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelIzquierdo.setBorder(BorderFactory.createEmptyBorder(10, 88, 0, 0));

        botonCrear = new JButton("Crear nuevo vendedor");
        botonCrear.setMargin(new Insets(0, 0, 0, 0)); // Le sacamos bordes internos al boton.
        panelIzquierdo.add(botonCrear); // Agregamos el boton al panel izquierdo.

        // Sub-panel para el campo 'buscador' alineado a la derecha:
        JPanel panelDerecho = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelDerecho.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel searchLabel = new JLabel("Buscador:");
        String[] criteriosBusqueda = {"ID", "Nombre", "Dirección"};
        comboBusqueda = new JComboBox<>(criteriosBusqueda);
        campoBusqueda = new JTextField(20);

        panelDerecho.add(searchLabel); // Agregamos el texto 'Buscador' al panel.
        panelDerecho.add(comboBusqueda); // Agregamos el selector combo de busqueda al panel.
        panelDerecho.add(campoBusqueda); // Agregamos el campo de busqueda al panel.

        // Añadimos los sub-paneles al panel superior:
        panelSuperior.add(panelIzquierdo, BorderLayout.WEST);
        panelSuperior.add(panelDerecho, BorderLayout.EAST);

        // Agregamos márgenes al panel superior para que coincida con los de la tabla:
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

        // Añadimos el panel superior al BorderLayout.NORTH del panel principal:
        add(panelSuperior, BorderLayout.NORTH);

        // Configuramos la tabla:
        String[] columnNames = {"ID", "Nombre", "Dirección", "Coordenadas", "Acción 1", "Acción 2"}; // Las acciones 1 y 2 corresponden a editar y eliminar respectivamente.
        modeloTabla = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4 || column == 5; // Hacemos que solo las celdas de editar y eliminar sean editables (presionables).
            }
        };

        tablaVendedores = new JTable(modeloTabla); // Declaramos un nuevo panel de tabla con el modelo que creamos antes.
        tablaVendedores.setRowHeight(30); // Le damos la altura que queremos a las filas de la tabla.

        // Configuramos la altura de la fila de los encabezados de las columnas:
        JTableHeader encabezado = tablaVendedores.getTableHeader();
        encabezado.setPreferredSize(new Dimension(encabezado.getWidth(), 40));
        encabezado.setDefaultRenderer(new PedidoUI.encabezadoPersonalizado());

        // Cambiamos el color de los bordes externos del encabezado para que coincida con el color de los bordes externos de la tabla:
        encabezado.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        // Establecemos el color de la cuadrícula y lo mostramos:
        tablaVendedores.setGridColor(Color.BLACK);
        tablaVendedores.setShowGrid(true);

        // Creamos un borde personalizado para la tabla:
        tablaVendedores.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.BLACK, 2),
                BorderFactory.createEmptyBorder(0, 0, 2, 0)
        ));

        // Configuramos los anchos específicos para cada columna:
        tablaVendedores.getColumnModel().getColumn(0).setPreferredWidth(30);
        tablaVendedores.getColumnModel().getColumn(1).setPreferredWidth(150);
        tablaVendedores.getColumnModel().getColumn(2).setPreferredWidth(100);
        tablaVendedores.getColumnModel().getColumn(3).setPreferredWidth(100);
        tablaVendedores.getColumnModel().getColumn(4).setPreferredWidth(60);
        tablaVendedores.getColumnModel().getColumn(5).setPreferredWidth(60);

        // Creamos un renderizador para centrar todos los textos dentro de la tabla:
        DefaultTableCellRenderer renderizadoCentrado = new DefaultTableCellRenderer();
        renderizadoCentrado.setHorizontalAlignment(SwingConstants.CENTER);

        // Aplicamos el renderizador a todas las columnas:
        for (int i = 0; i < tablaVendedores.getColumnCount(); i++) {
            tablaVendedores.getColumnModel().getColumn(i).setCellRenderer(renderizadoCentrado);
        }

        // Añadimos boton de "Editar" en la columna de "Accion 1":
        tablaVendedores.getColumn("Acción 1").setCellRenderer(new BotonRenderer());
        tablaVendedores.getColumn("Acción 1").setCellEditor(new BotonEditor(new JCheckBox(), "Editar"));

        // Añadimos boton de "Eliminar" en la columna de "Accion 2":
        tablaVendedores.getColumn("Acción 2").setCellRenderer(new BotonRenderer());
        tablaVendedores.getColumn("Acción 2").setCellEditor(new BotonEditor(new JCheckBox(), "Eliminar"));

        // Le agregamos una barra de scroll a la tabla de vendedores:
        JScrollPane panelScroll = new JScrollPane(tablaVendedores);
        panelScroll.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        add(panelScroll, BorderLayout.CENTER);

        // Creamos los listeners (de eventos) de los botones:
        assert botonCrear != null;
        botonCrear.addActionListener(e -> crearVendedor());

        assert campoBusqueda != null;
        campoBusqueda.addActionListener(e -> buscarVendedor());

        tablaVendedores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = tablaVendedores.rowAtPoint(evt.getPoint());
                int column = tablaVendedores.columnAtPoint(evt.getPoint());
                if (column == 4) { // Columna "Editar".
                    editarVendedor(row);
                } else if (column == 5) { // Columna "Eliminar".
                    eliminarVendedor(row);
                }
            }
        });

        cargarDatosEnTabla();

    }

    // Metodo para cargar datos en la tabla al iniciar la interfaz:
    public void cargarDatosEnTabla() {

        modeloTabla.setRowCount(0); // Limpiamos tabla antes de cargar nuevos datos.

        // Obtenemos la lista de vendedores del controlador y los añadimos a la tabla:
        for (Vendedor vendedor : controller.mostrarListaVendedores()) {
            modeloTabla.addRow(new Object[]{
                    vendedor.getId(),
                    vendedor.getNombre(),
                    vendedor.getDireccion(),
                    "Lat: " + vendedor.getCoordenadas().getLAT() + " - Lng: " + vendedor.getCoordenadas().getLNG(),
                    "Editar",
                    "Eliminar"
            });
        }
    }

    public void crearVendedor() {
        JTextField nombreField = new JTextField();
        JTextField direccionField = new JTextField();

        Object[] message = {
                "Nombre:", nombreField,
                "Dirección:", direccionField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Crear nuevo vendedor", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String nombre = nombreField.getText().trim();
            String direccion = direccionField.getText().trim();

            if (!nombre.isEmpty() && !direccion.isEmpty()) {
                Vendedor nuevoVendedor = new Vendedor("V00" + (modeloTabla.getRowCount() + 1), nombre, direccion, new Coordenada(NumeroAleatorio.generarNumeroAleatorio(new Random()),NumeroAleatorio.generarNumeroAleatorio(new Random())));
                controller.crearNuevoVendedor(nuevoVendedor);
                JOptionPane.showMessageDialog(this, "Vendedor creado exitosamente.");
                cargarDatosEnTabla(); // Actualiza la tabla después de crear.
            } else {
                JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            }
        }
    }

    public void editarVendedor(int row) {
        String idVendedor = (String) modeloTabla.getValueAt(row, 0);
        Vendedor vendedor = controller.buscarVendedor(idVendedor);

        if (vendedor != null) {
            JTextField nombreField = new JTextField(vendedor.getNombre());
            JTextField direccionField = new JTextField(vendedor.getDireccion());

            DecimalFormat formatoDecimal = new DecimalFormat("#.######"); // Para 6 decimales
            String latitudTexto = formatoDecimal.format(vendedor.getCoordenadas().getLAT());
            JTextField coordenadasFieldLAT = new JTextField(latitudTexto);

            String longitudTexto = formatoDecimal.format(vendedor.getCoordenadas().getLNG());
            JTextField coordenadasFieldLNG = new JTextField(longitudTexto);

            Object[] message = {
                    "Nombre:", nombreField,
                    "Coordenada (latitud):", coordenadasFieldLAT,
                    "Coordenada (longitud):", coordenadasFieldLNG,
                    "Dirección:", direccionField
            };

            int option = JOptionPane.showConfirmDialog(this, message, "Editar vendedor", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                vendedor.setNombre(nombreField.getText().trim());
                vendedor.setDireccion(direccionField.getText().trim());

                try {
                    // Extraemos el texto de cada JTextField y lo convertimos a double:
                    double latitud = Double.parseDouble(coordenadasFieldLAT.getText());
                    double longitud = Double.parseDouble(coordenadasFieldLNG.getText());

                    // Creamos una nueva instancia de Coordenada con los valores convertidos:
                    vendedor.setCoordenadas(new Coordenada(latitud, longitud));

                } catch (NumberFormatException e) {
                    // Manejamos el caso donde la conversión falle, por ejemplo, si el texto no es un número válido
                    System.out.println("Por favor, ingrese un valor numérico válido.");
                }

                if (controller.modificarVendedor(vendedor)) {
                    JOptionPane.showMessageDialog(this, "Vendedor editado exitosamente.");
                } else {
                    JOptionPane.showMessageDialog(this, "Error al editar el vendedor.");
                }
                cargarDatosEnTabla(); // Actualizamos la tabla después de editar
            }
        }
    }

    public void eliminarVendedor(int row) {
        String idVendedor = (String) modeloTabla.getValueAt(row, 0); // Obtenemos el ID del vendedor de la fila seleccionada.

        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Está seguro que desea eliminar este vendedor?", "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (controller.eliminarVendedor(idVendedor)) {
                JOptionPane.showMessageDialog(this, "Vendedor eliminado exitosamente.");
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar el vendedor.");
            }
            cargarDatosEnTabla(); // Actualizamos la tabla después de eliminar.
        }
    }

    public void buscarVendedor() {
        // Este metodo es para buscar vendedores por cualquiera sea el dato querido:
        String filtro = campoBusqueda.getText().trim();
        String parametro = (String) comboBusqueda.getSelectedItem(); // Obtener el parámetro seleccionado

        // Si el campo de búsqueda está vacío, se restauran todos los vendedores:
        if (filtro.isEmpty()) {
            cargarDatosEnTabla(); // Vuelve a cargar todos los vendedores si no hay filtro.
            return; // Hecho eso, salimos del metodo.
        }

        // Si se ha ingresado un filtro de busqueda, se procede a buscar:
        assert parametro != null;
        List<Vendedor> resultados = controller.buscarVendedorPorParametro(parametro.toLowerCase(), filtro);

        modeloTabla.setRowCount(0); // Limpiamos el modelo de la tabla actual para que solo se visualice el vendedor encontrado.

        for (Vendedor vendedor : resultados) {

            // Añadimos el vendedor encontrado al modelo de tabla y mostramos sus detalles:
            modeloTabla.addRow(new Object[]{
                    vendedor.getId(),
                    vendedor.getNombre(),
                    vendedor.getDireccion(),
                    "Lat: " + vendedor.getCoordenadas().getLAT() + " - Lng: " + vendedor.getCoordenadas().getLNG(),
                    "Editar",
                    "Eliminar"
            });
        }

        if (resultados.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No se encontraron resultados.");
            cargarDatosEnTabla(); // Mostramos todos los vendedores si no se encontraron resultados.
        }

    }

    // Clase interna para renderizado del encabezado de tablas:
    static class encabezadoPersonalizado extends DefaultTableCellRenderer {

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

            JLabel campo = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            campo.setHorizontalAlignment(JLabel.CENTER);
            campo.setOpaque(true);
            campo.setBackground(new Color(0x4C60A2)); // Fondo del encabezado
            campo.setForeground(Color.WHITE); // Color del texto

            // Cambiamos la fuente del texto de los encabezados:
            Font headerFont = new Font("Arial", Font.BOLD, 14);
            campo.setFont(headerFont); // Aplicamos la fuente al encabezado.

            // Establecemos color del borde del encabezado:
            campo.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, Color.BLACK));

            return campo;
        }
    }

    // Clase interna para renderizar botones
    static class BotonRenderer extends JButton implements TableCellRenderer {
        public BotonRenderer() {
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText(value == null ? "" : value.toString());
            return this;
        }
    }

    // Clase interna para manejar la acción de los botones:
    class BotonEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
        private final JButton boton;
        private final String tipoAccion; // Puede ser "Editar" o "Eliminar".
        private int filaSeleccionada;

        public BotonEditor(JCheckBox checkBox, String tipoAccion) {
            this.boton = new JButton();
            this.boton.addActionListener(this);
            this.tipoAccion = tipoAccion;
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.filaSeleccionada = row;
            boton.setText(value == null ? "" : value.toString());
            return boton;
        }

        @Override
        public Object getCellEditorValue() {
            return boton.getText();
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                switch (tipoAccion) {
                    case "Editar":
                        editarVendedor(filaSeleccionada);
                        break;

                    case "Eliminar":
                        // Detener la edición activa antes de modificar el modelo
                        if (tablaVendedores.isEditing()) {
                            tablaVendedores.getCellEditor().stopCellEditing();
                        }
                        eliminarVendedor(filaSeleccionada);
                        break;
                }
            } catch (IndexOutOfBoundsException ex) {
                System.err.println("Error de índice: " + ex.getMessage());
            } finally {
                fireEditingStopped(); // Nos aseguramos de que la edición se detenga después de la acción.
            }
        }
    }

    // Clase que genera números aleatorios (usada para generar coordenadas aleatorias a los nuevos vendedores creados).
    static class NumeroAleatorio {

        private static double generarNumeroAleatorio(Random random) {

            // Generamos un número aleatorio entre -99 y 99:
            int parteEntera = random.nextInt(199) - 99; // -99 a 99

            // Generamos la parte decimal con hasta 6 decimales:
            double parteDecimal = random.nextDouble();

            // Combinamos la parte entera y la decimal:
            double numero = parteEntera + parteDecimal;

            // Redondeamos el número a 6 decimales:
            numero = Math.round(numero * 1_000_000) / 1_000_000.0;

            return numero;
        }
    }
}

