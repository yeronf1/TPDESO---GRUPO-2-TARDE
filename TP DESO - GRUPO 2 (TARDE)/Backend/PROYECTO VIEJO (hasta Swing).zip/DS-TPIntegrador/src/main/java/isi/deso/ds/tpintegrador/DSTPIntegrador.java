package isi.deso.ds.tpintegrador;

import isi.deso.ds.tpintegrador.models.*;
import isi.deso.ds.tpintegrador.models.enums.Estado;
import isi.deso.ds.tpintegrador.exceptions.ItemNoEncontradoException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

public class DSTPIntegrador {

    public static void main(String[] args) {

        // Generamos una instancia de ItemsPedidoMemory para poder acceder a todas las instancias creadas dentro de esa clase (aquellas que simulan la base de datos).
        ItemsPedidoMemory itemsPedidoMemory = new ItemsPedidoMemory();
        PedidosMemory pedidosmemory = new PedidosMemory();

        System.out.println("------------------------ CASOS DE PRUEBA (Etapa 1: Módulo de gestión del Vendedor y Gestión del Cliente) ------------------------");

        // Generamos un ArrayLisy y agregamos los vendedors manualmente ya que son pocos (en un futuro implementaremos un metodo de agregado automático).
        ArrayList<Vendedor> arregloVendedores = new ArrayList<>();

        arregloVendedores.add(itemsPedidoMemory.v1);
        arregloVendedores.add(itemsPedidoMemory.v2);
        arregloVendedores.add(itemsPedidoMemory.v3);

        System.out.println("\nSe han cargado 3 vendedores a la lista de vendedores.");
        System.out.println("\nLISTA DE VENDEDORES:");
        for (Vendedor vendedor : arregloVendedores) {
            System.out.println("* ID: " + vendedor.getId() + " - " + vendedor.getNombre() + " (DIRECCIÓN: " + vendedor.getDireccion() + ").");
        }

        // Creamos un nombre de vendedor al azar que buscaremos en la lista de vendedores ya creada.
        String vendedorABuscar = "Pablo";
        System.out.print("\nSe buscarán vendedores llamados: " + vendedorABuscar + ".");
        // La implementacion realizada tambien sirve para buscar por ID ingresado, este es solo un ejemplo.

        Iterator<Vendedor> iterator = arregloVendedores.iterator();

        // Declaramos un nuevo objeto tipo vendedor que irá tomando el valor de cada objeto vendedor en la ArrayList (en cada iteración) para poder ir comparando con la entrada estándar.
        Vendedor buscado;

        boolean bandera = true;

        while(iterator.hasNext() && bandera){

            buscado = iterator.next();

            // Buscamos por el nombre o ID aleatorio antes creado.
            if(vendedorABuscar.equalsIgnoreCase(buscado.getNombre()) || vendedorABuscar.equalsIgnoreCase(buscado.getId())){

                System.out.println("\nSe ha encontrado un vendedor con el nombre: " + vendedorABuscar + ".");

                // Eliminamos el elemento actual que tomó la variable iterator (es decir, el vendedor buscado).
                iterator.remove();

                System.out.println("El vendedor " + vendedorABuscar + " ha sido eliminado de la lista de vendedores.");

                System.out.println("\nLISTA DE VENDEDORES:");
                for (Vendedor vendedor : arregloVendedores) {
                    System.out.println("* ID: " + vendedor.getId() + " - " + vendedor.getNombre() + " (DIRECCIÓN: " + vendedor.getDireccion() + ").");
                }

                bandera = false;
                // Una vez que terminamos el proceso de búsqueda, salimos del bucle seteando la bandera a falso.
            }
        }

        if(bandera){
            System.out.println("No existe un vendedor con ese nombre o ID.");
        }

        // CASO DE PRUEBA PARA VERIFICAR EL FUNCIONAMIENTO DEL METODO 'distancia(Cliente)':

        System.out.println("\nUn vendedor aleatorio (ID: " + itemsPedidoMemory.vendedorRandom.getId() + " - " + itemsPedidoMemory.vendedorRandom.getNombre() + ") se encuentra en las coordenadas: (X:" + itemsPedidoMemory.vendedorRandom.getCoordenadas().getLNG() + "; Y:" + itemsPedidoMemory.vendedorRandom.getCoordenadas().getLAT() + ").");
        System.out.println("Un cliente aleatorio (ID: " + itemsPedidoMemory.clienteRandom.getId() + " - " + itemsPedidoMemory.clienteRandom.getNombre() + ") se encuentra en las coordenadas: (X:" + itemsPedidoMemory.clienteRandom.getCoordenadas().getLNG() + "; Y:" + itemsPedidoMemory.clienteRandom.getCoordenadas().getLAT() + ").");

        // Aplicacion del metodo 'distancia()' para el vendedor y cliente recien creados (con redondeo a dos cifras despues de la coma):
        System.out.printf("\nLa distancia entre el vendedor aleatorio y el cliente aleatorio es: %.2f kilómetros.%n", itemsPedidoMemory.vendedorRandom.distancia(itemsPedidoMemory.clienteRandom));

        System.out.println("\n------------------------ CASOS DE PRUEBA (Etapa 2: Módulo de gestión del Menú) ------------------------");

        // Agregacion de los items al menú del vendedor aleatorio creado:
        itemsPedidoMemory.vendedorRandom.agregarItem(itemsPedidoMemory.cocaCola);
        itemsPedidoMemory.vendedorRandom.agregarItem(itemsPedidoMemory.vino);
        itemsPedidoMemory.vendedorRandom.agregarItem(itemsPedidoMemory.jugoNaranja);
        itemsPedidoMemory.vendedorRandom.agregarItem(itemsPedidoMemory.ensalada);
        itemsPedidoMemory.vendedorRandom.agregarItem(itemsPedidoMemory.milanesa);

        System.out.println("\nSe han cargado 5 ítems al menú del vendedor aleatorio.");
        System.out.println("\nLISTA DE ÍTEMS DEL MENÚ DEL VENDEDOR ALEATORIO (ID: " + itemsPedidoMemory.vendedorRandom.getId() + " - "  + itemsPedidoMemory.vendedorRandom.getNombre() + "):");
        for (ItemMenu itemMenu : itemsPedidoMemory.vendedorRandom.getItemsMenu()) {
            System.out.println("* Ítem: " + itemMenu.getNombre() + ".");
        }

        // CASO DE PRUEBA PARA VERIFICAR EL FUNCIONAMIENTO DEL METODO 'getListaBebidas()':
        System.out.println("\nLISTA DE BEBIDAS:");
        ArrayList<ItemMenu> bebidas = itemsPedidoMemory.vendedorRandom.getListaBebidas();
        for (ItemMenu bebida : bebidas) {
            System.out.println("* " + bebida.getNombre() + ".");
        }

        // CASO DE PRUEBA PARA VERIFICAR EL FUNCIONAMIENTO DEL METODO 'getListaComidas()':
        System.out.println("\nLISTA DE COMIDAS:");
        ArrayList<ItemMenu> comidas = itemsPedidoMemory.vendedorRandom.getListaComidas();
        for (ItemMenu comida : comidas) {
            System.out.println("* " + comida.getNombre() + ".");
        }

        // CASO DE PRUEBA PARA VERIFICAR EL FUNCIONAMIENTO DEL METODO 'getListaComidasVegetarianas()':
        System.out.println("\nLISTA DE COMIDAS VEGETARIANAS:");
        ArrayList<ItemMenu> comidasVegetarianas = itemsPedidoMemory.vendedorRandom.getListaComidasVegetarianas();
        for (ItemMenu comidaVeg : comidasVegetarianas) {
            System.out.println("* " + comidaVeg.getNombre() + ".");
        }

        // CASO DE PRUEBA PARA VERIFICAR EL FUNCIONAMIENTO DEL METODO 'getListaBebidasSinAlcohol()':
        System.out.println("\nLISTA DE BEBIDAS SIN ALCOHOL:");
        ArrayList<ItemMenu> bebidasSinAlcohol = itemsPedidoMemory.vendedorRandom.getListaBebidasSinAlcohol();
        for (ItemMenu bebidaSinAlcohol : bebidasSinAlcohol) {
            System.out.println("* " + bebidaSinAlcohol.getNombre() + ".");
        }

        System.out.println("-------------------------------------------------------------------------------------------------------");

        // CASO DE PRUEBA PARA VERIFICAR EL FUNCIONAMIENTO DEL METODO 'peso()' EN BEBIDAS Y COMIDAS:

        System.out.println("PESOS DE LOS ÍTEMS DEL MENÚ: ");

        for (ItemMenu itemMenu : itemsPedidoMemory.vendedorRandom.getItemsMenu()) {
            System.out.println("* Peso de " + itemMenu.getNombre() + ": " + itemMenu.peso() + " gramos.");
        }

        System.out.println("-------------------------------------------------------------------------------------------------------");

        // CASOS DE PRUEBA PARA VERIFICAR EL FUNCIONAMIENTO DE LOS METODOS 'esComida()' y 'esBebida()':

        System.out.println("VERIFICACIÓN DE CATEGORÍA PARA CADA ÍTEM DEL MENÚ: ");

        for (ItemMenu itemMenu : itemsPedidoMemory.vendedorRandom.getItemsMenu()) {
            System.out.println("* ¿" + itemMenu.getNombre() + " es comida? " + itemMenu.esComida());
            System.out.println("* ¿" + itemMenu.getNombre() + " es bebida? " + itemMenu.esBebida());
            System.out.println();
        }

        System.out.println("-------------------------------------------------------------------------------------------------------");

        // CASO DE PRUEBA PARA VERIFICAR EL FUNCIONAMIENTO DEL METODO 'aptoVegetariano()':

        System.out.println("VERIFICACIÓN VEGETARIANA PARA CADA ÍTEM DEL MENÚ: ");

        for (ItemMenu itemMenu : itemsPedidoMemory.vendedorRandom.getItemsMenu()) {
            System.out.println("* ¿" + itemMenu.getNombre() + " es apta para vegetarianos? " + itemMenu.aptoVegetariano());
        }

        System.out.println("\n------------------------ CASOS DE PRUEBA (Etapa 3: Módulo de gestión de Búsqueda) ------------------------");

        // Agregacion de los items a los distintos menues de los vendedores nuevos creados:

        itemsPedidoMemory.vendedor1.agregarItem(itemsPedidoMemory.bebida1);
        itemsPedidoMemory.vendedor1.agregarItem(itemsPedidoMemory.plato1);
        itemsPedidoMemory.vendedor1.agregarItem(itemsPedidoMemory.bebida15);
        itemsPedidoMemory.vendedor1.agregarItem(itemsPedidoMemory.plato15);


        itemsPedidoMemory.vendedor2.agregarItem(itemsPedidoMemory.bebida2);
        itemsPedidoMemory.vendedor2.agregarItem(itemsPedidoMemory.plato2);
        itemsPedidoMemory.vendedor2.agregarItem(itemsPedidoMemory.bebida14);
        itemsPedidoMemory.vendedor2.agregarItem(itemsPedidoMemory.plato14);


        itemsPedidoMemory.vendedor3.agregarItem(itemsPedidoMemory.bebida3);
        itemsPedidoMemory.vendedor3.agregarItem(itemsPedidoMemory.plato3);
        itemsPedidoMemory.vendedor3.agregarItem(itemsPedidoMemory.bebida13);
        itemsPedidoMemory.vendedor3.agregarItem(itemsPedidoMemory.plato13);


        itemsPedidoMemory.vendedor4.agregarItem(itemsPedidoMemory.bebida4);
        itemsPedidoMemory.vendedor4.agregarItem(itemsPedidoMemory.plato4);
        itemsPedidoMemory.vendedor4.agregarItem(itemsPedidoMemory.bebida12);
        itemsPedidoMemory.vendedor4.agregarItem(itemsPedidoMemory.plato12);


        itemsPedidoMemory.vendedor5.agregarItem(itemsPedidoMemory.bebida5);
        itemsPedidoMemory.vendedor5.agregarItem(itemsPedidoMemory.plato5);
        itemsPedidoMemory.vendedor5.agregarItem(itemsPedidoMemory.bebida11);
        itemsPedidoMemory.vendedor5.agregarItem(itemsPedidoMemory.plato11);


        itemsPedidoMemory.vendedor6.agregarItem(itemsPedidoMemory.bebida6);
        itemsPedidoMemory.vendedor6.agregarItem(itemsPedidoMemory.plato6);
        itemsPedidoMemory.vendedor6.agregarItem(itemsPedidoMemory.bebida10);
        itemsPedidoMemory.vendedor6.agregarItem(itemsPedidoMemory.plato10);


        itemsPedidoMemory.vendedor7.agregarItem(itemsPedidoMemory.bebida7);
        itemsPedidoMemory.vendedor7.agregarItem(itemsPedidoMemory.plato7);
        itemsPedidoMemory.vendedor7.agregarItem(itemsPedidoMemory.bebida9);
        itemsPedidoMemory.vendedor7.agregarItem(itemsPedidoMemory.plato9);


        itemsPedidoMemory.vendedor8.agregarItem(itemsPedidoMemory.bebida8);
        itemsPedidoMemory.vendedor8.agregarItem(itemsPedidoMemory.plato8);
        itemsPedidoMemory.vendedor8.agregarItem(itemsPedidoMemory.bebida16);
        itemsPedidoMemory.vendedor8.agregarItem(itemsPedidoMemory.plato16);

        // A partir de distintos 'ItemsPedidos' armamos el detalle completo de pedidos correspondiente a cada pedido.

        // PEDIDO 1:

        pedidosmemory.pedido1.agregarADetalle(itemsPedidoMemory.itemPedido1_1);
        pedidosmemory.pedido1.agregarADetalle(itemsPedidoMemory.itemPedido1_2);
        pedidosmemory.pedido1.agregarADetalle(itemsPedidoMemory.itemPedido1_3);
        pedidosmemory.pedido1.agregarADetalle(itemsPedidoMemory.itemPedido1_4);

        // PEDIDO 2:

        pedidosmemory.pedido2.agregarADetalle(itemsPedidoMemory.itemPedido2_1);
        pedidosmemory.pedido2.agregarADetalle(itemsPedidoMemory.itemPedido2_2);
        pedidosmemory.pedido2.agregarADetalle(itemsPedidoMemory.itemPedido2_3);
        pedidosmemory.pedido2.agregarADetalle(itemsPedidoMemory.itemPedido2_4);

        // PEDIDO 3:

        pedidosmemory.pedido3.agregarADetalle(itemsPedidoMemory.itemPedido3_1);
        pedidosmemory.pedido3.agregarADetalle(itemsPedidoMemory.itemPedido3_2);
        pedidosmemory.pedido3.agregarADetalle(itemsPedidoMemory.itemPedido3_3);
        pedidosmemory.pedido3.agregarADetalle(itemsPedidoMemory.itemPedido3_4);

        // PEDIDO 4:

        pedidosmemory.pedido4.agregarADetalle(itemsPedidoMemory.itemPedido4_1);
        pedidosmemory.pedido4.agregarADetalle(itemsPedidoMemory.itemPedido4_2);
        pedidosmemory.pedido4.agregarADetalle(itemsPedidoMemory.itemPedido4_3);
        pedidosmemory.pedido4.agregarADetalle(itemsPedidoMemory.itemPedido4_4);

        // PEDIDO 5:

        pedidosmemory.pedido5.agregarADetalle(itemsPedidoMemory.itemPedido5_1);
        pedidosmemory.pedido5.agregarADetalle(itemsPedidoMemory.itemPedido5_2);
        pedidosmemory.pedido5.agregarADetalle(itemsPedidoMemory.itemPedido5_3);
        pedidosmemory.pedido5.agregarADetalle(itemsPedidoMemory.itemPedido5_4);

        // PEDIDO 6:

        pedidosmemory.pedido6.agregarADetalle(itemsPedidoMemory.itemPedido6_1);
        pedidosmemory.pedido6.agregarADetalle(itemsPedidoMemory.itemPedido6_2);
        pedidosmemory.pedido6.agregarADetalle(itemsPedidoMemory.itemPedido6_3);
        pedidosmemory.pedido6.agregarADetalle(itemsPedidoMemory.itemPedido6_4);

        // PEDIDO 7:

        pedidosmemory.pedido7.agregarADetalle(itemsPedidoMemory.itemPedido7_1);
        pedidosmemory.pedido7.agregarADetalle(itemsPedidoMemory.itemPedido7_2);
        pedidosmemory.pedido7.agregarADetalle(itemsPedidoMemory.itemPedido7_3);
        pedidosmemory.pedido7.agregarADetalle(itemsPedidoMemory.itemPedido7_4);

        // PEDIDO 8:

        pedidosmemory.pedido8.agregarADetalle(itemsPedidoMemory.itemPedido8_1);
        pedidosmemory.pedido8.agregarADetalle(itemsPedidoMemory.itemPedido8_2);
        pedidosmemory.pedido8.agregarADetalle(itemsPedidoMemory.itemPedido8_3);
        pedidosmemory.pedido8.agregarADetalle(itemsPedidoMemory.itemPedido8_4);


        // A partir de todos los pedidos ya armados, cada uno es agregado a una lista general 'pedidos' que incluye a todos los pedidos.

        itemsPedidoMemory.pedidos.add(pedidosmemory.pedido1);
        itemsPedidoMemory.pedidos.add(pedidosmemory.pedido2);
        itemsPedidoMemory.pedidos.add(pedidosmemory.pedido3);
        itemsPedidoMemory.pedidos.add(pedidosmemory.pedido4);
        itemsPedidoMemory.pedidos.add(pedidosmemory.pedido5);
        itemsPedidoMemory.pedidos.add(pedidosmemory.pedido6);
        itemsPedidoMemory.pedidos.add(pedidosmemory.pedido7);
        itemsPedidoMemory.pedidos.add(pedidosmemory.pedido8);

        System.out.println("\nSe han cargado " + itemsPedidoMemory.pedidos.size() + " pedidos.");

        System.out.println("\nLISTA DE PEDIDOS:");

        for (Pedido pedido :  itemsPedidoMemory.pedidos) {
            System.out.println("* ID Pedido: " + pedido.getIdPedido() + " - Cliente: " + pedido.getCliente().getNombre() + ".");
            for (ItemPedido itemPedido : pedido.getPedidosDetalle()) {
                System.out.println("  - Ítem: " + itemPedido.getItemMenu().getNombre() + ", Código: " + itemPedido.getCodigo() + ".");
            }
            System.out.println();
        }

        System.out.println("-------------------------------------------------------------------------------------------------------");

        // METODOS DE FILTRADO DE PEDIDOS:

        try {

            System.out.println("ÍTEMS FILTRADOS POR CATEGORÍA 'COMIDA': ");
            ArrayList<ItemMenu> itemsComida = itemsPedidoMemory.filtrar("COMIDA");
            itemsComida.forEach(item -> System.out.println("* " + item.getNombre() + " - Precio: $ " + item.getPrecio() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        try {

            System.out.println("\nÍTEMS FILTRADOS POR CATEGORÍA 'BEBIDA': ");
            ArrayList<ItemMenu> itemsBebida = itemsPedidoMemory.filtrar("BEBIDA");
            itemsBebida.forEach(item -> System.out.println("* " + item.getNombre() + " - Precio: $ " + item.getPrecio() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        try {

            String filtroNombreItem = "Lasaña de Espinaca";

            ArrayList<ItemMenu> resultadoFiltroNombreItem = itemsPedidoMemory.filtrar(filtroNombreItem);
            System.out.println("\nÍTEMS FILTRADOS POR NOMBRE DEL ÍTEM '" + filtroNombreItem + "':");
            resultadoFiltroNombreItem.forEach(item -> System.out.println("* " + item.getNombre() + " - Precio: $ " + item.getPrecio() +  "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        try {

            String filtroDireccionVendedor = "Calle Florida 102";

            ArrayList<ItemMenu> resultadoFiltroDireccionVendedor = itemsPedidoMemory.filtrar(filtroDireccionVendedor);
            System.out.println("\nÍTEMS FILTRADOS POR DIRECCIÓN DEL VENDEDOR '" + filtroDireccionVendedor + "':");
            resultadoFiltroDireccionVendedor.forEach(item -> System.out.println("* " + item.getNombre() + " - Precio: $ " + item.getPrecio() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        try {

            String filtroNombreCliente = "Juan Perez";

            ArrayList<ItemMenu> resultadoFiltroNombreCliente = itemsPedidoMemory.filtrar(filtroNombreCliente);
            System.out.println("\nÍTEMS FILTRADOS POR NOMBRE DEL CLIENTE '" + filtroNombreCliente + "':");
            resultadoFiltroNombreCliente.forEach(item -> System.out.println("* " + item.getNombre() + " - Precio: $ " + item.getPrecio() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        try {

            String filtroCuitCliente = "20678901236";

            ArrayList<ItemMenu> resultadoFiltroCuitCliente = itemsPedidoMemory.filtrar(filtroCuitCliente);
            System.out.println("\nÍTEMS FILTRADOS POR CUIT DEL CLIENTE '" + filtroCuitCliente + "':");
            resultadoFiltroCuitCliente.forEach(item -> System.out.println("* " + item.getNombre() + " - Precio: $ " + item.getPrecio() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        try {

            String filtroDireccionCliente = "Bv. Las Grevileas 3480";

            ArrayList<ItemMenu> resultadoFiltroDireccionCliente = itemsPedidoMemory.filtrar(filtroDireccionCliente);
            System.out.println("\nÍTEMS FILTRADOS POR DIRECCIÓN DEL CLIENTE '" + filtroDireccionCliente + "':");
            resultadoFiltroDireccionCliente.forEach(item -> System.out.println("* " + item.getNombre() + " - Precio: $ " + item.getPrecio() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        try {

            String filtroMail = "ricardo@ejemplo.com";

            ArrayList<ItemMenu> resultadoFiltroMail = itemsPedidoMemory.filtrar(filtroMail);
            System.out.println("\nÍTEMS FILTRADOS POR EMAIL DEL CLIENTE '" + filtroMail + "':");
            resultadoFiltroMail.forEach(item -> System.out.println("* " + item.getNombre() + " - Precio: $ " + item.getPrecio() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }


        // METODOS DE ORDENAMIENTO DE PEDIDOS (POR CRITERIOS):

        try {

            System.out.println("\nORDENAMIENTO ASCENDENTE POR NOMBRE DE ÍTEM: ");
            ArrayList<ItemMenu> itemsOrdenadosNombreAscendente = itemsPedidoMemory.ordenarPorNombreAscendente();
            itemsOrdenadosNombreAscendente.forEach(item -> System.out.println("* " + item.getNombre() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        try {

            System.out.println("\nORDENAMIENTO DESCENDENTE POR NOMBRE DE ÍTEM: ");
            ArrayList<ItemMenu> itemsOrdenadosNombreDescendente = itemsPedidoMemory.ordenarPorNombreDescendente();
            itemsOrdenadosNombreDescendente.forEach(item -> System.out.println("* " + item.getNombre() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        try {

            System.out.println("\nORDENAMIENTO ASCENDENTE POR PRECIO DE ÍTEM: ");
            ArrayList<ItemMenu> itemsOrdenadosPrecioAscendente = itemsPedidoMemory.ordenarPorprecioAscendente();
            itemsOrdenadosPrecioAscendente.forEach(item -> System.out.println("* " + item.getNombre() + " - $ " + item.getPrecio() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        try {

            System.out.println("\nORDENAMIENTO DESCENDENTE POR PRECIO DE ÍTEM: ");
            ArrayList<ItemMenu> itemsOrdenadosPrecioDescendente = itemsPedidoMemory.ordenarPorprecioDescendente();
            itemsOrdenadosPrecioDescendente.forEach(item -> System.out.println("* " + item.getNombre() + " - $ " + item.getPrecio() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        // METODO DE BUSQUEDA DE PEDIDOS POR RANGO DE PRECIOS:

        try {

            double precioMin = 5000.0;
            double precioMax = 12000.0;

            ArrayList<ItemMenu> filtradoPrecio = itemsPedidoMemory.buscarPorRangoPrecio(precioMin, precioMax);
            System.out.println("\nBÚSQUEDA DE ÍTEMS POR RANGO DE PRECIO ($" + precioMin + " - $" + precioMax + "):");
            filtradoPrecio.forEach(item -> System.out.println("* " + item.getNombre() + " - Precio: $ " + item.getPrecio() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        // METODO DE BUSQUEDA DE PEDIDOS POR RESTAURANTE (VENDEDOR):

        try {

            String filtroNombreVendedor = "Paprika";

            System.out.println("\nBÚSQUEDA DE ÍTEMS DEL VENDEDOR '" + filtroNombreVendedor + "': ");
            ArrayList<ItemMenu> itemsRestaurante3 = itemsPedidoMemory.buscarPorRestaurante(filtroNombreVendedor);
            itemsRestaurante3.forEach(item -> System.out.println("* " + item.getNombre() + " - Precio: $ " + item.getPrecio() + "."));

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\n------------------------ CASOS DE PRUEBA (Etapa 4: Módulo de gestión de Creación de pedido) ------------------------");

        System.out.println("\nLISTA DE VENDEDORES: ");

        // Generamos una nueva lista de vendedores para diferenciarla de la lista de la primera entrega (luego unificaremos).
        ArrayList<Vendedor> listaVendedores = new ArrayList<>();

        listaVendedores.add(itemsPedidoMemory.vendedor1);
        listaVendedores.add(itemsPedidoMemory.vendedor2);
        listaVendedores.add(itemsPedidoMemory.vendedor3);
        listaVendedores.add(itemsPedidoMemory.vendedor4);
        listaVendedores.add(itemsPedidoMemory.vendedor5);
        listaVendedores.add(itemsPedidoMemory.vendedor6);
        listaVendedores.add(itemsPedidoMemory.vendedor7);
        listaVendedores.add(itemsPedidoMemory.vendedor8);

        for(int i = 0; i < listaVendedores.size(); i++){
            System.out.println("* " + (i+1) + ": " + listaVendedores.get(i).getNombre() + ".");
        }

        BufferedReader bu = new BufferedReader(new InputStreamReader(System.in));
        int opcionVendedor = -1;

        while(opcionVendedor < 1 || opcionVendedor > listaVendedores.size()){

            System.out.print("\nSeleccione el vendedor del que quiere comprar (1-" + listaVendedores.size() + "): ");

            try {

                opcionVendedor = Integer.parseInt(bu.readLine());

                if (opcionVendedor >= 1 && opcionVendedor <= listaVendedores.size()) {
                    break;
                }
                else{
                    System.out.println("Opción fuera de rango. Intente de nuevo.");
                }

            }catch (IOException e){
                System.out.println("Hubo un error al leer la entrada del usuario.");
            }catch (NumberFormatException e){
                System.out.println("La entrada no es válida. Debe ingresar un numero.");
            }
        }

        // Generamos un id ALEATORIO correspondiente al pedido y a su respectivo pago.
        String idPedido = "NP123";

        // Generamos un nuevo pedido para el cliente actual.
        Pedido nuevoPedido = new Pedido(idPedido,itemsPedidoMemory.clienteRandom);

        try {

            System.out.println("\nMenú del restaurante '" + listaVendedores.get(opcionVendedor - 1).getNombre() + "':");
            ArrayList<ItemMenu> items = itemsPedidoMemory.buscarPorRestaurante(listaVendedores.get(opcionVendedor - 1).getNombre());

            for(int j = 0; j < items.size(); j++){
                System.out.println("* " + (j+1) + ": " + items.get(j).getNombre() + " - " + "Precio: $" + items.get(j).getPrecio() + ".");
            }

            int opcionProducto = -1;
            int codigosPedidos = 0;

            do {

                System.out.print("\nIngrese el número del producto que desea comprar (o ingrese 0 para finalizar): ");

                try {

                    opcionProducto = Integer.parseInt(bu.readLine());

                    // Validamos que el número este dentro del rango o que sea 0 para finalizar.
                    if (opcionProducto > 0 && opcionProducto <= items.size()) {

                        // Generamos un nuevo item pedido con el seleccionado actualmente.
                        ItemPedido item_nuevo = new ItemPedido("IP-" + codigosPedidos ,items.get(opcionProducto - 1));

                        // Agregamos dicho item pedido al pedido nuevo.
                        nuevoPedido.agregarADetalle(item_nuevo);

                        System.out.println("Producto agregado: " + items.get(opcionProducto - 1).getNombre() + ".");

                    } else if (opcionProducto != 0) {
                        System.out.println("El número ingresado está fuera del rango de productos.");
                    }

                } catch (IOException e){
                    System.out.println("Hubo un error al leer la entrada del usuario.");
                } catch (NumberFormatException e){
                    System.out.println("La entrada no es válida. Debe ingresar un número.");
                }

                codigosPedidos++;

            } while (opcionProducto != 0);  // Finaliza cuando el usuario ingresa 0

            System.out.println("Ha finalizado la selección de productos.");

            // Mostramos los productos seleccionados (AJUSTAR PARA QUE DIRECTAMENTE MUESTRE EL PEDIDO CON EL PRECIO TOTAL).

            if (nuevoPedido.getPedidosDetalle().isEmpty()) {
                System.out.println("\nNo ha seleccionado ningún producto. El pedido ha sido cancelado.");
                return;
            } else {

                System.out.println("\nPEDIDO NUEVO:");
                for (ItemPedido itemPedido : nuevoPedido.getPedidosDetalle()) {
                    System.out.println("  - Ítem: " + itemPedido.getItemMenu().getNombre() + ", Código: " + itemPedido.getCodigo() + ", Precio: $" + itemPedido.getItemMenu().getPrecio() + ".");
                }

                itemsPedidoMemory.pedidos.add(nuevoPedido);
            }

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\n¿Cómo desea pagar? Ingrese una opción (1-2): ");
        System.out.println("* 1: Transferencia (2% de recargo).");
        System.out.println("* 2: Mercado Pago (4% de recargo).");

        int opcionPago = -1;

        // Atributos correspondientes a los datos a informar del cliente si elige TRANSFERENCIA:
        String cuit = null;
        String cbu = null;

        // Atributo correspondiente al dato a informar del cliente si elige MERCADO PAGO:
        String alias = null;

        while(opcionPago != 1 && opcionPago != 2) {

            try {

                opcionPago = Integer.parseInt(bu.readLine());

                switch (opcionPago) {
                    case 1:

                        System.out.println("Usted pagará con TRANSFERENCIA.");

                        do {
                            System.out.print("\nIngrese su CUIT (11 dígitos): ");
                            // En Argentina, un cuit es numerico y tiene 11 digitos.

                            cuit = bu.readLine();

                            // Validamos utilizando una expresión regular: \\d{11} que asegura que el CUIT tiene exactamente 11 caracteres numéricos.
                            if (!cuit.matches("\\d{11}")) {
                                System.out.println("CUIT inválido. Debe tener 11 dígitos numéricos (sin letras o caracteres especiales).");
                            }

                        } while (!cuit.matches("\\d{11}")); // Repetimos hasta que sea valido.

                        do {
                            System.out.print("Ingrese su CBU (22 dígitos): ");
                            // En Argentina, un cbu es numerico y tiene 22 digitos.

                            cbu = bu.readLine();

                            // Validamos utilizando una expresión regular: \\d{22} que asegura que el cbu tiene exactamente 22 caracteres numéricos.
                            if (!cbu.matches("\\d{22}")) {
                                System.out.println("CBU inválido. Debe tener 22 dígitos numéricos.");
                            }

                        } while (!cbu.matches("\\d{22}")); // Repetimos hasta que sea valido.

                        break;

                    case 2:

                        System.out.println("Usted pagará con MERCADO PAGO.");

                        do {
                            System.out.print("\nIngrese su alias (6 a 20 caracteres alfanuméricos; puede incluir puntos): ");
                            // Un alias de Mercado Pago puede ser una combinación de letras y números (entre 6 y 20 caracteres), puede contener puntos y no debe tener
                            // espacios ni caracteres especiales.

                            alias = bu.readLine();

                            // Validamos utilizando una expresión regular: [a-zA-Z0-9\.]{6,20} que asegura que el alias tiene entre 6 a 20 caracteres alfanumericos (incluyendo puntos).
                            if (!alias.matches("[a-zA-Z0-9.]{6,20}")) {
                                System.out.println("Alias inválido. Debe tener entre 6 y 20 caracteres alfanuméricos; puede incluir puntos.");
                            }

                        } while (!alias.matches("[a-zA-Z0-9.]{6,20}")); // Repetimos hasta que sea valido.

                        break;

                    default: System.out.println("Opción inválida. Por favor, ingrese 1 para Transferencia o 2 para Mercado Pago.");
                }

            }catch (IOException e){
                System.out.println("Hubo un error al leer la entrada del usuario.");
            }catch (NumberFormatException e){
                System.out.println("La entrada no es válida. Debe ingresar un número.");
            }
        }

        nuevoPedido.setEstadoPedido(Estado.RECIBIDO);
        // Creado y armado el pedido, este se quedara con el estado RECIBIDO (dicho estado se pone automaticamente una vez calculado el total a pagar).

        System.out.println("\n------------------------ CASOS DE PRUEBA (Etapa 5: Módulo de Actualización de estados.) ------------------------");

        try{

            String filtroEstadoPedido = "RECIBIDO";


            System.out.println("\nLISTA DE PEDIDOS FILTRADOS POR ESTADO '" + filtroEstadoPedido + "': ");
            ArrayList<Pedido> pedidosFiltrados = pedidosmemory.filtrarPorEstado(filtroEstadoPedido);

            for(int i = 0; i < pedidosFiltrados.size(); i++) {
                System.out.println("(" + (i+1) + ") ID: " + pedidosFiltrados.get(i).getIdPedido() + " - Cliente: " + pedidosFiltrados.get(i).getCliente().getNombre() + " (Dirección: " + pedidosFiltrados.get(i).getCliente().getDireccion() + ").");
            }

            int opcionPedido = -1;

            do {

                System.out.print("\nIngrese los números de los pedidos a los cuales desea actualizarles el estado (o ingrese 0 para finalizar): ");

                try {

                    opcionPedido = Integer.parseInt(bu.readLine());

                    // Validamos que el número este dentro del rango o que sea 0 para finalizar.
                    if (opcionPedido > 0 && opcionPedido <= pedidosFiltrados.size()) {

                        System.out.println("Pedido " + pedidosFiltrados.get(opcionPedido-1).getIdPedido() + " actualizado a 'EN ENVIO'.");

                        pedidosFiltrados.get(opcionPedido-1).cambiarEstadoPedido();

                        switch (opcionPago){
                            case 1: pedidosFiltrados.get(opcionPedido-1).setFormaDePago(new Transferencia(idPedido,cuit,cbu));
                                break;
                            case 2: pedidosFiltrados.get(opcionPedido-1).setFormaDePago(new MercadoPago(idPedido,alias));
                                break;
                        }

                        System.out.println("\n--------------- RESUMEN PEDIDO ---------------");
                        System.out.println("* ID: " + pedidosFiltrados.get(opcionPedido-1).getIdPedido() + "." );
                        System.out.printf("* TOTAL A ABONAR (" + pedidosFiltrados.get(opcionPedido-1).getFormaDePago().getClass().getSimpleName() + "): $ %.2f.%n", pedidosFiltrados.get(opcionPedido-1).calcularTotal());
                        System.out.println("* FECHA: " + pedidosFiltrados.get(opcionPedido-1).getFormaDePago().getFechaPago() + " hs.");
                        System.out.println("* ESTADO: " + pedidosFiltrados.get(opcionPedido-1).getEstadoPedido() + ".");
                        System.out.println("* DATOS DE PAGO DEL CLIENTE: ");

                        if(pedidosFiltrados.get(opcionPedido-1).getFormaDePago() instanceof Transferencia){
                            System.out.println("  - CUIT: " + ((Transferencia) pedidosFiltrados.get(opcionPedido-1).getFormaDePago()).getCuit() + ".");
                            System.out.println("  - CBU: " + ((Transferencia) pedidosFiltrados.get(opcionPedido-1).getFormaDePago()).getCbu() + ".");
                        }
                        else if(pedidosFiltrados.get(opcionPedido-1).getFormaDePago() instanceof MercadoPago){
                            System.out.println("  - ALIAS: " + ((MercadoPago) pedidosFiltrados.get(opcionPedido-1).getFormaDePago()).getAlias() + ".");
                        }

                    } else if (opcionPedido != 0) {
                        System.out.println("El número ingresado está fuera del rango de pedidos.");
                    }

                } catch (IOException e){
                    System.out.println("Hubo un error al leer la entrada del usuario.");
                } catch (NumberFormatException e){
                    System.out.println("La entrada no es válida. Debe ingresar un número.");
                }

            } while (opcionPedido != 0);  // Finaliza cuando el usuario ingresa 0

            System.out.println("Ha finalizado la actualización de estados de los pedidos.");

        } catch (ItemNoEncontradoException e) {
            System.out.println(e.getMessage());
        }

    }
}