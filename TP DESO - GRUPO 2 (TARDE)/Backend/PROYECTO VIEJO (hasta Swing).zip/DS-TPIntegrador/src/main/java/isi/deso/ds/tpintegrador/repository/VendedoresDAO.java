package isi.deso.ds.tpintegrador.repository;

import java.util.List;

import isi.deso.ds.tpintegrador.models.Vendedor;

public interface VendedoresDAO {

    List<Vendedor> listarVendedores();
    boolean crearVendedor(Vendedor vendedor);
    boolean actualizarVendedor(Vendedor vendedor);
    boolean eliminarVendedor(String id);
    Vendedor buscarVendedor(String filtro);
    List<Vendedor> buscarVendedorPorParametro(String parametro, String valor);

}