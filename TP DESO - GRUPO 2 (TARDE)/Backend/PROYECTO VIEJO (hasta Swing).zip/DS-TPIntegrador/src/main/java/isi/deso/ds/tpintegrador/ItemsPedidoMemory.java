package isi.deso.ds.tpintegrador;

import java.util.ArrayList;
import java.util.stream.Collectors;

import isi.deso.ds.tpintegrador.models.*;
import isi.deso.ds.tpintegrador.repository.ItemsPedidoDAO;
import isi.deso.ds.tpintegrador.exceptions.ItemNoEncontradoException;

public class ItemsPedidoMemory implements ItemsPedidoDAO {

    // IMPLEMENTACION DE METODOS DE INTERFAZ.

    ArrayList<Pedido> pedidos = new ArrayList<>(); // En esta lista se alojaran todos los pedidos de los distintos clientes (incluyendo sus respectivos detalles).
    ArrayList<ItemMenu> itemMenusFiltrado;
    ArrayList<ItemMenu> itemsMenu = pedidos.stream().flatMap(pedido -> pedido.getPedidosDetalle().stream()).map(itemPedido -> itemPedido.getItemMenu()).collect(Collectors.toCollection(ArrayList::new));

    ArrayList<ItemPedido> itemsPedidos = new ArrayList<>();

    public ItemsPedidoMemory() {
        // Cargamos items COMIDA predeterminados:
        itemsPedidos.add(itemPedido1_1);
        itemsPedidos.add(itemPedido1_3);
        itemsPedidos.add(itemPedido2_1);
        itemsPedidos.add(itemPedido2_3);
        itemsPedidos.add(itemPedido3_1);
        itemsPedidos.add(itemPedido3_3);
        itemsPedidos.add(itemPedido4_1);
        itemsPedidos.add(itemPedido4_3);
        itemsPedidos.add(itemPedido5_1);
        itemsPedidos.add(itemPedido5_3);
        itemsPedidos.add(itemPedido6_1);
        itemsPedidos.add(itemPedido6_3);
        itemsPedidos.add(itemPedido7_1);
        itemsPedidos.add(itemPedido7_3);
        itemsPedidos.add(itemPedido8_1);
        itemsPedidos.add(itemPedido8_3);

        // Cargamos items BEBIDA predeterminados:

        itemsPedidos.add(itemPedido1_2);
        itemsPedidos.add(itemPedido1_4);
        itemsPedidos.add(itemPedido2_2);
        itemsPedidos.add(itemPedido2_4);
        itemsPedidos.add(itemPedido3_2);
        itemsPedidos.add(itemPedido3_4);
        itemsPedidos.add(itemPedido4_2);
        itemsPedidos.add(itemPedido4_4);
        itemsPedidos.add(itemPedido5_2);
        itemsPedidos.add(itemPedido5_4);
        itemsPedidos.add(itemPedido6_2);
        itemsPedidos.add(itemPedido6_4);
        itemsPedidos.add(itemPedido7_2);
        itemsPedidos.add(itemPedido7_4);
        itemsPedidos.add(itemPedido8_2);
        itemsPedidos.add(itemPedido8_4);
    }

    @Override
    public ArrayList<ItemPedido> listarItemsPedidos() {
        return new ArrayList<>(itemsPedidos);
    }

    @Override
    public ArrayList<ItemMenu> filtrar(String filtro) throws ItemNoEncontradoException {

        itemsMenu = pedidos.stream()
                .flatMap(pedido -> pedido.getPedidosDetalle().stream())
                .map(itemPedido -> itemPedido.getItemMenu())
                .collect(Collectors.toCollection(ArrayList::new));

        itemMenusFiltrado = itemsMenu.stream().filter(item -> (item.getNombre().equalsIgnoreCase(filtro) ||
                item.getVendedor().getDireccion().equalsIgnoreCase(filtro) ||
                (item.getCategoria().getTipoItem().name()).equalsIgnoreCase(filtro))).collect(Collectors.toCollection(ArrayList::new));

        if (itemMenusFiltrado.isEmpty()) {

            ArrayList<Pedido> itemPedidoFiltrado = pedidos.stream().filter(pedido -> pedido.getCliente().getNombre().equalsIgnoreCase(filtro) ||
                    pedido.getCliente().getCuit().equalsIgnoreCase(filtro) ||
                    pedido.getCliente().getDireccion().equalsIgnoreCase(filtro) ||
                    pedido.getCliente().getEmail().equalsIgnoreCase(filtro)).collect(Collectors.toCollection(ArrayList::new));

            itemMenusFiltrado = itemPedidoFiltrado.stream().flatMap(pedido -> pedido.getPedidosDetalle().stream()).map(pedido -> pedido.getItemMenu())
                    .collect(Collectors.toCollection(ArrayList::new));

        }

        if (itemMenusFiltrado.isEmpty()) {
            throw new ItemNoEncontradoException("\nNo se encontraron items para el filtro seleccionado (" + filtro + ").");
        }

        return itemMenusFiltrado;
    }

    @Override
    public ArrayList<ItemMenu> ordenarPorNombreAscendente() throws ItemNoEncontradoException {

        if(itemsMenu.isEmpty()){
            throw new ItemNoEncontradoException("\nNo hay items disponibles para ordenar.");
        }
        else {
            return itemsMenu.stream().sorted((item1, item2) -> item1.getNombre().compareTo(item2.getNombre())).collect(Collectors.toCollection(ArrayList::new));
        }
    }

    @Override
    public ArrayList<ItemMenu> ordenarPorNombreDescendente() throws ItemNoEncontradoException {

        if(itemsMenu.isEmpty()){
            throw new ItemNoEncontradoException("\nNo hay items disponibles para ordenar.");
        }
        else {
            return itemsMenu.stream().sorted((item1, item2) -> item2.getNombre().compareTo(item1.getNombre())).collect(Collectors.toCollection(ArrayList::new));
        }
    }

    @Override
    public ArrayList<ItemMenu> ordenarPorprecioAscendente() throws ItemNoEncontradoException {

        if(itemsMenu.isEmpty()){
            throw new ItemNoEncontradoException("\nNo hay items disponibles para ordenar.");
        }
        else {
            return itemsMenu.stream().sorted((item1, item2) -> Double.compare(item1.getPrecio(), item2.getPrecio())).collect(Collectors.toCollection(ArrayList::new));
        }
    }

    @Override
    public ArrayList<ItemMenu> ordenarPorprecioDescendente() throws ItemNoEncontradoException {

        if(itemsMenu.isEmpty()){
            throw new ItemNoEncontradoException("\nNo hay items disponibles para ordenar.");
        }
        else {
            return itemsMenu.stream().sorted((item1, item2) -> Double.compare(item2.getPrecio(), item1.getPrecio())).collect(Collectors.toCollection(ArrayList::new));
        }
    }

    @Override
    public ArrayList<ItemMenu> buscarPorRangoPrecio(double precioInferior,double precioSuperior) throws ItemNoEncontradoException {

        ArrayList<ItemMenu> resultadosBusqueda = itemsMenu.stream().filter(item -> item.getPrecio() >= precioInferior && item.getPrecio() <= precioSuperior)
                .collect(Collectors.toCollection(ArrayList::new));

        if(resultadosBusqueda.isEmpty()){
            throw new ItemNoEncontradoException("\nNo se encontraron items dentro del rango de precios " + precioInferior + " - " + precioSuperior + ".");
        }

        return resultadosBusqueda;
    }

    @Override
    public ArrayList<ItemMenu> buscarPorRestaurante(String filtroRestaurante) throws ItemNoEncontradoException {

        ArrayList<ItemMenu> resultadosPorRestaurante = itemsMenu.stream().filter(item -> item.getVendedor().getId().equalsIgnoreCase(filtroRestaurante) ||
                        item.getVendedor().getNombre().equals(filtroRestaurante)).collect(Collectors.toCollection(ArrayList::new));

        if(resultadosPorRestaurante.isEmpty()){
            throw new ItemNoEncontradoException("\nNo se encontaron items correspondientes al restaurante " + filtroRestaurante + ".");
        }

        return resultadosPorRestaurante;
    }

    // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    // SIMULACION DE BASE DE DATOS.

    // CREACION DE INSTANCIAS - ENTREGA N° 1:

    //Creacion de coordenadas para las instancias de vendedores:
    Coordenada c1 = new Coordenada(1,2);
    Coordenada c2 = new Coordenada(3,4);
    Coordenada c3 = new Coordenada(5,6);

    Vendedor v1 = new Vendedor("123","Pablo","9 de Julio 1234",c1);
    Vendedor v2 = new Vendedor("456","Sofia","Junin 4567",c2);
    Vendedor v3 = new Vendedor("789","Victoria","Santiago del Estero 7890",c3);

    //Creacion de coordenadas para las instancias de clientes:
    Coordenada c4 = new Coordenada(-1,-2);
    Coordenada c5 = new Coordenada(-3,-4);
    Coordenada c6 = new Coordenada(-5,-6);

    Cliente cl1 = new Cliente("001","Francisco","12345678912","hola@gmail.com","Saavedra 1800",c4);
    Cliente cl2 = new Cliente("002","Juan","98765432134","chau@gmail.com","4 de Enero 1528",c5);
    Cliente cl3 = new Cliente("003","Agustina","19283746556","ejemplo@gmail.com","Francia 9992",c6);

    // Creacion de un vendedor y un cliente aleatorios para testear el metodo de 'distancia()':
    Vendedor vendedorRandom = new Vendedor("777","Roberto","Mendoza 1923",new Coordenada(-74.005974,40.712776));
    Cliente clienteRandom = new Cliente("888","Mario Pereyra","39472611324","marito@ejemplo.com","Av. General Paz 1230",new Coordenada(-118.243683,34.052235));

    // Los datos utilizados en la inicializacion de cada coordenada son datos reales pero que NO aplican al problema (porque no tienen sentido), pero que permiten verificar la
    // validez del metodo de 'distancia()', ya que utilizando algun software en internet que aplique la formula de Haversine, se puede comprobar que el valor obtenido es correcto.

    // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    // CREACION DE INSTANCIAS - ENTREGA N° 2:

    // Creacion de instancias aleatorias de ItemMenu (Bebidas y Comidas):
    Bebida cocaCola = new Bebida("I001","Coca Cola","Descripción",900,0.0, true, 500); // Gaseosa sin alcohol
    Bebida vino = new Bebida("I002","Vino Tinto","Descripción",2500,12.5, false, 750); // Bebida alcohólica
    Bebida jugoNaranja = new Bebida("I003","Jugo de Naranja","Descripción",1000,0.0, false, 300); // Bebida sin alcohol
    Plato ensalada = new Plato("I004","Ensalada","Descripción",3500,300, 150, true, true); // Comida vegetariana
    Plato milanesa = new Plato("I005","Milanesa con Papas Fritas","Descripción",5000,500, 800, false, false); // Comida no vegetariana

    // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    // CREACION DE INSTANCIAS - ENTREGA N° 3:

    // Ejemplos de Clientes (ESTÁN COMENTADOS PORQUE NO ESTÁN SIENDO UTILIZADOS):
    /*Cliente cliente1 = new Cliente("C001", "Juan Perez", "20234567891", "juan@ejemplo.com", "Calle Falsa 123", new Coordenada(-34.603722, -58.381592));
    Cliente cliente2 = new Cliente("C002", "Maria Gomez", "20123456782", "maria@ejemplo.com", "Av. Siempre Viva 742", new Coordenada(-34.6083, -58.3712));
    Cliente cliente3 = new Cliente("C003", "Pedro Martinez", "20345678903", "pedro@ejemplo.com", "Pavon 5621", new Coordenada(-34.6100, -58.3800));
    Cliente cliente4 = new Cliente("C004", "Ana Lopez", "20456789014", "ana@ejemplo.com", "Bv. Las Grevileas 3480", new Coordenada(-34.6150, -58.3700));
    Cliente cliente5 = new Cliente("C005", "Carlos Jimenez", "20567890125", "carlos@ejemplo.com", "San Lorenzo 1580", new Coordenada(-34.6200, -58.3900));
    Cliente cliente6 = new Cliente("C006", "Laura Fernandez", "20678901236", "laura@ejemplo.com", "Av. Belgrano 2345", new Coordenada(-34.6250, -58.3650));
    Cliente cliente7 = new Cliente("C007", "Ricardo Sanchez", "20789012347", "ricardo@ejemplo.com", "Calle Alsina 456", new Coordenada(-34.6300, -58.3750));
    Cliente cliente8 = new Cliente("C008", "Lucia Herrera", "20890123458", "lucia@ejemplo.com", "Av. Corrientes 900", new Coordenada(-34.6350, -58.3850));*/

    // Ejemplos de Vendedores:
    Vendedor vendedor1 = new Vendedor("V001", "La Dominga", "Javier de la Rosa 101", new Coordenada(-34.603722, -58.381592));
    Vendedor vendedor2 = new Vendedor("V002", "El Nacional", "Ituzaingó 1090", new Coordenada(-34.6100, -58.3700));
    Vendedor vendedor3 = new Vendedor("V003", "Paprika", "San Martin 1707", new Coordenada(-34.6150, -58.3600));
    Vendedor vendedor4 = new Vendedor("V004", "Bilbao Amarras", "Calle 1º de Enero 27", new Coordenada(-34.6200, -58.3500));
    Vendedor vendedor5 = new Vendedor("V005", "Dr. Jekyll", "Marcial Candioti 3414", new Coordenada(-34.6250, -58.3400));
    Vendedor vendedor6 = new Vendedor("V006", "La Cabaña", "Av. Libertador 5900", new Coordenada(-34.6300, -58.3300));
    Vendedor vendedor7 = new Vendedor("V007", "El Almacén", "Calle Florida 102", new Coordenada(-34.6350, -58.3200));
    Vendedor vendedor8 = new Vendedor("V008", "La Terraza", "Belgrano 2001", new Coordenada(-34.6400, -58.3100));

    // Ejemplos de Bebidas:
    Bebida bebida1 = new Bebida("IMB001","Agua Mineral","Descripción",1200,0.0, false, 500);
    Bebida bebida2 = new Bebida("IMB002","Jugo de Pomelo","Descripción",1800,0.0, true, 610);
    Bebida bebida3 = new Bebida("IMB003","Whisky","Descripción",20000,55, false, 920);
    Bebida bebida4 = new Bebida("IMB004","Cerveza negra","Descripción",700,0.0, false, 250);
    Bebida bebida5 = new Bebida("IMB005","Fernet","Descripción",12000,45, false, 750);
    Bebida bebida6 = new Bebida("IMB006","Coca Cola","Descripción", 850, 0.0, true, 600);
    Bebida bebida7 = new Bebida("IMB007","Ron Blanco","Descripción", 15000, 40, false, 700);
    Bebida bebida8 = new Bebida("IMB008","Limonada Casera","Descripción", 1200, 0.0, false, 500);
    Bebida bebida9 = new Bebida("IMB009","Cerveza IPA","Descripción", 950, 5.0, false, 473);
    Bebida bebida10 = new Bebida("IMB0010","Gaseosa de Naranja","Descripción", 700, 0.0, true, 500);
    Bebida bebida11 = new Bebida("IMB0011","Gin Tonic", "Descripción",18000, 37.5, false, 750);
    Bebida bebida12 = new Bebida("IMB0012","Sidra Espumante", "Descripción",2200, 4.5, false, 750);
    Bebida bebida13 = new Bebida("IMB0013","Agua Tónica", "Descripción",900, 0.0, true, 350);
    Bebida bebida14 = new Bebida("IMB0014","Vino Malbec", "Descripción",25000, 13.5, false, 750);
    Bebida bebida15 = new Bebida("IMB0015","Vodka","Descripción", 18000, 40, false, 700);
    Bebida bebida16 = new Bebida("IMB0016","Ron con Coca","Descripción",9000,35,true,500);

    // Ejemplos de Platos:
    Plato plato1 = new Plato("IMC001","Pizza Napolitana","Descripción",10500,2000,1899, false, true);
    Plato plato2 = new Plato("IMC002","Sorrentinos de 4 quesos","Descripción",9350,750, 1500, false, true);
    Plato plato3 = new Plato("IMC003","Matambre a la pizza","Descripción",12150,1200, 1050, true, false);
    Plato plato4 = new Plato("IMC004","Sushi","Descripción",12000,500, 850, false, false);
    Plato plato5 = new Plato("IMC005","Helado de Dulce de Leche","Descripción",5700,1000, 2400, true, true);
    Plato plato6 = new Plato("IMC006","Lasaña de Espinaca", "Descripción",8500, 800, 950, false, true);
    Plato plato7 = new Plato("IMC007","Bife de Chorizo con Papas", "Descripción",18500, 1500, 1200, true, false);
    Plato plato8 = new Plato("IMC008","Ensalada César", "Descripción",5000, 400, 600, false, true);
    Plato plato9 = new Plato("IMC009","Risotto de Hongos", "Descripción",11000, 650, 850, false, true);
    Plato plato10 = new Plato("IMC0010","Pollo al Champiñón", "Descripción",12750, 900, 1050, true, false);
    Plato plato11 = new Plato("IMC0011","Tarta de Verduras","Descripción", 6000, 700, 750, false, true);
    Plato plato12 = new Plato("IMC0012","Empanadas de Carne","Descripción", 4000, 500, 650, true, false);
    Plato plato13 = new Plato("IMC0013","Hamburguesa Vegana","Descripción", 9500, 450, 800, true, true);
    Plato plato14 = new Plato("IMC0014","Papas Fritas con Cheddar","Descripción", 3700, 300, 500, false, true);
    Plato plato15 = new Plato("IMC0015","Brownie con Helado","Descripción", 5700, 250, 1200, true, true);
    Plato plato16 = new Plato("IMC0016","Chinchulines a la mostaza", "Descripción",8000, 1450, 1400, true, false);

    // Ejemplos de items pedidos:

    // PARA PEDIDO 1:
    public ItemPedido itemPedido1_1 = new ItemPedido("IT001",plato1);
    public ItemPedido itemPedido1_2 = new ItemPedido("IT002",bebida1);
    public ItemPedido itemPedido1_3 = new ItemPedido("IT029", plato15);
    public ItemPedido itemPedido1_4 = new ItemPedido("IT030", bebida15);

    // PARA PEDIDO 2:
    public ItemPedido itemPedido2_1 = new ItemPedido("IT003",plato2);
    public ItemPedido itemPedido2_2 = new ItemPedido("IT004",bebida2);
    public ItemPedido itemPedido2_3 = new ItemPedido("IT027", plato14);
    public ItemPedido itemPedido2_4 = new ItemPedido("IT028", bebida14);

    // PARA PEDIDO 3:
    public ItemPedido itemPedido3_1 = new ItemPedido("IT005", plato3);
    public ItemPedido itemPedido3_2 = new ItemPedido("IT006", bebida3);
    public ItemPedido itemPedido3_3 = new ItemPedido("IT025", plato13);
    public ItemPedido itemPedido3_4 = new ItemPedido("IT026", bebida13);

    // PARA PEDIDO 4:
    public ItemPedido itemPedido4_1 = new ItemPedido("IT007", plato4);
    public ItemPedido itemPedido4_2 = new ItemPedido("IT008",bebida4);
    public ItemPedido itemPedido4_3 = new ItemPedido("IT023", plato12);
    public ItemPedido itemPedido4_4 = new ItemPedido("IT024", bebida12);

    // PARA PEDIDO 5:
    public ItemPedido itemPedido5_1 = new ItemPedido("IT009",plato5);
    public ItemPedido itemPedido5_2 = new ItemPedido("IT010",bebida5);
    public ItemPedido itemPedido5_3 = new ItemPedido("IT021", plato11);
    public ItemPedido itemPedido5_4 = new ItemPedido("IT022", bebida11);

    // PARA PEDIDO 6:
    public ItemPedido itemPedido6_1 = new ItemPedido("IT011", plato6);
    public ItemPedido itemPedido6_2 = new ItemPedido("IT012", bebida6);
    public ItemPedido itemPedido6_3 = new ItemPedido("IT019", plato10);
    public ItemPedido itemPedido6_4 = new ItemPedido("IT020", bebida10);

    // PARA PEDIDO 7:
    public ItemPedido itemPedido7_1 = new ItemPedido("IT013", plato7);
    public ItemPedido itemPedido7_2 = new ItemPedido("IT014", bebida7);
    public ItemPedido itemPedido7_3 = new ItemPedido("IT017", plato9);
    public ItemPedido itemPedido7_4 = new ItemPedido("IT018", bebida9);

    // PARA PEDIDO 8:
    public ItemPedido itemPedido8_1 = new ItemPedido("IT015", plato8);
    public ItemPedido itemPedido8_2 = new ItemPedido("IT016", bebida8);
    public ItemPedido itemPedido8_3 = new ItemPedido("IT031", plato16);
    public ItemPedido itemPedido8_4 = new ItemPedido("IT032", bebida16);

}