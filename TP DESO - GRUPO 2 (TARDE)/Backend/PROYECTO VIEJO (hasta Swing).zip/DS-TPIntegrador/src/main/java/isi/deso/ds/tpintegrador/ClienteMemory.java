package isi.deso.ds.tpintegrador;

import isi.deso.ds.tpintegrador.models.Cliente;
import isi.deso.ds.tpintegrador.models.Coordenada;
import isi.deso.ds.tpintegrador.repository.ClienteDAO;

import java.util.ArrayList;
import java.util.List;

public class ClienteMemory implements ClienteDAO {
    private List<Cliente> clientes = new ArrayList<>();

    public ClienteMemory() {
        // Cargamos clientes predeterminados
        clientes.add(cliente1);
        clientes.add(cliente2);
        clientes.add(cliente3);
        clientes.add(cliente4);
        clientes.add(cliente5);
        clientes.add(cliente6);
        clientes.add(cliente7);
        clientes.add(cliente8);
    }

    @Override
    public List<Cliente> listarCliente() {
        return new ArrayList<>(clientes);
    }

    @Override
    public boolean crearCliente(Cliente cliente) {
        if (buscarCliente(cliente.getId()) == null) { // Verificar si el ID ya existe
            return clientes.add(cliente);
        }
        return false; // No se agregó porque el ID ya existe.
    }

    @Override
    public boolean actualizarCliente(Cliente cliente) {
        Cliente existente = buscarCliente(cliente.getId());
        if (existente != null) {
            existente.setNombre(cliente.getNombre());
            existente.setCuit(cliente.getCuit());
            existente.setEmail(cliente.getEmail());
            existente.setDireccion(cliente.getDireccion());
            existente.setCoordenadas(cliente.getCoordenadas());
            return true;
        }
        return false;
    }

    @Override
    public boolean eliminarCliente(String id) {
        Cliente cliente = buscarCliente(id);
        if (cliente != null) {
            return clientes.remove(cliente);
        }
        return false;
    }

    @Override
    public Cliente buscarCliente(String id) {
        for (Cliente cliente : clientes) {
            if (cliente.getId().equals(id)) {
                return cliente;
            }
        }
        return null;
    }

    @Override
    public List<Cliente> buscarClientePorParametro(String parametro, String valor) {
        List<Cliente> resultado = new ArrayList<>();

        for (Cliente cliente : clientes) {

            switch (parametro.toLowerCase()) {
                case "id":
                    if (cliente.getId().equals(valor)) resultado.add(cliente);
                    break;
                case "nombre":
                    if (cliente.getNombre().equalsIgnoreCase(valor)) resultado.add(cliente);
                    break;
                case "cuit":
                    if (cliente.getCuit().equals(valor)) resultado.add(cliente);
                    break;
                case "email":
                    if (cliente.getEmail().equalsIgnoreCase(valor)) resultado.add(cliente);
                    break;
                case "dirección":
                    if  (cliente.getDireccion().toLowerCase().contains(valor.toLowerCase())) resultado.add(cliente);
                    break;
            }
        }
        return resultado;
    }

    // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    // SIMULACION DE BASE DE DATOS DE CLIENTES:

    // Ejemplos de clientes:

    Cliente cliente1 = new Cliente("C001", "Juan Perez", "20234567891", "juan@ejemplo.com", "Calle Falsa 123", new Coordenada(-34.603722, -58.381592));
    Cliente cliente2 = new Cliente("C002", "Maria Gomez", "20123456782", "maria@ejemplo.com", "Av. Siempre Viva 742", new Coordenada(-34.6083, -58.3712));
    Cliente cliente3 = new Cliente("C003", "Pedro Martinez", "20345678903", "pedro@ejemplo.com", "Pavon 5621", new Coordenada(-34.6100, -58.3800));
    Cliente cliente4 = new Cliente("C004", "Ana Lopez", "20456789014", "ana@ejemplo.com", "Bv. Las Grevileas 3480", new Coordenada(-34.6150, -58.3700));
    Cliente cliente5 = new Cliente("C005", "Carlos Jimenez", "20567890125", "carlos@ejemplo.com", "San Lorenzo 1580", new Coordenada(-34.6200, -58.3900));
    Cliente cliente6 = new Cliente("C006", "Laura Fernandez", "20678901236", "laura@ejemplo.com", "Av. Belgrano 2345", new Coordenada(-34.6250, -58.3650));
    Cliente cliente7 = new Cliente("C007", "Ricardo Sanchez", "20789012347", "ricardo@ejemplo.com", "Calle Alsina 456", new Coordenada(-34.6300, -58.3750));
    Cliente cliente8 = new Cliente("C008", "Lucia Herrera", "20890123458", "lucia@ejemplo.com", "Av. Corrientes 900", new Coordenada(-34.6350, -58.3850));

}