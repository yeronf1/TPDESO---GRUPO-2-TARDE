package isi.deso.ds.tpintegrador;

import java.sql.*;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.ArrayList;

import isi.deso.ds.tpintegrador.models.*;
import isi.deso.ds.tpintegrador.config.ConexionDB;
import isi.deso.ds.tpintegrador.repository.ItemsMenuDAO;

public class ItemsMenuJDBC implements ItemsMenuDAO {

    @Override
    public List<ItemMenu> listarItemsMenu() {
        List<ItemMenu> items = new ArrayList<>();
        String query = "SELECT * FROM items_menu";

        // Obtenemos la conexión a la base de datos:
        try (Connection conn = ConexionDB.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            // Iteramos sobre el resultado de la consulta:
            while (rs.next()) {
                ItemMenu item;

                // Determinamos la subclase según el tipo de ítem:
                String tipoItem = rs.getString("categoria");
                if ("COMIDA".equalsIgnoreCase(tipoItem)) {
                    item = new Plato(
                            rs.getString("id"),
                            rs.getString("nombre"),
                            rs.getString("descripcion"),
                            rs.getDouble("precio"),
                            rs.getDouble("peso"),
                            rs.getInt("calorias"),
                            rs.getBoolean("apto_celiaco"),
                            rs.getBoolean("apto_vegetariano")
                    );
                } else if ("BEBIDA".equalsIgnoreCase(tipoItem)) {
                    item = new Bebida(
                            rs.getString("id"),
                            rs.getString("nombre"),
                            rs.getString("descripcion"),
                            rs.getDouble("precio"),
                            rs.getDouble("graduacion_alcoholica"),
                            rs.getBoolean("es_gaseosa"),
                            rs.getDouble("volumen")
                    );
                } else {
                    throw new IllegalArgumentException("Tipo de ítem desconocido: " + tipoItem);
                }

                // Agregamos el ítem a la lista:
                items.add(item);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar ítems menú: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Opcionalmente, cerramos la conexión de forma explícita:
            ConexionDB.desconectar();
        }
        return items;
    }

    @Override
    public boolean crearItemsMenu(ItemMenu item) {
        String insertarVendedorQuery = "INSERT INTO vendedor (nombre) VALUES (?)";
        String query;

        // Consultas para insertar el ítem en la tabla según categoría:
        if (item instanceof Plato) {
            query = "INSERT INTO items_menu (nombre, categoria, descripcion, precio, calorias, peso, apto_vegetariano, apto_celiaco, vendedor_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        } else if (item instanceof Bebida) {
            query = "INSERT INTO items_menu (nombre, categoria, descripcion, precio, graduacion_alcoholica, volumen, es_gaseosa, vendedor_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        } else {
            throw new IllegalArgumentException("Tipo de ítem desconocido: " + item.getClass().getSimpleName());
        }

        try (Connection conn = ConexionDB.conectar()) {
            // Iniciamos la transacción:
            conn.setAutoCommit(false);

            // Creamos un nuevo vendedor con el nombre "usuarioActual" para hacerlo genérico (luego hay que implementar inicio de sesión).
            int vendedorId;
            try (PreparedStatement stmtVendedor = conn.prepareStatement(insertarVendedorQuery, Statement.RETURN_GENERATED_KEYS)) {
                stmtVendedor.setString(1, "VendedorActual");
                int affectedRows = stmtVendedor.executeUpdate();

                if (affectedRows > 0) {
                    try (ResultSet generatedKeys = stmtVendedor.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            vendedorId = generatedKeys.getInt(1); // Obtenemos el ID del nuevo vendedor.
                        } else {
                            conn.rollback();
                            throw new SQLException("Fallo al obtener el ID del nuevo vendedor.");
                        }
                    }
                } else {
                    conn.rollback();
                    throw new SQLException("Fallo al insertar el nuevo vendedor.");
                }
            }

            // Insertamos el ítem asociado al vendedor nuevo:
            try (PreparedStatement stmtItem = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                stmtItem.setString(1, item.getNombre());
                stmtItem.setString(2, item.getCategoria().getTipoItem().toString());
                stmtItem.setString(3, item.getDescripcion());
                stmtItem.setDouble(4, item.getPrecio());

                if (item instanceof Plato) {
                    Plato plato = (Plato) item;
                    stmtItem.setInt(5, plato.getCalorias());
                    stmtItem.setDouble(6, plato.peso());
                    stmtItem.setBoolean(7, plato.getAptoVegetariano());
                    stmtItem.setBoolean(8, plato.getAptoCeliaco());
                    stmtItem.setInt(9, vendedorId);
                } else {
                    Bebida bebida = (Bebida) item;
                    stmtItem.setDouble(5, bebida.getGraduacionAlcoholica());
                    stmtItem.setDouble(6, bebida.getVolumen());
                    stmtItem.setBoolean(7, bebida.getEsGaseosa());
                    stmtItem.setInt(8, vendedorId);
                }

                int affectedRows = stmtItem.executeUpdate();

                if (affectedRows > 0) {
                    try (ResultSet generatedKeys = stmtItem.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            int idGenerado = generatedKeys.getInt(1);
                            item.setId("C00" + idGenerado);
                        }
                    }
                    // Confirmamos la transacción:
                    conn.commit();
                    return true;
                } else {
                    conn.rollback();
                    return false;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al crear ítem o vendedor: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean actualizarItemsMenu(ItemMenu item) {
        String query = "UPDATE items_menu SET nombre = ?, descripcion = ?, precio = ?, categoria = ?, "
                + "peso = ?, calorias = ?, apto_celiaco = ?, apto_vegetariano = ?, "
                + "graduacion_alcoholica = ?, es_gaseosa = ?, volumen = ? WHERE id = ?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            // Seteamos los atributos comunes a todos los ítems:
            pstmt.setString(1, item.getNombre());
            pstmt.setString(2, item.getDescripcion());
            pstmt.setDouble(3, item.getPrecio());
            pstmt.setString(4, item.getCategoria().getTipoItem().name());

            // Inicializamos y seteamos los valores específicos según el tipo de ítem:
            if (item instanceof Plato) {
                Plato plato = (Plato) item;
                pstmt.setDouble(5, plato.peso());
                pstmt.setInt(6, plato.getCalorias());
                pstmt.setBoolean(7, plato.getAptoCeliaco());
                pstmt.setBoolean(8, plato.getAptoVegetariano());

                // Valores nulos para los atributos específicos de Bebida:
                pstmt.setNull(9, java.sql.Types.DOUBLE); // graduacion_alcoholica
                pstmt.setNull(10, java.sql.Types.BOOLEAN); // es_gaseosa
                pstmt.setNull(11, java.sql.Types.DOUBLE); // volumen
            } else if (item instanceof Bebida) {
                Bebida bebida = (Bebida) item;
                pstmt.setNull(5, java.sql.Types.DOUBLE); // peso
                pstmt.setNull(6, java.sql.Types.INTEGER); // calorias
                pstmt.setNull(7, java.sql.Types.BOOLEAN); // apto_celiaco
                pstmt.setBoolean(8, bebida.aptoVegetariano());
                pstmt.setDouble(9, bebida.getGraduacionAlcoholica());
                pstmt.setBoolean(10, bebida.getEsGaseosa());
                pstmt.setDouble(11, bebida.getVolumen());
            } else {
                // Si no es ni Plato ni Bebida, lanzamos una excepción:
                throw new IllegalArgumentException("Tipo de ítem desconocido: " + item.getClass().getSimpleName());
            }

            // ID del ítem:
            pstmt.setString(12, item.getId());
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar ítem: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean eliminarItemsMenu(String id) {
        String query = "DELETE FROM items_menu WHERE id = ?";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, id);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar el ítem de menú con ID: " + id);
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public ItemMenu buscarItemsMenu(String id) {
        String query = "SELECT * FROM items_menu WHERE id = ?";

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String tipoItem = rs.getString("categoria");
                    ItemMenu item;

                    if ("COMIDA".equalsIgnoreCase(tipoItem)) {
                        item = new Plato(
                                rs.getString("id"),
                                rs.getString("nombre"),
                                rs.getString("descripcion"),
                                rs.getDouble("precio"),
                                rs.getDouble("peso"),
                                rs.getInt("calorias"),
                                rs.getBoolean("apto_celiaco"),
                                rs.getBoolean("apto_vegetariano")
                        );
                    } else if ("BEBIDA".equalsIgnoreCase(tipoItem)) {
                        item = new Bebida(
                                rs.getString("id"),
                                rs.getString("nombre"),
                                rs.getString("descripcion"),
                                rs.getDouble("precio"),
                                rs.getDouble("graduacion_alcoholica"),
                                rs.getBoolean("es_gaseosa"),
                                rs.getDouble("volumen")
                        );
                    } else {
                        throw new IllegalArgumentException("Tipo de ítem desconocido: " + tipoItem);
                    }
                    return item;
                }
            }


        } catch (SQLException e) {
            System.err.println("Error al buscar ítem: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<ItemMenu> buscarItemMenuporParametro(String parametro, String valor) {
        List<ItemMenu> items = new ArrayList<>();
        String query = "SELECT * FROM items_menu WHERE " + parametro + " = ?";


        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, valor);
            try (ResultSet rs = stmt.executeQuery()){
                while (rs.next()) {
                    String tipoItem = rs.getString("categoria");
                    ItemMenu item;

                    if ("COMIDA".equalsIgnoreCase(tipoItem)) {
                        item = new Plato(
                                rs.getString("id"),
                                rs.getString("nombre"),
                                rs.getString("descripcion"),
                                rs.getDouble("precio"),
                                rs.getDouble("peso"),
                                rs.getInt("calorias"),
                                rs.getBoolean("apto_celiaco"),
                                rs.getBoolean("apto_vegetariano")
                        );
                    } else if ("BEBIDA".equalsIgnoreCase(tipoItem)) {
                        item = new Bebida(
                                rs.getString("id"),
                                rs.getString("nombre"),
                                rs.getString("descripcion"),
                                rs.getDouble("precio"),
                                rs.getDouble("graduacion_alcoholica"),
                                rs.getBoolean("es_gaseosa"),
                                rs.getDouble("volumen")
                        );
                    } else {
                        throw new IllegalArgumentException("Tipo de ítem desconocido: " + tipoItem);
                    }

                    items.add(item);
                }
            }


        } catch (SQLException e) {
            System.err.println("Error al buscar ítem por parámetro: " + e.getMessage());
            e.printStackTrace();
        }

        return items;
    }

}