package isi.deso.ds.tpintegrador.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {

    private static Connection con = null; // Ya inicializamos en null (la 'reseteamos') a la base de datos.

    // Declaramos los datos de conexión a la base de datos:
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/bd_desarrollo";
    private static final String USER = "nuestroUser";
    private static final String PASSWORD = "tpdds2024";

    // Metodo para conectar a la base de datos:
    public static Connection conectar() {
        try {
            if (con == null || con.isClosed()) {
                Class.forName(DRIVER); // Nos conectamos a la base de datos utilizando el driver.
                con = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Conexión establecida."); // Si la conexión fue exitosa mostramos un mensaje de éxito.
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error al conectar: " + e.getMessage()); // Si la conexión NO fue exitosa mostramos un mensaje de error.
        }
        return con;
    }

    // Metodo para cerrar la conexión (no es realmente necesario):
    public static void desconectar() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("Conexión cerrada.");
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar conexión: " + e.getMessage());
        }
    }
}


