package isi.deso.ds.tpintegrador.models;

import java.util.Iterator;
import java.util.ArrayList;

public class Vendedor {

    private String id;
    private String nombre;
    private String direccion;
    private Coordenada coordenadas;
    private ArrayList<ItemMenu> itemsMenu;
    
    // GETTERS Y SETTERS:


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Coordenada getCoordenadas() {
        return coordenadas;
    }

    public void setCoordenadas(Coordenada coordenadas) {
        this.coordenadas = coordenadas;
    }

    public ArrayList<ItemMenu> getItemsMenu() {
        return itemsMenu;
    }

    public void setItemsMenu(ArrayList<ItemMenu> itemsMenu) {
        this.itemsMenu = itemsMenu;
    }

    // CONSTRUCTORES:
    
    public Vendedor(){
        this.itemsMenu = new ArrayList<>();
    }

    // El siguiente constructor no tiene como argumento la lista de ItemsMenu ya que para ello creamos un metodo que permita ir agregando cuántos items quieran agregarse.
    public Vendedor(String id, String nombre, String direccion, Coordenada coordenadas) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.coordenadas = coordenadas;
        this.itemsMenu = new ArrayList<>();
    }

    // Metodo para agregar items a una lista de ItemsMenu.
    public void agregarItem(ItemMenu item) {
        item.setVendedor(this); // Le asignamos al itemMenu agregado el respectivo vendedor que lo agrego.
        this.itemsMenu.add(item);
    }
    
    // Metodo para calcular la distancia (en kilometros) entre dos puntos (lat1, lon1) y (lat2, lon2) usando una implementación de la fórmula de Haversine:
    public double distancia(Cliente cliente){
        final double R = 6371.0088; // Radio de la tierra en kilómetros.
        
        // Convertimos las latitudes y longitudes de grados a radianes.
        double lat1Rad = Math.toRadians(this.coordenadas.getLAT());
        double lon1Rad = Math.toRadians(this.coordenadas.getLNG());
        double lat2Rad = Math.toRadians(cliente.getCoordenadas().getLAT());
        double lon2Rad = Math.toRadians(cliente.getCoordenadas().getLNG());

        double dlon = lon2Rad - lon1Rad;
        double dlat = lat2Rad - lat1Rad;

        // Aplicamos la fórmula de Haversine:
        double a = Math.sin(dlat / 2) * Math.sin(dlat / 2) + Math.cos(lat1Rad) * Math.cos(lat2Rad) * Math.sin(dlon / 2) * Math.sin(dlon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));      
        
        // Obtenemos la distancia en kilómetros:
        return R * c;
    }

    // Metodo para obtener la lista de bebidas:
    public ArrayList<ItemMenu> getListaBebidas(){
        ArrayList<ItemMenu> listaBebidas = new ArrayList<>();

        Iterator<ItemMenu> iterador = this.itemsMenu.iterator();

        ItemMenu itemActual;

        while(iterador.hasNext()){
            itemActual = iterador.next();

            if(itemActual.esBebida()){
                listaBebidas.add(itemActual);
            }
        }

        return listaBebidas;
    }

    // Metodo para obtener la lista de comidas:
    public ArrayList<ItemMenu> getListaComidas(){
        ArrayList<ItemMenu> listaComidas = new ArrayList<>();

        Iterator<ItemMenu> iterador = this.itemsMenu.iterator();

        ItemMenu itemActual;

        while(iterador.hasNext()){
            itemActual = iterador.next();

            if(itemActual.esComida()){
                listaComidas.add(itemActual);
            }
        }

        return listaComidas;
    }

    // Metodo para obtener la lista de comidas vegetarianas:
    public ArrayList<ItemMenu> getListaComidasVegetarianas(){
        ArrayList<ItemMenu> listaComidasVegetarianas = new ArrayList<>();

        Iterator<ItemMenu> iterador = this.itemsMenu.iterator();

        ItemMenu itemActual;

        while(iterador.hasNext()){
            itemActual = iterador.next();

            if(itemActual.esComida() && itemActual.aptoVegetariano()){
                listaComidasVegetarianas.add(itemActual);
            }
        }

        return listaComidasVegetarianas;
    }

    // Metodo para obtener la lista de bebidas sin alcohol:
    public ArrayList<ItemMenu> getListaBebidasSinAlcohol(){
        ArrayList<ItemMenu> ListaBebidasSinAlcohol = new ArrayList<>();

        Iterator<ItemMenu> iterador = this.itemsMenu.iterator();

        ItemMenu itemActual;

        while(iterador.hasNext()){
            itemActual = iterador.next();

            if(itemActual.esBebida() && ((Bebida) itemActual).getGraduacionAlcoholica()==0){
                ListaBebidasSinAlcohol.add(itemActual);

            }
        }

        return ListaBebidasSinAlcohol;
    }

    
}