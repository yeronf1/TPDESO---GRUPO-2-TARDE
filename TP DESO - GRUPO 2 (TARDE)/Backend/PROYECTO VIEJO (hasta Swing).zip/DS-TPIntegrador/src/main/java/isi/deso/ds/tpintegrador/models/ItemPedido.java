package isi.deso.ds.tpintegrador.models;

public class ItemPedido {

    private String codigo;
    private ItemMenu itemMenu;

    // GETTERS Y SETTERS:

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public ItemMenu getItemMenu() {
        return itemMenu;
    }

    public void setItemMenu(ItemMenu itemMenu) {
        this.itemMenu = itemMenu;
    }

    public ItemPedido() {
    }

    public ItemPedido(ItemMenu itemMenu) {
        this.itemMenu = itemMenu;
    }

    public ItemPedido(String codigo, ItemMenu itemMenu) {
        this.codigo = codigo;
        this.itemMenu = itemMenu;
    }

}
