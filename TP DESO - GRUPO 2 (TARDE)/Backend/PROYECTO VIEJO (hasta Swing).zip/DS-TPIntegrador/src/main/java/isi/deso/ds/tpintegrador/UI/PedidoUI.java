package isi.deso.ds.tpintegrador.UI;

import javax.swing.*;
import javax.swing.table.*;
import java.util.List;
import java.util.ArrayList;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import isi.deso.ds.tpintegrador.PedidosJDBC;
import isi.deso.ds.tpintegrador.models.*;
import isi.deso.ds.tpintegrador.models.enums.Estado;
import isi.deso.ds.tpintegrador.repository.PedidoDAO;
import isi.deso.ds.tpintegrador.controllers.PedidosController;

public class PedidoUI extends JFrame {
    private final PedidosController controller;
    private JTextField campoBusqueda;
    private JButton botonCrear;
    private JTable tablaPedidos;
    private static DefaultTableModel modeloTabla;

    // Clase main para ejecutar interfaz:
    public static void main(String[] args) {

        PedidoDAO pedidoDAO = new PedidosJDBC(); // Instanciamos un DAO asociado a su implementacion.
        PedidosController pedidoController = new PedidosController(pedidoDAO); // Instanciamos un controlador utilizando el DAO recien creado en su constructor.

        SwingUtilities.invokeLater(() -> {
            PedidoUI ui = new PedidoUI(pedidoController); // Instanciamos la interfaz pasandole el controlador recien creado como argumento.
            ui.setVisible(true); // Hacemos visible la interfaz al usuario.
        });
    }

    public PedidoUI(PedidosController controller) {
        this.controller = controller;
        iniciarUI(); // Para inicializar la interfaz.
    }

    private void iniciarUI() {
        setTitle("Gestión de Pedidos");
        setSize(1200, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Para centrar la ventana.

        // Configuración del Layout principal:
        setLayout(new BorderLayout());

        // Creamos y agregamos el menú lateral para moverse entre interfaces:
        JPanel menuLateral = MenuLateral.crearMenuLateral(this);
        add(menuLateral,BorderLayout.WEST);

        // Panel superior que contiene el título, botón de crear y buscador:
        JPanel panelSuperior = new JPanel(new BorderLayout());

        // Sub-panel para el título:
        JPanel panelTitulo = new JPanel();
        panelTitulo.setLayout(new BoxLayout(panelTitulo, BoxLayout.Y_AXIS));
        panelTitulo.setBackground(new Color(0x2169AC));
        panelTitulo.setPreferredSize(new Dimension(0, 50));

        JLabel tituloPrincipal = new JLabel("Lista de Pedidos");
        tituloPrincipal.setForeground(Color.WHITE);
        tituloPrincipal.setFont(new Font("Arial", Font.BOLD, 18));
        tituloPrincipal.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Acomodamos el titlo en su panel (centrado):
        panelTitulo.add(Box.createVerticalGlue()); // Espacio flexible arriba.
        panelTitulo.add(tituloPrincipal);
        panelTitulo.add(Box.createVerticalGlue()); // Espacio flexible abajo.

        // Añadimos el titlePanel al lado superior del panel superior:
        panelSuperior.add(panelTitulo, BorderLayout.NORTH);

        // Sub-panel para el botón "Crear Nuevo Pedido" alineado a la izquierda:
        JPanel panelIzquierdo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelIzquierdo.setBorder(BorderFactory.createEmptyBorder(10, 88, 0, 0));

        botonCrear = new JButton("Crear nuevo pedido");
        botonCrear.setMargin(new Insets(0, 0, 0, 0)); // Le sacamos bordes internos al boton.
        panelIzquierdo.add(botonCrear); // Agregamos el boton al panel izquierdo.

        // Sub-panel para el campo 'buscador' alineado a la derecha:
        JPanel panelDerecho = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelDerecho.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel searchLabel = new JLabel("Buscador:");
        campoBusqueda = new JTextField(20);
        panelDerecho.add(searchLabel); // Agregamos el texto 'Buscador' al panel.
        panelDerecho.add(campoBusqueda); // Agregamos el campo de busqueda al panel.

        // Añadimos los sub-paneles al panel superior:
        panelSuperior.add(panelIzquierdo, BorderLayout.WEST);
        panelSuperior.add(panelDerecho, BorderLayout.EAST);

        // Agregamos márgenes al panel superior para que coincida con los de la tabla:
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

        // Añadimos el panel superior al BorderLayout.NORTH del panel principal:
        add(panelSuperior, BorderLayout.NORTH);

        // Configuramos la tabla:
        String[] columnNames = {"ID", "Cliente", "Fecha de pago", "Costo total" ,"Estado","Acción 1","Acción 2","Acción 3"}; // Las acciones 1, 2 y 3 corresponden a modificar estado, editar y eliminar respectivamente.
        modeloTabla = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5 || column == 6 || column == 7; // Hacemos que solo las celdas de modificar estado, editar y eliminar sean editables (presionables).
            }
        };

        tablaPedidos = new JTable(modeloTabla); // Declaramos un nuevo panel de tabla con el modelo que creamos antes.
        tablaPedidos.setRowHeight(30); // Le damos la altura que queremos a las filas de la tabla.

        // Configuramos la altura de la fila de los encabezados de las columnas:
        JTableHeader encabezado = tablaPedidos.getTableHeader();
        encabezado.setPreferredSize(new Dimension(encabezado.getWidth(), 40));
        encabezado.setDefaultRenderer(new encabezadoPersonalizado());

        // Cambiamos el color de los bordes externos del encabezado para que coincida con el color de los bordes externos de la tabla:
        encabezado.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        // Establecemos el color de la cuadrícula y lo mostramos:
        tablaPedidos.setGridColor(Color.BLACK);
        tablaPedidos.setShowGrid(true);

        // Creamos un borde personalizado para la tabla:
        tablaPedidos.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.BLACK, 2),
                BorderFactory.createEmptyBorder(0, 0, 2, 0)
        ));

        // Configuramos los anchos específicos para cada columna:
        tablaPedidos.getColumnModel().getColumn(0).setPreferredWidth(30);
        tablaPedidos.getColumnModel().getColumn(1).setPreferredWidth(150);
        tablaPedidos.getColumnModel().getColumn(2).setPreferredWidth(100);
        tablaPedidos.getColumnModel().getColumn(3).setPreferredWidth(100);
        tablaPedidos.getColumnModel().getColumn(4).setPreferredWidth(100);
        tablaPedidos.getColumnModel().getColumn(5).setPreferredWidth(120);
        tablaPedidos.getColumnModel().getColumn(6).setPreferredWidth(120);
        tablaPedidos.getColumnModel().getColumn(7).setPreferredWidth(60);

        // Creamos un renderizador para centrar todos los textos dentro de la tabla:
        DefaultTableCellRenderer renderizadoCentrado = new DefaultTableCellRenderer();
        renderizadoCentrado.setHorizontalAlignment(SwingConstants.CENTER);

        // Aplicamos el renderizador a todas las columnas:
        for (int i = 0; i < tablaPedidos.getColumnCount(); i++) {
            tablaPedidos.getColumnModel().getColumn(i).setCellRenderer(renderizadoCentrado);
        }

        // Añadimos boton de "Actualizar estado" en la columna de "Accion 1":
        tablaPedidos.getColumn("Acción 1").setCellRenderer(new BotonRenderer());
        tablaPedidos.getColumn("Acción 1").setCellEditor(new BotonEditor(new JCheckBox(), "ActualizarEstado"));

        // Añadimos boton de "Editar" en la columna de "Accion 2":
        tablaPedidos.getColumn("Acción 2").setCellRenderer(new BotonRenderer());
        tablaPedidos.getColumn("Acción 2").setCellEditor(new BotonEditor(new JCheckBox(), "VerDetalle"));

        // Añadimos boton de "Eliminar" en la columna de "Accion 3":
        tablaPedidos.getColumn("Acción 3").setCellRenderer(new BotonRenderer());
        tablaPedidos.getColumn("Acción 3").setCellEditor(new BotonEditor(new JCheckBox(), "Eliminar"));

        // Le agregamos una barra de scroll a la tabla de pedidos:
        JScrollPane panelScroll = new JScrollPane(tablaPedidos);
        panelScroll.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        add(panelScroll, BorderLayout.CENTER);

        // Creamos los listeners (de eventos) de los botones:
        assert botonCrear != null;
        botonCrear.addActionListener(e -> crearPedido());

        assert campoBusqueda != null;
        campoBusqueda.addActionListener(e -> buscarPedido());

        cargarDatosEnTabla();
    }

    // Metodo constructor para poder utilizar en DetallePedidoUI:
    public PedidosController getController() {
        return controller;
    }

    // Metodo para cargar datos en la tabla al iniciar la interfaz.
    public void cargarDatosEnTabla() {
        modeloTabla.setRowCount(0); // Limpiamos tabla antes de cargar nuevos datos.

        // Obtenemos la lista de pedidos del controlador y los añadimos a la tabla:
        for (Pedido pedido : controller.mostrarListaPedidos()) {

            modeloTabla.addRow(new Object[]{
                    pedido.getIdPedido(),
                    pedido.getCliente().getNombre(),
                    pedido.getFormaDePago().getFechaPago(),
                    "$" + pedido.calcularTotal(),
                    pedido.getEstadoPedido(),
                    "Actualizar estado",
                    "Ver detalle",
                    "Eliminar"
            });
        }
    }

    public void crearPedido() {
        try {
            // Recuperamos los ítems desde la base de datos
            List<ItemMenu> itemsMenu = controller.obtenerItemsMenu();

            // Creamos una lista dinámica para almacenar los componentes del mensaje:
            ArrayList<Object> messageList = new ArrayList<>();
            messageList.add("Seleccione los items para el pedido:");

            // Creamos una lista para almacenar los JCheckBox y sus referencias a los ItemPedido:
            ArrayList<JCheckBox> checkBoxes = new ArrayList<>();

            // Variables de control para añadir los encabezados "Comidas:" y "Bebidas:".
            boolean comidasAgregadas = false;
            boolean bebidasAgregadas = false;

            // Creamos JCheckBox para cada ItemMenu y los añadimos con encabezados:
            for (ItemMenu item : itemsMenu) {
                // Determina si el item es de tipo comida o bebida.
                if (item.getCategoria().equals("COMIDA") && !comidasAgregadas) {
                    // Agrega el encabezado "Comidas:" una sola vez al inicio de las comidas.
                    messageList.add(new JLabel("Comidas:"));
                    comidasAgregadas = true;
                } else if (item.getCategoria().equals("BEBIDA") && !bebidasAgregadas) {
                    // Agrega el encabezado "Bebidas:" una sola vez al inicio de las bebidas.
                    messageList.add(new JLabel("Bebidas:"));
                    bebidasAgregadas = true;
                }

                // Creamos el JCheckBox correspondiente al item.
                JCheckBox checkBox = new JCheckBox(
                        "* " + item.getNombre() + " - Precio: $" + item.getPrecio(),
                        false);

                // Añadimos una propiedad al JCheckBox para almacenar el ItemPedido correspondiente.
                ItemPedido itemPedido = new ItemPedido(item);  // Creas un ItemPedido con el ItemMenu correspondiente
                checkBox.putClientProperty("ItemPedido", itemPedido);
                messageList.add(checkBox);
                checkBoxes.add(checkBox);  // Guardamos el JCheckBox en una lista para futuras referencias.
            }

            // Convierte la lista dinámica en un arreglo para el cuadro de diálogo.
            Object[] message = messageList.toArray();

            // Muestra el cuadro de diálogo.
            int option = JOptionPane.showConfirmDialog(this, message, "Crear nuevo pedido", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                // Generamos el ID del pedido en formato "P00x"
                String idPedido = "P00" + (modeloTabla.getRowCount() + 1);

                // Creamos un cliente asociado (ejemplo, se debería asociar al usuario en curso).
                Cliente clienteNuevo = new Cliente(
                        "C00X", "Usuario actual", "11223344556", "usuarioActual@gmail.com",
                        "Calle de UsuarioActual", new Coordenada(-24.061987, -19.032003)
                );

                // Creamos el pedido y agregamos los items seleccionados
                Pedido nuevoPedido = new Pedido(idPedido, clienteNuevo);
                for (JCheckBox checkBox : checkBoxes) {
                    if (checkBox.isSelected()) {
                        // Obtenemos el ItemPedido almacenado en la propiedad del JCheckBox.
                        ItemPedido itemSeleccionado = (ItemPedido) checkBox.getClientProperty("ItemPedido");
                        nuevoPedido.agregarADetalle(itemSeleccionado);
                    }
                }

                // Configuramos la forma de pago y estado del pedido:
                nuevoPedido.setFormaDePago(new MercadoPago());
                nuevoPedido.setEstadoPedido(Estado.RECIBIDO);

                // Guardamos el pedido mediante el controlador y actualizamos la interfaz:
                controller.crearNuevoPedido(nuevoPedido);
                JOptionPane.showMessageDialog(this, "Pedido creado exitosamente.");
                cargarDatosEnTabla();  // Actualizamos la tabla después de crear el pedido.
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al recuperar los ítems del menú.");
            e.printStackTrace();
        }
    }

    public void actualizarTabla(Pedido pedidoActualizado) {
        if (pedidoActualizado == null) {
            // Si no se especifica un pedido, recargamos toda la tabla.
            cargarDatosEnTabla();
        } else {
            // Buscar la fila correspondiente al pedido actualizado.
            for (int i = 0; i < modeloTabla.getRowCount(); i++) {
                if (modeloTabla.getValueAt(i, 0).equals(pedidoActualizado.getIdPedido())) {
                    // Actualizamos las columnas relevantes con los nuevos valores.
                    modeloTabla.setValueAt(pedidoActualizado.getCliente().getNombre(), i, 1); // Cliente
                    modeloTabla.setValueAt(pedidoActualizado.getFormaDePago().getFechaPago(), i, 2); // Fecha de pago
                    modeloTabla.setValueAt("$" + pedidoActualizado.calcularTotal(), i, 3); // Costo total
                    modeloTabla.setValueAt(pedidoActualizado.getEstadoPedido(), i, 4); // Estado del pedido
                    break;
                }
            }
        }
    }

    private void actualizarEstado(int fila) {
        Pedido pedido = controller.mostrarListaPedidos().get(fila);

        // Verificamos si el estado es RECIBIDO antes de actualizar:
        if (pedido.getEstadoPedido() == Estado.RECIBIDO) {
            int respuesta = JOptionPane.showConfirmDialog(
                    null,
                    "¿Estás seguro de que deseas actualizar el estado del pedido " + pedido.getIdPedido() + " a EN_ENVIO?",
                    "Confirmar actualización de estado",
                    JOptionPane.YES_NO_OPTION
            );

            if (respuesta == JOptionPane.YES_OPTION) {
                // Cambiamos el estado del pedido en memoria
                pedido.cambiarEstadoPedido();

                // Persistimos el cambio en la base de datos
                boolean actualizado = controller.actualizarEstadoPedido(pedido.getIdPedido(), Estado.EN_ENVIO);

                if (actualizado) {
                    // Actualizamos la tabla si el cambio fue exitoso
                    modeloTabla.setValueAt(Estado.EN_ENVIO, fila, 4);
                } else {
                    JOptionPane.showMessageDialog(
                            null,
                            "Error al actualizar el estado en la base de datos.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            }
        } else {
            JOptionPane.showMessageDialog(
                    null,
                    "El estado del pedido ya es 'EN_ENVIO'.",
                    "Estado no actualizable.",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    public void verDetalle(int fila) {
        Pedido pedido = controller.getPedidoById(modeloTabla.getValueAt(fila, 0).toString()); // Recupera por ID
        if (pedido != null) {
            new DetallePedidoUI(this, pedido, this);
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró el pedido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void eliminarPedido(int fila) {
        // Obtenemos el ID del pedido desde la tabla. Se sabe que el ID esta en la primera columna (índice 0).
        String idPedido = (String) modeloTabla.getValueAt(fila, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea eliminar el pedido " + idPedido +"?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            controller.eliminarPedido(idPedido);  // Ahora pasamos el ID en lugar de la fila.
            modeloTabla.removeRow(fila);  // También eliminamos la fila de la tabla.
        }
    }

    public void buscarPedido() {
        // Este metodo es para buscar pedidos por su ID o nombre de cliente asociado:
        String filtro = campoBusqueda.getText().trim();

        // Si el campo de búsqueda está vacío, se restauran todos los pedidos:
        if (filtro.isEmpty()) {
            cargarDatosEnTabla(); // Aca se restaura el modelo original de la tabla.
            return; // Hecho eso, salimos del metodo.
        }

        // Si se ha ingresado un filtro de busqueda, se procede a buscar:
        Pedido pedido = controller.buscarPedido(filtro);

        if (pedido != null) {

            modeloTabla.setRowCount(0); // Limpiamos el modelo de la tabla actual para que solo se visualice el pedido encontrado.

            // Añadimos el pedido encontrado al modelo de tabla y mostramos sus detalles:
            Object[] rowData = {pedido.getIdPedido(), pedido.getCliente().getNombre(), pedido.getFormaDePago().getFechaPago(), pedido.calcularTotal(),pedido.getEstadoPedido(),"Actualizar estado" ,"Editar","Eliminar"};
            modeloTabla.addRow(rowData); // Añadir la fila del pedido encontrado

        } else {
            JOptionPane.showMessageDialog(this, "No se ha encontrado un pedido asociado a ese ID o nombre.");
            cargarDatosEnTabla(); // Mostramos todos los pedidos si no se encontraron resultados.
        }
    }

    // Clase interna para renderizado del encabezado de tablas:
    static class encabezadoPersonalizado extends DefaultTableCellRenderer {

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

            JLabel campo = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            campo.setHorizontalAlignment(JLabel.CENTER);
            campo.setOpaque(true);
            campo.setBackground(new Color(0x4C60A2)); // Fondo del encabezado
            campo.setForeground(Color.WHITE); // Color del texto

            // Cambiamos la fuente del texto de los encabezados:
            Font headerFont = new Font("Arial", Font.BOLD, 14);
            campo.setFont(headerFont); // Aplicamos la fuente al encabezado.

            // Establecemos color del borde del encabezado:
            campo.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, Color.BLACK));

            return campo;
        }
    }

    // Clase interna para renderizar botones
    static class BotonRenderer extends JButton implements TableCellRenderer {
        public BotonRenderer() {
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText(value == null ? "" : value.toString());
            return this;
        }
    }

    // Clase interna para manejar la acción de los botones:
    class BotonEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
        private final JButton boton;
        private final String tipoAccion; // Puede ser "VerDetalle", "Eliminar" o "ActualizarEstado"
        private int filaSeleccionada;

        public BotonEditor(JCheckBox checkBox, String tipoAccion) {
            this.boton = new JButton();
            this.boton.addActionListener(this);
            this.tipoAccion = tipoAccion;
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.filaSeleccionada = row;
            boton.setText(value == null ? "" : value.toString());
            return boton;
        }

        @Override
        public Object getCellEditorValue() {
            return boton.getText();
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            try{
                switch (tipoAccion) {
                    case "VerDetalle":
                        verDetalle(filaSeleccionada);
                        break;

                    case "Eliminar":
                        // Detener la edición activa antes de modificar el modelo:
                        if (tablaPedidos.isEditing()) {
                            tablaPedidos.getCellEditor().stopCellEditing();
                        }
                        eliminarPedido(filaSeleccionada);
                        break;

                    case "ActualizarEstado":
                        actualizarEstado(filaSeleccionada);
                        break;
                }
            } catch (IndexOutOfBoundsException ex) {
                System.err.println("Error de índice: " + ex.getMessage());
            } finally {
                fireEditingStopped(); // Nos aseguramos de que la edición se detenga después de la acción.
            }
        }

    }
}