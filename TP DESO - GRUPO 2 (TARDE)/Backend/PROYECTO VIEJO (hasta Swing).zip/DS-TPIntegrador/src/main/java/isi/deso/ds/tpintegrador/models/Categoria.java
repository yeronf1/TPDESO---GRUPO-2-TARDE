package isi.deso.ds.tpintegrador.models;

import isi.deso.ds.tpintegrador.models.enums.TipoItem;

public class Categoria {

    private String id;
    private String descripcion;
    private TipoItem tipoItem;

    // GETTERS Y SETTERS:

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public TipoItem getTipoItem() {
        return tipoItem;
    }

    public void setTipoItem(TipoItem tipoItem) {
        this.tipoItem = tipoItem;
    }

    // CONSTRUCTORES:

    public Categoria(){

    }

    public Categoria(String id, String descripcion, TipoItem tipoItem) {
        this.id = id;
        this.descripcion = descripcion;
        this.tipoItem = tipoItem;
    }
}
