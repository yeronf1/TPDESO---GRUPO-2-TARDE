package isi.deso.ds.tpintegrador.controllers;

import java.util.List;

import isi.deso.ds.tpintegrador.repository.VendedoresDAO;
import isi.deso.ds.tpintegrador.models.Vendedor;

public class VendedoresController {

    private final VendedoresDAO vendedoresDAO;

    public VendedoresController(VendedoresDAO vendedoresDAO) {
        this.vendedoresDAO = vendedoresDAO;
    }

    public List<Vendedor> mostrarListaVendedores() {
        return vendedoresDAO.listarVendedores();
    }

    public boolean crearNuevoVendedor(Vendedor vendedor) {
        return vendedoresDAO.crearVendedor(vendedor);
    }

    public boolean modificarVendedor(Vendedor vendedor) {
        return vendedoresDAO.actualizarVendedor(vendedor);
    }

    public boolean eliminarVendedor(String id) {
         return vendedoresDAO.eliminarVendedor(id);
    }

    public Vendedor buscarVendedor(String filtro) {
        return vendedoresDAO.buscarVendedor(filtro);
    }

    public List<Vendedor> buscarVendedorPorParametro(String parametro, String valor) {
        return vendedoresDAO.buscarVendedorPorParametro(parametro, valor);
    }

}