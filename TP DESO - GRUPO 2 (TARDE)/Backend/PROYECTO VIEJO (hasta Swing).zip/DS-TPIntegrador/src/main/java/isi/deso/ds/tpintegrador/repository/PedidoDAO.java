package isi.deso.ds.tpintegrador.repository;

import java.util.List;
import java.util.ArrayList;
import java.sql.SQLException;

import isi.deso.ds.tpintegrador.models.Pedido;
import isi.deso.ds.tpintegrador.models.ItemMenu;
import isi.deso.ds.tpintegrador.models.ItemPedido;
import isi.deso.ds.tpintegrador.models.enums.Estado;
import isi.deso.ds.tpintegrador.exceptions.ItemNoEncontradoException;

public interface PedidoDAO {

    List<Pedido> listarPedidos();
    boolean crearPedido(Pedido pedido);
    boolean actualizarEstadoPedido(String idPedido, Estado nuevoEstado);
    boolean actualizarDetallePedido(String idPedido, List<ItemPedido> itemsActualizados);
    boolean eliminarPedido(String id);
    Pedido buscarPedido(String id);
    Pedido getPedidoById(String idPedido);
    List<ItemMenu> obtenerItemsMenu() throws SQLException;
    ArrayList<Pedido> filtrarPorEstado(String estado)throws ItemNoEncontradoException;

}
