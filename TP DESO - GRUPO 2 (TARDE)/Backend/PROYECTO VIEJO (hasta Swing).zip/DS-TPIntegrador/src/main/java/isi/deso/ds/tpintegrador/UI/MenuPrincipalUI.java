package isi.deso.ds.tpintegrador.UI;

import javax.swing.*;
import java.awt.*;

public class MenuPrincipalUI extends JFrame {

    public MenuPrincipalUI() {

        // Configuramos el JFrame:
        setTitle("Menú Principal");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout()); // Usamos GridBagLayout para centrar y espaciar los botones.

        // Creamos el contenedor de los botones:
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new GridBagLayout());
        panelBotones.setBackground(new Color(245, 245, 245));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0); // Damos espaciado entre botones.
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0; // Ubicamos todos los botones en la misma columna.

        // Botón para ClienteUI:
        JButton clienteButton = crearBoton("Cliente");
        clienteButton.addActionListener(e -> ClienteUI.main(null));
        panelBotones.add(clienteButton, gbc);

        // Botón para VendedorUI:
        gbc.gridy = 1;
        JButton vendedorButton = crearBoton("Vendedor");
        vendedorButton.addActionListener(e -> VendedorUI.main(null));
        panelBotones.add(vendedorButton, gbc);

        // Botón para ItemsMenuUI:
        gbc.gridy = 2;
        JButton itemsButton = crearBoton("Items");
        itemsButton.addActionListener(e -> ItemsMenuUI.main(null));
        panelBotones.add(itemsButton, gbc);

        // Botón para PedidoUI:
        gbc.gridy = 3;
        JButton pedidoButton = crearBoton("Pedido");
        pedidoButton.addActionListener(e -> PedidoUI.main(null));
        panelBotones.add(pedidoButton, gbc);

        // Agregamos el panel de botones al JFrame:
        add(panelBotones);

        setVisible(true);
    }

    private JButton crearBoton(String texto) {

        JButton boton = new JButton(texto);
        boton.setPreferredSize(new Dimension(200, 40));
        boton.setBackground(new Color(70, 130, 180));
        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        return boton;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MenuPrincipalUI::new);
    }
}
