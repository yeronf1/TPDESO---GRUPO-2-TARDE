package isi.deso.ds.tpintegrador.repository;

import java.util.List;

import isi.deso.ds.tpintegrador.models.Cliente;

public interface ClienteDAO {

    List<Cliente> listarCliente();
    boolean crearCliente(Cliente dato);
    boolean actualizarCliente(Cliente dato);
    boolean eliminarCliente(String id);
    Cliente buscarCliente(String id);
    List<Cliente> buscarClientePorParametro(String parametro, String valor);

}
