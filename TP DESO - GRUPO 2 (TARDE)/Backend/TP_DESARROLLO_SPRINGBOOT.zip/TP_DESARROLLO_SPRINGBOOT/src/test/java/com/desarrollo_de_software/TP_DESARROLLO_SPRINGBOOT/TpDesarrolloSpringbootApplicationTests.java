package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpDesarrolloSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
