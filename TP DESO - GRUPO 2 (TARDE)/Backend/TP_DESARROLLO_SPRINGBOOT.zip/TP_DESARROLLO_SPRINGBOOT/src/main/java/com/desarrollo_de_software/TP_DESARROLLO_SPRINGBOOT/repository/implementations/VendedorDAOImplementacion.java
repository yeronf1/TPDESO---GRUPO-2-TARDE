package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.implementations;

import java.util.List;
import java.util.NoSuchElementException;
import jakarta.transaction.Transactional;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Vendedor;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.VendedorDAO;

@Repository
public class VendedorDAOImplementacion implements VendedorDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    @Transactional
    public Vendedor save(Vendedor vendedor) {
        entityManager.persist(vendedor);
        return vendedor;
    }

    @Override
    @Transactional
    public void actualizarVendedor(Vendedor vendedor) {
        entityManager.merge(vendedor);
    }

    @Override
    public List<Vendedor> buscarPorFiltros(int id_vendedor, String nombre, String direccion) {

        StringBuilder queryStr = new StringBuilder("SELECT v FROM Vendedor v WHERE 1 = 1");

        if (id_vendedor > 0) {
            queryStr.append(" AND v.id_vendedor = :id_vendedor");
        }

        if (nombre != null && !nombre.isEmpty()) {
            queryStr.append(" AND v.nombre LIKE :nombre");
        }

        if (direccion != null && !direccion.isEmpty()) {
            queryStr.append(" AND v.direccion LIKE :direccion");
        }

        TypedQuery<Vendedor> query = entityManager.createQuery(queryStr.toString(), Vendedor.class);

        if (id_vendedor > 0) {
            query.setParameter("id_vendedor", id_vendedor);
        }

        // Usamos '%' para realizar una búsqueda parcial por datos ingresados:

        if (nombre != null && !nombre.isEmpty()) {
            query.setParameter("nombre", "%" + nombre + "%");
        }

        if (direccion != null && !direccion.isEmpty()) {
            query.setParameter("direccion", "%" + direccion + "%");
        }

        return query.getResultList();

    }

    @Override
    @Transactional
    public long totalVendedoresEnBD() {
        TypedQuery<Long> query = entityManager.createQuery("SELECT COUNT(v) FROM Vendedor v", Long.class);
        return query.getSingleResult();
    }

    @Override
    @Transactional
    public Vendedor findById(int id) {
        return entityManager.find(Vendedor.class, id);
    }

    @Override
    @Transactional
    public void deleteById(int id) {
        // Obtenemos la entidad a eliminar usando el ID:
        Vendedor vendedor = findById(id);

        if (vendedor != null) {
            // Si existe, la eliminamos:
            entityManager.remove(vendedor);
        } else {
            throw new NoSuchElementException("No se encontró un vendedor con el ID: " + id);
        }
    }

    // Metodo para poder devolver todos los vendedores de la base de datos a la interfaz de usuario.
    @Override
    @Transactional
    public List<Vendedor> findAll() {
        TypedQuery<Vendedor> query = entityManager.createQuery("SELECT v FROM Vendedor v", Vendedor.class);
        return query.getResultList();
    }

}