package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services.validationServices;

import java.util.regex.Pattern;
import org.springframework.stereotype.Service;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.PedidoDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.ClienteDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.VendedorDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.ItemMenuDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums.TipoItem;

@Service
public class ValidadorRegistro {

    // Expresiones regulares para las validaciones:
    private static final Pattern PATRON_NOMBRE = Pattern.compile("^[A-Za-záéíóúÁÉÍÓÚüÜ]+( [A-Za-záéíóúÁÉÍÓÚüÜ]+)*$"); // Solo letras y vocales con tilde, además de espacios en blanco en cualquier parte menos al inicio y final (para segundos nombres).
    private static final Pattern PATRON_CUIT = Pattern.compile("^\\d{11}$"); // Solo dígitos para simplificación
    private static final Pattern PATRON_CORREO = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"); // Validaciones varias para correos electrónicos.
    private static final Pattern PATRON_VARIOS = Pattern.compile("^[a-zA-Z0-9áéíóúÁÉÍÓÚ\\s.,#-]+$"); // Validaciones varias para domicilos.
    private static final Pattern PATRON_NUMERO_POSITIVO = Pattern.compile("^(\\d+(\\.\\d+)?)$"); // Validaciones para campos numéricos enteros positivos.
    private static final Pattern PATRON_GRAD_ALCOHOLICA = Pattern.compile("^\\d+(\\.\\d+)?$");

    // Restricciones de longitud para los campos que hay que ingresar cadenas de caracteres:
    private static final int LONGITUD_MAX_NOMBRE = 35; // Longitud tomada por convención (considerando nombres compuestos o segundos nombres).
    private static final int LONGITUD_MAX_VARIOS = 80; // Longitud tomada por convención.
    private static final int MAX_PRECIO = 100000; // Precio máximo tomada por convención.
    private static final int MAX_CALORIAS = 5000; // Calorías máximas tomadas por convención.
    private static final int MAX_PESO = 4000; // Peso máximo tomado por convención.
    private static final int MAX_VOLUMEN = 3000; // Volumen máximo tomado por convención.

    public void validarCliente(ClienteDTO clienteDTO) throws IllegalArgumentException {

        // Validamos campos vacíos:
        if (clienteDTO.getNombre() == null || clienteDTO.getNombre().trim().isBlank() ||
                clienteDTO.getCuit() == null || clienteDTO.getCuit().trim().isBlank() ||
                clienteDTO.getCorreo_electronico() == null || clienteDTO.getCorreo_electronico().trim().isBlank() ||
                clienteDTO.getDireccion() == null || clienteDTO.getDireccion().trim().isBlank()) {
            throw new IllegalArgumentException("Todos los campos son obligatorios.");
        }

        // Validamos que el campo 'Nombre' solo contenga letras:
        if (!PATRON_NOMBRE.matcher(clienteDTO.getNombre()).matches()) {
            throw new IllegalArgumentException("El nombre debe contener solo letras (se permiten tíldes).");
        }

        // Validamos que el campo 'Nombre' tenga una longitud máxima de LONGITUD_MAX_NOMBRE:
        if (clienteDTO.getNombre().length() > LONGITUD_MAX_NOMBRE) {
            throw new IllegalArgumentException("El nombre debe tener " + LONGITUD_MAX_NOMBRE + " caracteres como máximo.");
        }

        // Validamos que el campo 'Cuit' contenga 11 dígitos numéricos:
        if (!PATRON_CUIT.matcher(clienteDTO.getCuit()).matches()) {
            throw new IllegalArgumentException("El cuit debe contener 11 dígitos numéricos, sin guiones.");
        }

        // Validamos que el correo electrónico cumpla con la expresión regular especificada (un correo electrónico válido):
        if (!PATRON_CORREO.matcher(clienteDTO.getCorreo_electronico()).matches()) {
            throw new IllegalArgumentException("El correo electrónico no es válido.");
        }

        // Validamos que el correo electrónico tenga una longitud máxima de LONGITUD_MAX_VARIOS:
        if (clienteDTO.getCorreo_electronico().length() > LONGITUD_MAX_VARIOS) {
            throw new IllegalArgumentException("El correo electrónico debe tener " + LONGITUD_MAX_VARIOS + " caracteres como máximo.");
        }

        // Validamos que el campo 'Direccion' siga un formato para domicilios (sin símbolos especiales):
        if (!PATRON_VARIOS.matcher(clienteDTO.getDireccion()).matches()) {
            throw new IllegalArgumentException("La dirección debe contener solo letras (se permiten tíldes) y números.");
        }

        // Validamos que el campo 'Direccion' tenga una longitud máxima de LONGITUD_MAX_VARIOS:
        if (clienteDTO.getDireccion().length() > LONGITUD_MAX_VARIOS) {
            throw new IllegalArgumentException("La direcion debe tener " + LONGITUD_MAX_VARIOS + " caracteres como máximo.");
        }

    }

    public void validarVendedor(VendedorDTO vendedorDTO) throws IllegalArgumentException {

        // Validamos campos vacíos:
        if (vendedorDTO.getNombre() == null || vendedorDTO.getNombre().trim().isBlank() ||
                vendedorDTO.getDireccion() == null || vendedorDTO.getDireccion().trim().isBlank()) {
            throw new IllegalArgumentException("Todos los campos son obligatorios.");
        }

        // Validamos que el campo 'Nombre' solo contenga letras:
        if (!PATRON_NOMBRE.matcher(vendedorDTO.getNombre()).matches()) {
            throw new IllegalArgumentException("El nombre debe contener solo letras (se permiten tíldes).");
        }

        // Validamos que el campo 'Nombre' tenga una longitud máxima de LONGITUD_MAX_NOMBRE:
        if (vendedorDTO.getNombre().length() > LONGITUD_MAX_NOMBRE) {
            throw new IllegalArgumentException("El nombre debe tener " + LONGITUD_MAX_NOMBRE + " caracteres como máximo.");
        }

        // Validamos que el campo 'Direccion' siga un formato para domicilios (sin símbolos especiales):
        if (!PATRON_VARIOS.matcher(vendedorDTO.getDireccion()).matches()) {
            throw new IllegalArgumentException("La dirección debe contener solo letras (se permiten tíldes) y números.");
        }

        // Validamos que el campo 'Direccion' tenga una longitud máxima de LONGITUD_MAX_VARIOS:
        if (vendedorDTO.getDireccion().length() > LONGITUD_MAX_VARIOS) {
            throw new IllegalArgumentException("La direcion debe tener " + LONGITUD_MAX_VARIOS + " caracteres como máximo.");
        }

    }

    public void validarCrearItemMenu(ItemMenuDTO itemMenuDTO) throws IllegalArgumentException {

        // Validamos campos GENERALES vacíos:
        if (itemMenuDTO.getNombre() == null || itemMenuDTO.getNombre().trim().isBlank() ||
                itemMenuDTO.getTipo_item_menu() == null || itemMenuDTO.getId_categoria() <= 0 ||
                itemMenuDTO.getDescripcion() == null || itemMenuDTO.getDescripcion().isBlank() ||
                itemMenuDTO.getId_vendedor() <= 0) {
            throw new IllegalArgumentException("Todos los campos son obligatorios.");
        }

        // Validamos que el campo 'Nombre' siga un formato estándar (sin símbolos especiales):
        if (!PATRON_VARIOS.matcher(itemMenuDTO.getNombre()).matches()) {
            throw new IllegalArgumentException("El nombre del ítem debe contener solo letras (se permiten tíldes) y números.");
        }

        // Validamos que el campo 'Nombre' tenga una longitud máxima de LONGITUD_MAX_NOMBRE:
        if (itemMenuDTO.getNombre().length() > LONGITUD_MAX_NOMBRE) {
            throw new IllegalArgumentException("El nombre del ítem debe tener " + LONGITUD_MAX_NOMBRE + " caracteres como máximo.");
        }

        // Validamos que el campo 'Descripcion' siga un formato estándar (sin símbolos especiales):
        if (!PATRON_VARIOS.matcher(itemMenuDTO.getDescripcion()).matches()) {
            throw new IllegalArgumentException("La descripción del ítem debe contener solo letras (se permiten tíldes) y números.");
        }

        // Validamos que el campo 'Descripcion' tenga una longitud máxima de LONGITUD_MAX_VARIOS:
        if (itemMenuDTO.getDescripcion().length() > LONGITUD_MAX_VARIOS) {
            throw new IllegalArgumentException("La descripción del ítem debe tener " + LONGITUD_MAX_VARIOS + " caracteres como máximo.");
        }

        // Validamos el campo 'Precio' como número positivo con decimales:
        if (!PATRON_NUMERO_POSITIVO.matcher(String.valueOf(itemMenuDTO.getPrecio())).matches() || itemMenuDTO.getPrecio() <= 0) {
            throw new IllegalArgumentException("Ingrese un precio válido (número positivo).");
        }
        if (itemMenuDTO.getPrecio() > MAX_PRECIO) {
            throw new IllegalArgumentException("El precio del ítem debe ser menor o igual a $" + MAX_PRECIO + ".");
        }

        if (itemMenuDTO.getTipo_item_menu() == TipoItem.COMIDA) {
            // Validamos el campo 'Calorías' como número positivo con decimales:
            if (!PATRON_NUMERO_POSITIVO.matcher(String.valueOf(itemMenuDTO.getCalorias())).matches() || itemMenuDTO.getCalorias() <= 0) {
                throw new IllegalArgumentException("Ingrese un valor de calorías válido (número positivo).");
            }
            if (itemMenuDTO.getCalorias() > MAX_CALORIAS) {
                throw new IllegalArgumentException("El valor de calorías debe ser menor o igual a " + MAX_CALORIAS + ".");
            }

            // Validamos el campo 'Peso' como número positivo con decimales:
            if (!PATRON_NUMERO_POSITIVO.matcher(String.valueOf(itemMenuDTO.getPeso())).matches() || itemMenuDTO.getPeso() <= 0) {
                throw new IllegalArgumentException("Ingrese un valor de peso válido (número positivo).");
            }
            if (itemMenuDTO.getPeso() > MAX_PESO) {
                throw new IllegalArgumentException("El valor de peso debe ser menor o igual a " + MAX_PESO + " gramos.");
            }

        } else {

            // Validamos el campo 'Graduación alcohólica' como número positivo entre 0 y 100 con decimales:
            if (!PATRON_GRAD_ALCOHOLICA.matcher(String.valueOf(itemMenuDTO.getGraduacionAlcoholica())).matches()
                    || itemMenuDTO.getGraduacionAlcoholica() < 0
                    || itemMenuDTO.getGraduacionAlcoholica() > 100) {
                throw new IllegalArgumentException("Ingrese un valor válido para la graduación alcohólica (entre 0 y 100).");
            }

            // Validamos el campo 'Volumen' como número positivo con decimales:
            if (!PATRON_NUMERO_POSITIVO.matcher(String.valueOf(itemMenuDTO.getVolumen())).matches() || itemMenuDTO.getVolumen() <= 0) {
                throw new IllegalArgumentException("Ingrese un volumen válido (número positivo).");
            }
            if (itemMenuDTO.getVolumen() > MAX_VOLUMEN) {
                throw new IllegalArgumentException("El volumen debe ser menor o igual a " + MAX_VOLUMEN + " ml.");
            }

        }
    }

    public void validarModificarItemMenu(ItemMenuDTO itemMenuDTO) throws IllegalArgumentException {

        // Validamos campos GENERALES vacíos:
        if (itemMenuDTO.getNombre() == null || itemMenuDTO.getNombre().trim().isBlank() ||
                itemMenuDTO.getDescripcion() == null || itemMenuDTO.getDescripcion().isBlank() ||
                itemMenuDTO.getId_vendedor() <= 0) {
            throw new IllegalArgumentException("Todos los campos son obligatorios.");
        }

        // Validamos que el campo 'Nombre' siga un formato estándar (sin símbolos especiales):
        if (!PATRON_VARIOS.matcher(itemMenuDTO.getNombre()).matches()) {
            throw new IllegalArgumentException("El nombre del ítem debe contener solo letras (se permiten tíldes) y números.");
        }

        // Validamos que el campo 'Nombre' tenga una longitud máxima de LONGITUD_MAX_NOMBRE:
        if (itemMenuDTO.getNombre().length() > LONGITUD_MAX_NOMBRE) {
            throw new IllegalArgumentException("El nombre del ítem debe tener " + LONGITUD_MAX_NOMBRE + " caracteres como máximo.");
        }

        // Validamos que el campo 'Descripcion' siga un formato estándar (sin símbolos especiales):
        if (!PATRON_VARIOS.matcher(itemMenuDTO.getDescripcion()).matches()) {
            throw new IllegalArgumentException("La descripción del ítem debe contener solo letras (se permiten tíldes) y números.");
        }

        // Validamos que el campo 'Descripcion' tenga una longitud máxima de LONGITUD_MAX_VARIOS:
        if (itemMenuDTO.getDescripcion().length() > LONGITUD_MAX_VARIOS) {
            throw new IllegalArgumentException("La descripción del ítem debe tener " + LONGITUD_MAX_VARIOS + " caracteres como máximo.");
        }

        // Validamos el campo 'Precio' como número positivo con decimales:
        if (!PATRON_NUMERO_POSITIVO.matcher(String.valueOf(itemMenuDTO.getPrecio())).matches() || itemMenuDTO.getPrecio() <= 0) {
            throw new IllegalArgumentException("Ingrese un precio válido (número positivo).");
        }
        if (itemMenuDTO.getPrecio() > MAX_PRECIO) {
            throw new IllegalArgumentException("El precio del ítem debe ser menor o igual a $" + MAX_PRECIO + ".");
        }

        if (itemMenuDTO.getTipo_item_menu() == TipoItem.COMIDA) {
            // Validamos el campo 'Calorías' como número positivo con decimales:
            if (!PATRON_NUMERO_POSITIVO.matcher(String.valueOf(itemMenuDTO.getCalorias())).matches() || itemMenuDTO.getCalorias() <= 0) {
                throw new IllegalArgumentException("Ingrese un valor de calorías válido (número positivo).");
            }
            if (itemMenuDTO.getCalorias() > MAX_CALORIAS) {
                throw new IllegalArgumentException("El valor de calorías debe ser menor o igual a " + MAX_CALORIAS + ".");
            }

            // Validamos el campo 'Peso' como número positivo con decimales:
            if (!PATRON_NUMERO_POSITIVO.matcher(String.valueOf(itemMenuDTO.getPeso())).matches() || itemMenuDTO.getPeso() <= 0) {
                throw new IllegalArgumentException("Ingrese un valor de peso válido (número positivo).");
            }
            if (itemMenuDTO.getPeso() > MAX_PESO) {
                throw new IllegalArgumentException("El valor de peso debe ser menor o igual a " + MAX_PESO + " gramos.");
            }

        } else {

            // Validamos el campo 'Graduación alcohólica' como número positivo entre 0 y 100 con decimales:
            if (!PATRON_GRAD_ALCOHOLICA.matcher(String.valueOf(itemMenuDTO.getGraduacionAlcoholica())).matches()
                    || itemMenuDTO.getGraduacionAlcoholica() < 0
                    || itemMenuDTO.getGraduacionAlcoholica() > 100) {
                throw new IllegalArgumentException("Ingrese un valor válido para la graduación alcohólica (entre 0 y 100).");
            }

            // Validamos el campo 'Volumen' como número positivo con decimales:
            if (!PATRON_NUMERO_POSITIVO.matcher(String.valueOf(itemMenuDTO.getVolumen())).matches() || itemMenuDTO.getVolumen() <= 0) {
                throw new IllegalArgumentException("Ingrese un volumen válido (número positivo).");
            }
            if (itemMenuDTO.getVolumen() > MAX_VOLUMEN) {
                throw new IllegalArgumentException("El volumen debe ser menor o igual a " + MAX_VOLUMEN + " ml.");
            }

        }
    }

    public void validarPedido(PedidoDTO pedidoDTO) throws IllegalArgumentException {

        // Validamos que se haya seleccionado un cliente:
        if(pedidoDTO.getIdCliente() <= 0){
            throw new IllegalArgumentException("Seleccione un cliente asociado al pedido.");
        }

        // Validamos que se haya seleccionad al menos un ítem y que la cantidad de los items pedidos sea mayor a 0:
        if (pedidoDTO.getDetalle() == null || pedidoDTO.getDetalle().isEmpty()) {
            throw new IllegalArgumentException("Elija al menos un ítem para el pedido.");
        } else {
            pedidoDTO.getDetalle().forEach(itemPedido -> {
                if(!PATRON_NUMERO_POSITIVO.matcher(String.valueOf(itemPedido.getCantidad())).matches() || itemPedido.getCantidad() <= 0){
                    throw new IllegalArgumentException("Ingrese una cantidad entera positiva para los ítems seleccionados.");
                }
            });
        }

        if ("TRANSFERENCIA".equalsIgnoreCase(pedidoDTO.getFormaPago())){
            // Validamos campos vacíos:
            if (pedidoDTO.getCbu() == null || pedidoDTO.getCbu().trim().isBlank() ||
                    pedidoDTO.getCuit() == null || pedidoDTO.getCuit().trim().isBlank()) {
                throw new IllegalArgumentException("Los campos 'CBU' y 'CUIT' son obligatorios.");
            }

            // Validamos que el campo 'Cuit' contenga 11 dígitos numéricos:
            if (!PATRON_CUIT.matcher(pedidoDTO.getCuit()).matches()) {
                throw new IllegalArgumentException("El cuit debe contener 11 dígitos numéricos, sin guiones.");
            }

            // Validamos que el campo 'CBU' siga un formato estándar:
            if (!PATRON_VARIOS.matcher(pedidoDTO.getCbu()).matches()) {
                throw new IllegalArgumentException("El CBU debe contener solo letras (se permiten tíldes) y números.");
            }

            // Validamos que el campo 'CBU' tenga una longitud máxima de LONGITUD_MAX_VARIOS:
            if (pedidoDTO.getCbu().length() > LONGITUD_MAX_VARIOS) {
                throw new IllegalArgumentException("El CBU debe tener " + LONGITUD_MAX_VARIOS + " caracteres como máximo.");
            }

        } else if("MERCADO_PAGO".equalsIgnoreCase(pedidoDTO.getFormaPago())){
            // Validamos campos vacíos:
            if (pedidoDTO.getAlias() == null || pedidoDTO.getAlias().trim().isBlank()) {
                throw new IllegalArgumentException("El campo 'ALIAS' es obligatorio.");
            }

            // Validamos que el campo 'Alias' siga un formato estándar:
            if (!PATRON_VARIOS.matcher(pedidoDTO.getAlias()).matches()) {
                throw new IllegalArgumentException("El alias debe contener solo letras (se permiten tíldes) y números.");
            }

            // Validamos que el campo 'Alias' tenga una longitud máxima de LONGITUD_MAX_VARIOS:
            if (pedidoDTO.getAlias().length() > LONGITUD_MAX_VARIOS) {
                throw new IllegalArgumentException("El alias debe tener " + LONGITUD_MAX_VARIOS + " caracteres como máximo.");
            }
        }

    }

}