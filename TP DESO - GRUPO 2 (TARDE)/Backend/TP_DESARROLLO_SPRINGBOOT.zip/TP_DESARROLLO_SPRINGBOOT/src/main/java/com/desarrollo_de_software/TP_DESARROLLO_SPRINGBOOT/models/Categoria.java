package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models;

import jakarta.persistence.*;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums.TipoItem;

@Entity
@Table(name = "categorias")
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_categoria", nullable = false, unique = true)
    private int id_categoria;

    @Column(name = "descripcion_categoria")
    private String descripcion_categoria;

    @Column(name = "tipo_item")
    private TipoItem tipoItem;

    // GETTERS Y SETTERS:

    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public String getDescripcion_categoria() {
        return descripcion_categoria;
    }

    public void setDescripcion_categoria(String descripcion_categoria) {
        this.descripcion_categoria = descripcion_categoria;
    }

    public TipoItem getTipoItem() {
        return tipoItem;
    }

    public void setTipoItem(TipoItem tipoItem) {
        this.tipoItem = tipoItem;
    }

    // CONSTRUCTORES:

    public Categoria() {
    }

    public Categoria(int id_categoria, String descripcion_categoria, TipoItem tipoItem) {
        this.id_categoria = id_categoria;
        this.descripcion_categoria = descripcion_categoria;
        this.tipoItem = tipoItem;
    }
}