package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums.TipoItem;

public class ItemMenuDTO {

    // Características generales:
    private int id_item_menu;
    private int id_vendedor;
    private String nombreVendedor;
    private String nombre;
    private int id_categoria;
    private String nombreCategoria;
    private TipoItem tipo_item_menu;
    private String descripcion;
    private double precio;

    // Características específicas para COMIDAS:
    private double peso;
    private int calorias;
    private boolean aptoCeliaco;
    private boolean aptoVegetariano;

    // Características específicas para BEBIDAS:
    private double graduacionAlcoholica;
    private boolean es_gaseosa;
    private double volumen;

    // GETTERS Y SETTERS:

    public int getId_item_menu() {
        return id_item_menu;
    }

    public void setId_item_menu(int id_item_menu) {
        this.id_item_menu = id_item_menu;
    }

    public int getId_vendedor() {
        return id_vendedor;
    }

    public void setId_vendedor(int id_vendedor) {
        this.id_vendedor = id_vendedor;
    }

    public String getNombreVendedor() {
        return nombreVendedor;
    }

    public void setNombreVendedor(String nombreVendedor) {
        this.nombreVendedor = nombreVendedor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String categoria) {
        this.nombreCategoria = categoria;
    }

    public TipoItem getTipo_item_menu() {
        return tipo_item_menu;
    }

    public void setTipo_item_menu(TipoItem tipo_item_menu) {
        this.tipo_item_menu = tipo_item_menu;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public int getCalorias() {
        return calorias;
    }

    public void setCalorias(int calorias) {
        this.calorias = calorias;
    }

    public boolean getAptoCeliaco() {
        return aptoCeliaco;
    }

    public void setAptoCeliaco(boolean aptoCeliaco) {
        this.aptoCeliaco = aptoCeliaco;
    }

    public boolean getAptoVegetariano() {
        return aptoVegetariano;
    }

    public void setAptoVegetariano(boolean aptoVegetariano) {
        this.aptoVegetariano = aptoVegetariano;
    }

    public double getGraduacionAlcoholica() {
        return graduacionAlcoholica;
    }

    public void setGraduacionAlcoholica(double graduacionAlcoholica) {
        this.graduacionAlcoholica = graduacionAlcoholica;
    }

    public boolean getEs_gaseosa() {
        return es_gaseosa;
    }

    public void setEs_gaseosa(boolean es_gaseosa) {
        this.es_gaseosa = es_gaseosa;
    }

    public double getVolumen() {
        return volumen;
    }

    public void setVolumen(double volumen) {
        this.volumen = volumen;
    }

    // CONSTRUCTORES:

    public ItemMenuDTO() {
    }

    // Constructor para PLATOS:
    public ItemMenuDTO(int id_item_menu, int id_vendedor, String nombreVendedor,String nombre, int id_categoria, TipoItem tipo_item_menu, String descripcion, double precio, double peso, int calorias, boolean aptoCeliaco, boolean aptoVegetariano) {
        this.id_item_menu = id_item_menu;
        this.id_vendedor = id_vendedor;
        this.nombreVendedor = nombreVendedor;
        this.nombre = nombre;
        this.id_categoria = id_categoria;
        this.tipo_item_menu = tipo_item_menu;
        this.descripcion = descripcion;
        this.precio = precio;
        this.peso = peso;
        this.calorias = calorias;
        this.aptoCeliaco = aptoCeliaco;
        this.aptoVegetariano = aptoVegetariano;
    }

    // Constructor para BEBIDAS:
    public ItemMenuDTO(int id_item_menu, int id_vendedor, String nombreVendedor,String nombre, int id_categoria, TipoItem tipo_item_menu, String descripcion, double precio, double graduacionAlcoholica, boolean es_gaseosa, double volumen) {
        this.id_item_menu = id_item_menu;
        this.id_vendedor = id_vendedor;
        this.nombreVendedor = nombreVendedor;
        this.nombre = nombre;
        this.id_categoria = id_categoria;
        this.tipo_item_menu = tipo_item_menu;
        this.descripcion = descripcion;
        this.precio = precio;
        this.graduacionAlcoholica = graduacionAlcoholica;
        this.es_gaseosa = es_gaseosa;
        this.volumen = volumen;
    }
}