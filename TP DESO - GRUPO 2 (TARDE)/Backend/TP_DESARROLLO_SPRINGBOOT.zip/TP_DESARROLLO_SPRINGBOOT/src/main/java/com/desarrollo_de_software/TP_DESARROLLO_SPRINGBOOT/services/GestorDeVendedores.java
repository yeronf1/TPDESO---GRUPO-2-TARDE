package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services;

import java.util.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.VendedorDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Coordenada;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Vendedor;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.VendedorDAO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services.validationServices.ValidadorRegistro;

@Service
public class GestorDeVendedores {

    private final VendedorDAO vendedorDAO;
    private final ValidadorRegistro validadorRegistro;

    @Autowired
    public GestorDeVendedores(VendedorDAO vendedorDAO, ValidadorRegistro validadorRegistro) {
        this.vendedorDAO = vendedorDAO;
        this.validadorRegistro = validadorRegistro;
    }

    // Metodo para registrar un nuevo vendedor en la base de datos:
    public void registrarVendedor(VendedorDTO vendedorDTO) {

        // Encapsulamos la lógica de validación de datos de entrada dentro del mismo metodo de registro de vendedor:
        try {
            validadorRegistro.validarVendedor(vendedorDTO);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(e.getMessage());
        }

        // Creamos la entidad y le asignamos los respectivos datos:
        Vendedor vendedor = new Vendedor();

        vendedor.setNombre(vendedorDTO.getNombre());
        vendedor.setDireccion(vendedorDTO.getDireccion());

        Coordenada coordenadaAleatoria = generarCoordenadaAleatoria();
        vendedor.setCoordenadas(coordenadaAleatoria);

        vendedorDAO.save(vendedor);
    }

    // Lo ideal sería realizar una integración que permita, a raíz de una dirección, asociar las respectivas coordenadas mediante Google Maps.
    // Como eso no se puede hacer, realizamos un metodo que permite asignar coordenadas aleatorias dentro del rango de Argentina:
    private Coordenada generarCoordenadaAleatoria() {
        Random random = new Random();

        // Rango aproximado para latitud y longitud en Argentina:
        double latMin = -55.0;
        double latMax = -21.0;
        double lngMin = -74.0;
        double lngMax = -53.0;

        double lat = latMin + (latMax - latMin) * random.nextDouble();
        double lng = lngMin + (lngMax - lngMin) * random.nextDouble();

        // Redondeamos a 2 decimales:
        lat = Double.parseDouble(String.format(Locale.US, "%.3f", lat));
        lng = Double.parseDouble(String.format(Locale.US, "%.3f", lng));

        return new Coordenada(lat, lng);
    }

    // Metodo usado para buscar los vendedores que coincidan con los filtros de búsqueda ingresados:
    public List<VendedorDTO> buscarVendedor(VendedorDTO vendedorDTO) {

        List<Vendedor> vendedoresEncontrados = vendedorDAO.buscarPorFiltros(vendedorDTO.getId_vendedor(),vendedorDTO.getNombre(),vendedorDTO.getDireccion());

        // Convertimos todas las entidades de vendedores encontradas a DTOs para trasnferirlos a la capa de presentación:
        List<VendedorDTO> vendedorDTOS = new ArrayList<>();

        for (Vendedor vendedor : vendedoresEncontrados) {
            VendedorDTO vendedorDTOEncontrado = new VendedorDTO();
            vendedorDTOEncontrado.setId_vendedor(vendedor.getId_vendedor());
            vendedorDTOEncontrado.setNombre(vendedor.getNombre());
            vendedorDTOEncontrado.setDireccion(vendedor.getDireccion());

            Coordenada coordenadas = new Coordenada();
            coordenadas.setLat(vendedor.getCoordenadas().getLat());
            coordenadas.setLng(vendedor.getCoordenadas().getLng());
            vendedorDTOEncontrado.setCoordenadas(coordenadas);

            vendedorDTOS.add(vendedorDTOEncontrado);
        }

        return vendedorDTOS;

    }

    // Metodo para contar el total de vendedores en la base de datos (para poder mostrar en la interfaz: 'X vendedores encontrados de Y totales').
    public long contarTotalVendedores() {
        return vendedorDAO.totalVendedoresEnBD();
    }

    public Vendedor obtenerVendedorPorID(int id_vendedor){
        return vendedorDAO.findById(id_vendedor);
    }

    // Metodo para modificar los datos de un vendedor exsistente en la base de datos:
    public void modificarVendedor(VendedorDTO vendedorDTO) {

        try {
            // Validamos los datos del cliente
            validadorRegistro.validarVendedor(vendedorDTO);

            // Buscamos el vendedor en la base de datos por su ID
            Vendedor vendedor = vendedorDAO.findById(vendedorDTO.getId_vendedor());

            if (vendedor == null) {
                throw new NoSuchElementException("No se encontró un vendedor con el ID: " + vendedorDTO.getId_vendedor());
            }

            // Actualizamos los datos del vendedor:
            vendedor.setNombre(vendedorDTO.getNombre());
            vendedor.setDireccion(vendedorDTO.getDireccion());

            // Persistimos los cambios
            vendedorDAO.actualizarVendedor(vendedor);

        } catch (IllegalArgumentException e) {
            // Excepción para datos no válidos
            throw new IllegalArgumentException(e.getMessage(), e);
        } catch (NoSuchElementException e) {
            // Excepción si el vendedor no existe
            throw new NoSuchElementException(e.getMessage(), e);
        }
    }

    // Metodo para realizar la eliminación FÍSICA de un vendedor:
    public void eliminarVendedor(VendedorDTO vendedorDTO) {

        try{
            vendedorDAO.deleteById(vendedorDTO.getId_vendedor());
        } catch (NoSuchElementException ex){
            throw new NoSuchElementException(ex.getMessage());
        }

    }

    // Metodo para obtener todos los vendedores de la base de datos y poder mostrarlos en la interfaz de usuario para seleccionar:
    public List<VendedorDTO> obtenerVendedores() {

        // Recuperamos de la base de datos todas las entidades de vendedores que existan:
        List<Vendedor> vendedores = vendedorDAO.findAll();

        // Convertimos las entidades en DTOs para transferirlas a la capa de presentación:
        List<VendedorDTO> vendedorDTOS = new ArrayList<>();

        for (Vendedor vendedor : vendedores) {
            VendedorDTO vendedorDTO = new VendedorDTO();
            vendedorDTO.setId_vendedor(vendedor.getId_vendedor());
            vendedorDTO.setNombre(vendedor.getNombre());
            vendedorDTOS.add(vendedorDTO);
        }

        return vendedorDTOS;
    }

}