package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.controllers;

import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.NoSuchElementException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.ItemMenuDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.CategoriaDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.PedidoDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services.GestorDeItemsMenu;

@RestController
@RequestMapping("/item_menu")
public class ItemMenuController {

    private final GestorDeItemsMenu gestorDeItemsMenu;

    @Autowired
    public ItemMenuController(final GestorDeItemsMenu gestorDeItemsMenu) {
        this.gestorDeItemsMenu = gestorDeItemsMenu;
    }

    @PostMapping("/registrar")
    public ResponseEntity<Map<String, String>> registrarItemMenu(@RequestBody ItemMenuDTO itemMenuDTO) {

        Map<String, String> response = new HashMap<>();

        try {

            gestorDeItemsMenu.registrarItemMenu(itemMenuDTO);

            response.put("message", "Ítem registrado exitosamente.");
            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/buscar")
    public ResponseEntity<Map<String, Object>> buscarItemMenu(@RequestBody ItemMenuDTO itemMenuDTO) {

        Map<String, Object> response = new HashMap<>();

        try {
            // Obtenemos los items menú que coinciden con los filtros (si no hay filtros ingresados, se muestran todos los items menú de la base de datos):
            List<ItemMenuDTO> items = gestorDeItemsMenu.buscarItemMenu(itemMenuDTO);

            // Obtenemos el total de items menú en la base de datos.
            long totalItems = gestorDeItemsMenu.contarTotalItemsMenu();

            if (items.isEmpty()) {
                response.put("message", "No se encontraron items menú que coincidan con los filtros especificados.");
                response.put("totalResultados", totalItems); // Incluimos el total de items menú aunque no haya resultados.
                return ResponseEntity.ok(response);
            }

            response.put("message", "Ítems menú  encontrados exitosamente.");
            response.put("data", items);
            response.put("totalResultados", totalItems); // Incluimos el total de items menú.

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/verMenu") // Ruta específica para obtener la lista entera de los ítems asociados a un vendedor en la base de datos (para mostrar en la lista desplegable).
    public ResponseEntity<Map<String, Object>> verMenu(@RequestBody PedidoDTO pedidoDTO) {

        Map<String, Object> response = new HashMap<>();

        try {

            List<ItemMenuDTO> itemsPorVendedor = gestorDeItemsMenu.obtenerItemMenuPorVendedor(pedidoDTO);

            if (itemsPorVendedor.isEmpty()) {
                response.put("message", "No se encontraron items para ese vendedor.");
                return ResponseEntity.ok(response);
            }

            response.put("message", "Ítems encontrados exitosamente.");
            response.put("data", itemsPorVendedor);
            return ResponseEntity.ok(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @DeleteMapping("/eliminar")
    public ResponseEntity<Map<String, Object>> eliminarItemMenu(@RequestBody ItemMenuDTO itemMenuDTO) {

        Map<String, Object> response = new HashMap<>();

        try {

            gestorDeItemsMenu.eliminarItemMenu(itemMenuDTO);

            response.put("message", "Ítem menú eliminado exitosamente.");
            return ResponseEntity.ok(response);

        } catch (NoSuchElementException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PutMapping("/modificar")
    public ResponseEntity<Map<String, Object>> modificarItemMenu(@RequestBody ItemMenuDTO itemMenuDTO) {

        Map<String, Object> response = new HashMap<>();

        try {

            gestorDeItemsMenu.modificarItemMenu(itemMenuDTO);

            response.put("message", "Ítem menú modificado exitosamente.");
            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException | NoSuchElementException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/obtenerCategorias") // Ruta específica para obtener la lista entera de las categorias en la base de datos (para mostrar en la lista desplegable).
    public ResponseEntity<Map<String, Object>> obtenerIDCategorias() {

        Map<String, Object> response = new HashMap<>();

        try {

            List<CategoriaDTO> categorias = gestorDeItemsMenu.obtenerCategorias();

            if (categorias.isEmpty()) {
                response.put("message", "No se encontraron categorias.");
                return ResponseEntity.ok(response);
            }

            response.put("message", "Categorias encontradas exitosamente.");
            response.put("data", categorias);
            return ResponseEntity.ok(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }


}
