package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs;

import java.util.List;
import java.time.LocalDate;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums.Estado;

public class PedidoDTO {

    // Atributos generales del pedido:
    private int idPedido;
    private int idCliente;
    private String nombreCliente;
    private double total;
    private Estado estadoPedido;
    private List<ItemPedidoDTO> detalle;
    private int idVendedor;
    private String nombreVendedor;

    // Atributos generales del pago:
    private int idPago;
    private LocalDate fechaPago;
    private String formaPago;

    // Atributos específicos de transferencia:
    private String cuit;
    private String cbu;

    // Atributos específicos de Mercado Pago:
    private String alias;

    // GETTERS Y SETTERS:

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Estado getEstadoPedido() {
        return estadoPedido;
    }

    public void setEstadoPedido(Estado estadoPedido) {
        this.estadoPedido = estadoPedido;
    }

    public List<ItemPedidoDTO> getDetalle() {
        return detalle;
    }

    public void setDetalle(List<ItemPedidoDTO> detalle) {
        this.detalle = detalle;
    }

    public int getIdVendedor() {
        return idVendedor;
    }

    public void setIdVendedor(int idVendedor) {
        this.idVendedor = idVendedor;
    }

    public String getNombreVendedor() {
        return nombreVendedor;
    }

    public void setNombreVendedor(String nombreVendedor) {this.nombreVendedor = nombreVendedor;}

    public int getIdPago() {
        return idPago;
    }

    public void setIdPago(int idPago) {
        this.idPago = idPago;
    }

    public LocalDate getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(LocalDate fechaPago) {
        this.fechaPago = fechaPago;
    }

    public String getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public String getCbu() {
        return cbu;
    }

    public void setCbu(String cbu) {
        this.cbu = cbu;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    // CONSTRUCTORES:

    public PedidoDTO() {
    }

    // Constructor para forma de pago TRANSFERENCIA:
    public PedidoDTO(int idPedido, int idCliente, String nombreCliente, double total, Estado estadoPedido, List<ItemPedidoDTO> detalle, int idVendedor, String nombreVendedor, int idPago, LocalDate fechaPago, String formaPago, String cuit, String cbu) {
        this.idPedido = idPedido;
        this.idCliente = idCliente;
        this.nombreCliente = nombreCliente;
        this.total = total;
        this.estadoPedido = estadoPedido;
        this.detalle = detalle;
        this.idVendedor = idVendedor;
        this.nombreVendedor = nombreVendedor;
        this.idPago = idPago;
        this.fechaPago = fechaPago;
        this.formaPago = formaPago;
        this.cuit = cuit;
        this.cbu = cbu;
    }

    // Constructor para forma de pago MERCADO PAGO:

    public PedidoDTO(int idPedido, int idCliente, String nombreCliente, double total, Estado estadoPedido, List<ItemPedidoDTO> detalle, int idVendedor, String nombreVendedor, int idPago, LocalDate fechaPago, String formaPago, String alias) {
        this.idPedido = idPedido;
        this.idCliente = idCliente;
        this.nombreCliente = nombreCliente;
        this.total = total;
        this.estadoPedido = estadoPedido;
        this.detalle = detalle;
        this.idVendedor = idVendedor;
        this.nombreVendedor = nombreVendedor;
        this.idPago = idPago;
        this.fechaPago = fechaPago;
        this.formaPago = formaPago;
        this.alias = alias;
    }
}