package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository;

import java.util.List;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Cliente;

public interface ClienteDAO {

    Cliente save (Cliente cliente);
    void actualizarCliente(Cliente cliente);
    List<Cliente> buscarPorFiltros(int id_cliente, String nombre, String cuit, String email, String direccion);
    long totalClientesEnBD();
    Cliente findById(int id);
    void deleteById(int id);
    List<Cliente> findAll();

}
