package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Coordenada;

public class VendedorDTO {

    private int id_vendedor;
    private String nombre;
    private String direccion;
    private Coordenada coordenadas;

    // GETTERS Y SETTERS:

    public int getId_vendedor() {
        return id_vendedor;
    }

    public void setId_vendedor(int id_vendedor) {
        this.id_vendedor = id_vendedor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Coordenada getCoordenadas() {
        return coordenadas;
    }

    public void setCoordenadas(Coordenada coordenadas) {
        this.coordenadas = coordenadas;
    }


    // CONSTRUCTORES:

    public VendedorDTO() {
    }

    public VendedorDTO(int id_vendedor, String nombre, String direccion, Coordenada coordenadas) {
        this.id_vendedor = id_vendedor;
        this.nombre = nombre;
        this.direccion = direccion;
        this.coordenadas = coordenadas;
    }
}
