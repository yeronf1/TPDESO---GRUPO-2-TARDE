package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "pagos")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public abstract class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_pago;

    private LocalDateTime fechaPago;

    // GETTERS Y SETTERS:

    public int getId_pago() {
        return id_pago;
    }

    public void setId_pago(int id_pago) {
        this.id_pago = id_pago;
    }

    public String getFechaPago() {
        return fechaPago.format(DateTimeFormatter.ofPattern("dd/MM/yyyy - HH:mm:ss")); // Le damos un formato legible a la fecha del pago.
    }

    public void setFechaPago() {
        this.fechaPago = LocalDateTime.now();
    }

    // CONSTRUCTORES:

    public Pago() {
        this.fechaPago = LocalDateTime.now();
    }

    public Pago(int id_pago) {
        this.id_pago = id_pago;
        this.fechaPago = LocalDateTime.now();
    }

    public Pago(int id_pago, LocalDateTime fechaPago) {
        this.id_pago = id_pago;
        this.fechaPago = fechaPago;
    }

    // Metodo abstracto:
    public abstract double calcularRecargo(double total);

}
