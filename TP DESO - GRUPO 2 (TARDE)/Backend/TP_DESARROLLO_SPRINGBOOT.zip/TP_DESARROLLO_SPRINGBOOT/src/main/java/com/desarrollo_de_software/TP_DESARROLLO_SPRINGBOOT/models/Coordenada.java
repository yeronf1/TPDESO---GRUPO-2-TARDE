package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models;

import java.io.Serializable;
import jakarta.persistence.Embeddable;

@Embeddable
public class Coordenada implements Serializable {

    private double lat;
    private double lng;

    // GETTERS Y SETTERS:

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    // CONSTRUCTORES:

    public Coordenada() {
    }

    public Coordenada(double lat, double lng) {
        this.lat = lat;
        this.lng = lng;
    }
}