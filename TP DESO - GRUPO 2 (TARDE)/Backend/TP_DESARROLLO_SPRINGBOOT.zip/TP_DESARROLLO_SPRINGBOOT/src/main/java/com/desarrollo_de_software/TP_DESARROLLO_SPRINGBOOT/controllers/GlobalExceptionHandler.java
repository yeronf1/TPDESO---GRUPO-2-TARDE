package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

// Controlador para manejar exepciones globales (en este caso, para ingreso de letras en campos numéricos).
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<String> handleDeserializationError(HttpMessageNotReadableException ex) {
        if (ex.getCause() instanceof NumberFormatException) {
            return new ResponseEntity<>("Ingrese valores numéricos válidos (números positivos).", HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>("Error en el formato de los campos numéricos. Procure ingresar números enteros positivos.", HttpStatus.BAD_REQUEST);
    }
}

