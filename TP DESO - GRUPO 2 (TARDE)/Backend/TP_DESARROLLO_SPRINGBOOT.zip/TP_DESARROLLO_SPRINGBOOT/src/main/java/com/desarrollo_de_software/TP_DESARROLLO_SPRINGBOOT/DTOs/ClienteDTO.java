package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Coordenada;

public class ClienteDTO {

    private int id_cliente;
    private String nombre;
    private String direccion;
    private String correo_electronico;
    private String cuit;
    private Coordenada coordenadas;

    // GETTERS Y SETTERS:

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCorreo_electronico() {
        return correo_electronico;
    }

    public void setCorreo_electronico(String correo_electronico) {
        this.correo_electronico = correo_electronico;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public Coordenada getCoordenadas() {
        return coordenadas;
    }

    public void setCoordenadas(Coordenada coordenadas) {
        this.coordenadas = coordenadas;
    }

    // CONSTRUCTORES:

    public ClienteDTO(){
    }

    public ClienteDTO(int id_cliente, String nombre, String direccion, String correo_electronico, String cuit, Coordenada coordenadas) {
        this.id_cliente = id_cliente;
        this.nombre = nombre;
        this.direccion = direccion;
        this.correo_electronico = correo_electronico;
        this.cuit = cuit;
        this.coordenadas = coordenadas;
    }
}
