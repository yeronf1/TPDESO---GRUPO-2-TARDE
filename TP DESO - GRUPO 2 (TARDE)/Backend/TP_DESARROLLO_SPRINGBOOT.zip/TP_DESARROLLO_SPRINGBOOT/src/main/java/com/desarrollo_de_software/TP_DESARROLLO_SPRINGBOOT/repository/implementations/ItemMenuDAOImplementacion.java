package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.implementations;

import java.util.List;
import java.util.NoSuchElementException;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.ItemMenu;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Categoria;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums.TipoItem;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.ItemMenuDAO;

@Repository
public class ItemMenuDAOImplementacion implements ItemMenuDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    @Transactional
    public ItemMenu save(ItemMenu itemMenu) {
        entityManager.persist(itemMenu);
        return itemMenu;
    }

    @Override
    @Transactional
    public void actualizarItemMenu(ItemMenu itemMenu) {
        entityManager.merge(itemMenu);
    }

    @Override
    @Transactional
    public List<ItemMenu> buscarPorFiltros(int id_item_menu, String nombre, int id_vendedor, TipoItem tipo_item, int id_categoria) {

        // Construimos la consulta dinámica
        StringBuilder queryStr = new StringBuilder(
                "SELECT i FROM ItemMenu i " +
                        "JOIN FETCH i.categoria c " +
                        "JOIN FETCH i.vendedor v " +
                        "WHERE 1 = 1"
        );

        if (id_item_menu > 0) {
            queryStr.append(" AND i.id_item_menu = :id_item_menu");
        }

        if (id_vendedor > 0) {
            queryStr.append(" AND v.id_vendedor = :id_vendedor");
        }

        if (id_categoria > 0) {
            queryStr.append(" AND c.id_categoria = :id_categoria");
        }

        if (nombre != null && !nombre.isEmpty()) {
            queryStr.append(" AND i.nombre LIKE :nombre");
        }

        if (tipo_item != null) {
            queryStr.append(" AND c.tipoItem = :tipo_item");
        }

        TypedQuery<ItemMenu> query = entityManager.createQuery(queryStr.toString(), ItemMenu.class);
        // Asignamos los parámetros
        if (id_item_menu > 0) {
            query.setParameter("id_item_menu", id_item_menu);
        }

        if (id_vendedor > 0) {
            query.setParameter("id_vendedor", id_vendedor);
        }

        if (id_categoria > 0) {
            query.setParameter("id_categoria", id_categoria);
        }

        // Usamos '%' para realizar una búsqueda parcial por datos ingresados:

        if (nombre != null && !nombre.isEmpty()) {
            query.setParameter("nombre", "%" + nombre + "%");
        }

        if (tipo_item != null) {
            query.setParameter("tipo_item", tipo_item);
        }

        return query.getResultList();

    }

    @Override
    @Transactional
    public long totalItemsMenuEnBD() {
        TypedQuery<Long> query = entityManager.createQuery("SELECT COUNT(i) FROM ItemMenu i", Long.class);
        return query.getSingleResult();
    }

    @Override
    @Transactional
    public ItemMenu findItemById(int id) {
        try {
            return entityManager.find(ItemMenu.class, id);
        } catch (Exception e) {
            System.out.println("Error al encontrar el ítem: " + e.getMessage());
            return null;
        }
    }

    @Override
    @Transactional
    public Categoria findCatById(int id) {
        try {
            return entityManager.find(Categoria.class, id);
        } catch (Exception e) {
            System.out.println("Error al encontrar la Categoria: " + e.getMessage());
            return null;
        }
    }

    @Override
    @Transactional
    public void deleteById(int id) {
        // Obtenemos la entidad a eliminar usando el ID:
        ItemMenu itemMenu = findItemById(id);

        if (itemMenu != null) {
            // Si existe, la eliminamos:
            entityManager.remove(itemMenu);
        } else {
            throw new NoSuchElementException("No se encontró un ítem con el ID: " + id);
        }
    }

    // Metodo para poder devolver todas las categorias de la base de datos a la interfaz de usuario.
    @Override
    @Transactional
    public List<Categoria> findAllCategorias() {
        TypedQuery<Categoria> query = entityManager.createQuery("SELECT c FROM Categoria c", Categoria.class);
        return query.getResultList();
    }

    // Metodo para devolver la lista de los ítems asociados a un vendedor de la base de datos a la interfaz de usuario.
    @Override
    @Transactional
    public List<ItemMenu> findAllItemsPorVendedor(int id_vendedor){
        TypedQuery<ItemMenu> query = entityManager.createQuery(
                "SELECT i FROM ItemMenu i WHERE i.vendedor.id = :idVendedor", ItemMenu.class
        );
        query.setParameter("idVendedor", id_vendedor);
        return query.getResultList();
    }

}