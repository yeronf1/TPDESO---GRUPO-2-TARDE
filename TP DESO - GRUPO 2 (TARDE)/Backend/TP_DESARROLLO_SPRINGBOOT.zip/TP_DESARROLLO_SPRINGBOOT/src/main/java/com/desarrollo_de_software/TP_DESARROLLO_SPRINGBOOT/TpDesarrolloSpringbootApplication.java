package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpDesarrolloSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpDesarrolloSpringbootApplication.class, args);
	}

}
