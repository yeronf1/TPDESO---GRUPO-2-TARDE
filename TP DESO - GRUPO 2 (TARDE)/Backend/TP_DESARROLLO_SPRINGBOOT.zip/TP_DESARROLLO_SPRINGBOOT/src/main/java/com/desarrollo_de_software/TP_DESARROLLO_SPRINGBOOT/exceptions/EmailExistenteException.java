package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.exceptions;

public class EmailExistenteException extends RuntimeException {
    public EmailExistenteException(String message) {
        super(message);
    }
}
