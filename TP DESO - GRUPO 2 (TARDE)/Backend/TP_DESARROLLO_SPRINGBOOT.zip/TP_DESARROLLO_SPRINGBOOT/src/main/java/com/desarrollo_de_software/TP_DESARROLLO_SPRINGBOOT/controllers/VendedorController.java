package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.controllers;

import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.NoSuchElementException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.VendedorDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services.GestorDeVendedores;

@RestController
@RequestMapping("/vendedor")
public class VendedorController {

    private final GestorDeVendedores gestorDeVendedores;

    @Autowired
    public VendedorController(GestorDeVendedores gestorDeVendedores) {
        this.gestorDeVendedores = gestorDeVendedores;
    }

    @PostMapping("/registrar")
    public ResponseEntity<Map<String, String>> registrarVendedor(@RequestBody VendedorDTO vendedorDTO) {

        Map<String, String> response = new HashMap<>();

        try {

            gestorDeVendedores.registrarVendedor(vendedorDTO);

            response.put("message", "Vendedor registrado exitosamente.");
            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor."); // Por ejemplo, si no se conectó bien el front con el back.
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/buscar")
    public ResponseEntity<Map<String, Object>> buscarVendedor(@RequestBody VendedorDTO vendedorDTO) {

        Map<String, Object> response = new HashMap<>();

        try {
            // Obtenemos los vendedores que coinciden con los filtros (si no hay filtros ingresados, se muestran todos los vendedores de la base de datos):
            List<VendedorDTO> vendedores = gestorDeVendedores.buscarVendedor(vendedorDTO);

            // Obtenemos el total de vendedores en la base de datos.
            long totalVendedores = gestorDeVendedores.contarTotalVendedores();

            if (vendedores.isEmpty()) {
                response.put("message", "No se encontraron vendedores que coincidan con los filtros especificados.");
                response.put("totalResultados", totalVendedores); // Incluimos el total de vendedores aunque no haya resultados.
                return ResponseEntity.ok(response);
            }

            response.put("message", "Vendedores encontrados exitosamente.");
            response.put("data", vendedores);
            response.put("totalResultados", totalVendedores); // Incluimos el total de vendedores.

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @DeleteMapping("/eliminar")
    public ResponseEntity<Map<String, Object>> eliminarVendedor(@RequestBody VendedorDTO vendedorDTO) {

        Map<String, Object> response = new HashMap<>();

        try {

            gestorDeVendedores.eliminarVendedor(vendedorDTO);

            response.put("message", "Vendedor eliminado exitosamente.");
            return ResponseEntity.ok(response);

        } catch (NoSuchElementException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PutMapping("/modificar")
    public ResponseEntity<Map<String, Object>> modificarVendedor(@RequestBody VendedorDTO vendedorDTO) {

        Map<String, Object> response = new HashMap<>();

        try {

            gestorDeVendedores.modificarVendedor(vendedorDTO);

            response.put("message", "Vendedor modificado exitosamente.");
            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException | NoSuchElementException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/obtenerVendedores") // Ruta específica para obtener la lista entera de los vendedores en la base de datos (para mostrar en la lista desplegable).
    public ResponseEntity<Map<String, Object>> obtenerIDVendedores() {

        Map<String, Object> response = new HashMap<>();

        try {

            List<VendedorDTO> vendedores = gestorDeVendedores.obtenerVendedores();

            if (vendedores.isEmpty()) {
                response.put("message", "No se encontraron vendedores.");
                return ResponseEntity.ok(response);
            }

            response.put("message", "Vendedores encontradas exitosamente.");
            response.put("data", vendedores);
            return ResponseEntity.ok(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }


}