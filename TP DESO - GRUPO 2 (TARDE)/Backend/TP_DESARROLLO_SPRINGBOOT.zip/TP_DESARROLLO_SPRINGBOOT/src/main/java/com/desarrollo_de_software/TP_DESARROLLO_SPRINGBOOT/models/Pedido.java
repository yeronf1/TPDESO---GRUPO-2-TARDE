package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models;

import java.util.List;
import java.util.ArrayList;
import java.util.Observable;
import jakarta.persistence.*;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums.Estado;

@Entity
@Table(name = "pedidos")
public class Pedido extends Observable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_pedido;

    @ManyToOne
    @JoinColumn(name = "id_cliente", nullable = false)
    private Cliente cliente;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    private List<ItemPedido> pedidosDetalle = new ArrayList<>();

    private double total;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "id_pago")
    private Pago formaDePago;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Estado estadoPedido;

    // GETTERS Y SETTERS:

    public int getId_pedido() {
        return id_pedido;
    }

    public void setId_pedido(int id_pedido) {
        this.id_pedido = id_pedido;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<ItemPedido> getPedidosDetalle() {
        return pedidosDetalle;
    }

    public void setPedidosDetalle(List<ItemPedido> pedidosDetalle) {
        this.pedidosDetalle = pedidosDetalle;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Pago getFormaDePago() {
        return formaDePago;
    }

    public void setFormaDePago(Pago formaDePago) {
        this.formaDePago = formaDePago;
    }

    public Estado getEstadoPedido() {
        return estadoPedido;
    }

    public void setEstadoPedido(Estado estadoPedido) {
        this.estadoPedido = estadoPedido;
    }

    // CONSTRUCTORES:

    public Pedido() {
    }

    public Pedido(int id_pedido, Cliente cliente) {
        this.id_pedido = id_pedido;
        this.cliente = cliente;
        this.pedidosDetalle = new ArrayList<>();
        this.total = 0.0;
        this.estadoPedido = Estado.EN_PROCESO;

        // Este patrón de inicialización está diseñado para casos de uso previos a calcular el total y establecer el estado.
    }

    // MÉTODOS DE CONSIGNA:

    public void agregarADetalle(ItemPedido item) {
        total += item.getItemMenu().getPrecio() * item.getCantidad();
        this.pedidosDetalle.add(item);
    }

    public double calcularTotal() {
        double totalConRecargo = total;

        if (formaDePago != null) {
            totalConRecargo = formaDePago.calcularRecargo(total);
        }

        return totalConRecargo;
    }

    public void cambiarEstadoPedido(){
        setEstadoPedido((Estado.EN_ENVIO));
        setChanged();
        notifyObservers();
    }

}