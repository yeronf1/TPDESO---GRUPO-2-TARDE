package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs;

public class ItemPedidoDTO {

    private int idItemPedido;
    private int idPedido;
    private ItemMenuDTO itemMenuDTO;
    private int cantidad;
    private int idItemMenu;
    private String nombre;
    private double precio;

    // GETTERS Y SETTERS:

    public int getIdItemPedido() {
        return idItemPedido;
    }

    public void setIdItemPedido(int idItemPedido) {
        this.idItemPedido = idItemPedido;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public ItemMenuDTO getItemMenuDTO() {return itemMenuDTO;}

    public void setItemMenuDTO(ItemMenuDTO itemMenuDTO) {this.itemMenuDTO = itemMenuDTO;}

    public int getCantidad() {return cantidad;}

    public void setCantidad(int cantidad) {this.cantidad = cantidad;}

    public int getIdItemMenu() {return idItemMenu;}

    public void setIdItemMenu(int idItemMenu) {this.idItemMenu = idItemMenu;}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    // CONSTRUCTORES:

    public ItemPedidoDTO() {
    }

    public ItemPedidoDTO(int idItemPedido, int idPedido, ItemMenuDTO itemMenuDTO, int cantidad, int idItemMenu, String nombre, double precio) {
        this.idItemPedido = idItemPedido;
        this.idPedido = idPedido;
        this.itemMenuDTO = itemMenuDTO;
        this.cantidad = cantidad;
        this.idItemMenu = idItemMenu;
        this.nombre = nombre;
        this.precio = precio;
    }
}
