package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models;

import java.util.List;
import java.util.ArrayList;
import java.util.Observer;
import java.util.Observable;
import java.io.Serializable;
import jakarta.persistence.*;

@Entity
@Table(name = "clientes")
public class Cliente implements Serializable, Observer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_cliente;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(nullable = false, unique = true, length = 20)
    private String cuit;

    @Column(nullable = false, unique = true, length = 100)
    private String email;

    @Column(nullable = false, length = 255)
    private String direccion;

    @Embedded
    private Coordenada coordenadas;

    @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Pedido> pedidos = new ArrayList<>();

    // GETTERS Y SETTERS:

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Coordenada getCoordenadas() {
        return coordenadas;
    }

    public void setCoordenadas(Coordenada coordenadas) {
        this.coordenadas = coordenadas;
    }

    public List<Pedido> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<Pedido> pedidos) {
        this.pedidos = pedidos;
    }

    // CONSTRUCTORES:

    public Cliente() {
    }

    public Cliente(int id_cliente, String nombre, String cuit, String email, String direccion, Coordenada coordenadas, List<Pedido> pedidos) {
        this.id_cliente = id_cliente;
        this.nombre = nombre;
        this.cuit = cuit;
        this.email = email;
        this.direccion = direccion;
        this.coordenadas = coordenadas;
        this.pedidos = pedidos;
    }

    // METODO DE OBSERVER IMPLEMENTADO:

    @Override
    public void update(Observable o, Object arg) {
        System.out.println("\n(EL SIGUIENTE MENSAJE SÓLO SERÁ VISUALIZABLE EN LA INTERFAZ CLIENTE).");
        System.out.println("Tu pedido ha sido aceptado y está en estado: " + ((Pedido)o).getEstadoPedido() + ".");
    }
}