package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository;

import java.util.List;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.ItemMenu;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Categoria;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums.TipoItem;

public interface ItemMenuDAO {

    ItemMenu save (ItemMenu itemMenu);
    void actualizarItemMenu(ItemMenu itemMenu);
    List<ItemMenu> buscarPorFiltros(int id_item_menu, String nombre, int id_vendedor, TipoItem tipo_item, int id_categoria);
    long totalItemsMenuEnBD();
    ItemMenu findItemById(int id);
    Categoria findCatById(int id);
    void deleteById(int id);
    List<Categoria> findAllCategorias();
    List<ItemMenu> findAllItemsPorVendedor(int id_vendedor);

}
