package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.implementations;

import java.util.List;
import java.util.NoSuchElementException;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Pedido;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.ItemPedido;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums.Estado;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.PedidoDAO;

@Repository
public class PedidoDAOImplementacion implements PedidoDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    @Transactional
    public Pedido save(Pedido pedido) {
        entityManager.persist(pedido);
        return pedido;
    }

    @Override
    @Transactional
    public void actualizarPedido(Pedido pedido) {
        entityManager.merge(pedido);
    }

    @Override
    @Transactional
    public List<Pedido> buscarPorFiltros(int idPedido, String nombreCliente, Estado estadoPedido, int id_vendedor) {

        StringBuilder queryStr = new StringBuilder(
                "SELECT DISTINCT p FROM Pedido p " +
                        "JOIN FETCH p.pedidosDetalle d " +
                        "JOIN FETCH d.itemMenu im " +
                        "JOIN FETCH im.vendedor v " +
                        "JOIN p.cliente c " +
                        "WHERE 1 = 1"
        );

        if (idPedido > 0) {
            queryStr.append(" AND p.id_pedido = :idPedido");
        }

        if (nombreCliente != null && !nombreCliente.isEmpty()) {
            queryStr.append(" AND c.nombre LIKE :nombreCliente");
        }

        if (estadoPedido != null) {
            queryStr.append(" AND p.estadoPedido = :estadoPedido");
        }

        if (id_vendedor > 0) {
            queryStr.append(" AND v.id_vendedor = :id_vendedor");
        }

        TypedQuery<Pedido> query = entityManager.createQuery(queryStr.toString(), Pedido.class);

        if (idPedido > 0) {
            query.setParameter("idPedido", idPedido);
        }

        if (nombreCliente != null && !nombreCliente.isEmpty()) {
            query.setParameter("nombreCliente", "%" + nombreCliente + "%");
        }

        if (estadoPedido != null) {
            query.setParameter("estadoPedido", estadoPedido);
        }

        if (id_vendedor > 0) {
            query.setParameter("id_vendedor",id_vendedor);
        }

        return query.getResultList();
    }

    @Override
    @Transactional
    public long totalPedidosEnBD() {
        TypedQuery<Long> query = entityManager.createQuery("SELECT COUNT(p) FROM Pedido p", Long.class);
        return query.getSingleResult();
    }

    @Override
    @Transactional
    public Pedido findById(int id) {
        return entityManager.find(Pedido.class, id);
    }

    @Override
    @Transactional
    public void deleteById(int id) {
        // Obtenemos la entidad a eliminar usando el ID:
        Pedido pedido = findById(id);

        if (pedido != null) {
            // Si existe, la eliminamos:
            entityManager.remove(pedido);
        } else {
            throw new NoSuchElementException("No se encontró un pedido con el ID: " + id);
        }
    }

    // Metodo para devolver la lista de los ítems asociados a un pedido de la base de datos a la interfaz de usuario.
    @Override
    @Transactional
    public List<ItemPedido> findAllItemsPorPedido(int id_pedido) {
        TypedQuery<ItemPedido> query = entityManager.createQuery(
                "SELECT ip FROM ItemPedido ip " +
                        "JOIN ip.itemMenu i " +
                        "JOIN ip.pedido p " +
                        "WHERE p.id = :idPedido",
                ItemPedido.class
        );
        query.setParameter("idPedido", id_pedido);
        return query.getResultList();
    }

}