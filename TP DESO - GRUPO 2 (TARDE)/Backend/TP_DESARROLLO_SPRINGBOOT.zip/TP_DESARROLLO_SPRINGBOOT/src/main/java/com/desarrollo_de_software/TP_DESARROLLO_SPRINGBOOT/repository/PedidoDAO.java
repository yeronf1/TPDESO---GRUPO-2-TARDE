package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository;

import java.util.List;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Pedido;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.ItemPedido;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums.Estado;

public interface PedidoDAO {

    Pedido save(Pedido pedido);
    void actualizarPedido(Pedido pedido);
    List<Pedido> buscarPorFiltros(int idPedido, String nombreCliente, Estado estadoPedido, int id_vendedor);
    long totalPedidosEnBD();
    Pedido findById(int id);
    void deleteById(int id);
    List<ItemPedido> findAllItemsPorPedido(int id_pedido);

}
