package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models;

import java.util.List;
import java.util.ArrayList;
import jakarta.persistence.*;

@Entity
@Table(name = "items_menu")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public abstract class ItemMenu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_item_menu", nullable = false, unique = true)
    private int id_item_menu;

    @OneToMany(mappedBy = "itemMenu", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private List<ItemPedido> itemPedidos = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "id_vendedor", referencedColumnName = "id_vendedor")
    private Vendedor vendedor;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "precio", nullable = false)
    private double precio;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_categoria", referencedColumnName = "id_categoria")
    private Categoria categoria;

    // GETTERS Y SETTERS:

    public int getId_item_menu() {
        return id_item_menu;
    }

    public void setId_item_menu(int id_item_menu) {
        this.id_item_menu = id_item_menu;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    // CONSTRUCTORES:

    public ItemMenu() {
    }

    public ItemMenu(int id_item_menu, Vendedor vendedor, String nombre, String descripcion, double precio, Categoria categoria) {
        this.id_item_menu = id_item_menu;
        this.vendedor = vendedor;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.categoria = categoria;
    }

    // METODOS ABSTRACTOS:

    public abstract double peso();
    public abstract boolean esComida();
    public abstract boolean esBebida();
    public abstract boolean aptoVegetariano();

}