package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.implementations;

import java.util.List;
import java.util.NoSuchElementException;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Cliente;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.ClienteDAO;

@Repository
public class ClienteDAOImplementacion implements ClienteDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    @Transactional
    public Cliente save(Cliente cliente) {
        entityManager.persist(cliente);
        return cliente;
    }

    @Override
    @Transactional
    public void actualizarCliente(Cliente cliente) {
        entityManager.merge(cliente);
    }

    @Override
    public List<Cliente> buscarPorFiltros(int id_cliente, String nombre, String cuit, String email, String direccion) {

        StringBuilder queryStr = new StringBuilder("SELECT c FROM Cliente c WHERE 1 = 1");

        if (id_cliente > 0) {
            queryStr.append(" AND c.id_cliente = :id_cliente");
        }

        if (nombre != null && !nombre.isEmpty()) {
            queryStr.append(" AND c.nombre LIKE :nombre");
        }

        if (cuit != null && !cuit.isEmpty()) {
            queryStr.append(" AND c.cuit LIKE :cuit");
        }

        if (email != null && !email.isEmpty()) {
            queryStr.append(" AND c.email LIKE :email");
        }

        if (direccion != null && !direccion.isEmpty()) {
            queryStr.append(" AND c.direccion LIKE :direccion");
        }

        TypedQuery<Cliente> query = entityManager.createQuery(queryStr.toString(), Cliente.class);

        if (id_cliente > 0) {
            query.setParameter("id_cliente", id_cliente);
        }

        // Usamos '%' para realizar una búsqueda parcial por datos ingresados:

        if (nombre != null && !nombre.isEmpty()) {
            query.setParameter("nombre", "%" + nombre + "%");
        }

        if (cuit != null && !cuit.isEmpty()) {
            query.setParameter("cuit", "%" + cuit + "%");
        }

        if (email != null && !email.isEmpty()) {
            query.setParameter("email", "%" + email + "%");
        }

        if (direccion != null && !direccion.isEmpty()) {
            query.setParameter("direccion", "%" + direccion + "%");
        }

        return query.getResultList();

    }

    @Override
    @Transactional
    public long totalClientesEnBD() {
        TypedQuery<Long> query = entityManager.createQuery("SELECT COUNT(c) FROM Cliente c", Long.class);
        return query.getSingleResult();
    }

    @Override
    @Transactional
    public Cliente findById(int id) {
        return entityManager.find(Cliente.class, id);
    }

    @Override
    @Transactional
    public void deleteById(int id) {
        // Obtenemos la entidad a eliminar usando el ID:
        Cliente cliente = findById(id);

        if (cliente != null) {
            // Si existe, la eliminamos:
            entityManager.remove(cliente);
        } else {
            throw new NoSuchElementException("No se encontró un cliente con el ID: " + id);
        }
    }

    // Metodo para poder devolver todos los clientes de la base de datos a la interfaz de usuario.
    @Override
    @Transactional
    public List<Cliente> findAll() {
        TypedQuery<Cliente> query = entityManager.createQuery("SELECT c FROM Cliente c", Cliente.class);
        return query.getResultList();
    }

}