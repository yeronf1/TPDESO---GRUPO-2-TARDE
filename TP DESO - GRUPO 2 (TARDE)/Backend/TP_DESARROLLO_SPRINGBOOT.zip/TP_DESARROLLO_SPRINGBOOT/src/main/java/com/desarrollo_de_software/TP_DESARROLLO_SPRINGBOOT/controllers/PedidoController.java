package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.controllers;

import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.NoSuchElementException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.PedidoDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.ItemPedidoDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services.GestorDePedidos;

@RestController
@RequestMapping("/pedido")
public class PedidoController {

    private final GestorDePedidos gestorDePedidos;

    @Autowired
    public PedidoController(GestorDePedidos gestorDePedidos) {
        this.gestorDePedidos = gestorDePedidos;
    }

    @PostMapping("/registrar")
    public ResponseEntity<Map<String, String>> registrarPedido(@RequestBody PedidoDTO pedidoDTO) {
        Map<String, String> response = new HashMap<>();

        try {

            gestorDePedidos.registrarPedido(pedidoDTO);
            response.put("message", "Pedido registrado exitosamente.");
            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException ex) {
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) {
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/buscar")
    public ResponseEntity<Map<String, Object>> buscarPedido(@RequestBody PedidoDTO pedidoDTO) {
        Map<String, Object> response = new HashMap<>();

        try {

            List<PedidoDTO> pedidos = gestorDePedidos.buscarPedidos(pedidoDTO);

            long totalPedidos = gestorDePedidos.contarTotalPedidos();

            if (pedidos.isEmpty()) {
                response.put("message", "No se encontraron pedidos que coincidan con los filtros especificados.");
                response.put("totalResultados", totalPedidos);
                return ResponseEntity.ok(response);
            }

            response.put("message", "Pedidos encontrados exitosamente.");
            response.put("data", pedidos);
            response.put("totalResultados", totalPedidos);

            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException ex) {
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception ex) {
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @DeleteMapping("/eliminar")
    public ResponseEntity<Map<String, Object>> eliminarPedido(@RequestBody PedidoDTO pedidoDTO) {
        Map<String, Object> response = new HashMap<>();

        try {
            gestorDePedidos.eliminarPedido(pedidoDTO);
            response.put("message", "Pedido eliminado exitosamente.");
            return ResponseEntity.ok(response);

        } catch (NoSuchElementException ex) {
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) {
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PutMapping("/actualizarEstado")
    public ResponseEntity<Map<String, Object>> actualizarEstadoPedido(@RequestBody PedidoDTO pedidoDTO) {
        Map<String, Object> response = new HashMap<>();

        try {
            gestorDePedidos.actualizarEstadoPedido(pedidoDTO);
            response.put("message", "Estado de pedido actualizado a EN ENVIO.");
            return ResponseEntity.ok(response);

        } catch (NoSuchElementException ex) {
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) {
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/verDetalle")
    public ResponseEntity<Map<String, Object>> verDetallePedido(@RequestBody PedidoDTO pedidoDTO) {

        Map<String, Object> response = new HashMap<>();

        try {

            List<ItemPedidoDTO> itemsPorPedido = gestorDePedidos.verDetallePedido(pedidoDTO);

            if (itemsPorPedido.isEmpty()) {
                response.put("message", "No se encontraron items para ese pedido.");
                return ResponseEntity.ok(response);
            }

            response.put("message", "Ítems encontrados exitosamente.");
            response.put("data", itemsPorPedido);
            return ResponseEntity.ok(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }

    }

}