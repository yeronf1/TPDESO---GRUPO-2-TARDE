package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services;

import java.util.List;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.*;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.PedidoDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.ItemMenuDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.CategoriaDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums.TipoItem;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.ItemMenuDAO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services.validationServices.ValidadorRegistro;

@Service
public class GestorDeItemsMenu {

    private final ItemMenuDAO itemMenuDAO;
    private final GestorDeVendedores gestorDeVendedores;
    private final ValidadorRegistro validadorRegistro;

    @Autowired
    public GestorDeItemsMenu(ItemMenuDAO itemMenuDAO, ValidadorRegistro validadorRegistro, GestorDeVendedores gestorDeVendedores ) {
        this.itemMenuDAO = itemMenuDAO;
        this.validadorRegistro = validadorRegistro;
        this.gestorDeVendedores = gestorDeVendedores;
    }

    // Metodo para registrar un nuevo item menú en la base de datos:
    public void registrarItemMenu(ItemMenuDTO itemMenuDTO) {

        // Encapsulamos la lógica de validación de datos de entrada dentro del mismo metodo de registro de ítem menú:
        try {
            validadorRegistro.validarCrearItemMenu(itemMenuDTO);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(e.getMessage());
        }

        // Creamos la entidad y le asignamos los respectivos datos dependiendo el tipo:

        if(itemMenuDTO.getTipo_item_menu() == TipoItem.COMIDA){
            Plato plato = new Plato();

            plato.setNombre(itemMenuDTO.getNombre());
            plato.setDescripcion(itemMenuDTO.getDescripcion());
            plato.setCategoria(itemMenuDAO.findCatById(itemMenuDTO.getId_categoria()));

            if (plato.getCategoria() == null) {
                System.out.println("No se encontró la categoría con el ID proporcionado.");
                throw new IllegalArgumentException("Categoría no válida: " + itemMenuDTO.getId_categoria());
            }

            plato.setPrecio(itemMenuDTO.getPrecio());
            plato.setVendedor(gestorDeVendedores.obtenerVendedorPorID(itemMenuDTO.getId_vendedor()));

            plato.setPeso(itemMenuDTO.getPeso());
            plato.setCalorias(itemMenuDTO.getCalorias());

            plato.setAptoVegetariano(itemMenuDTO.getAptoVegetariano());
            plato.setAptoCeliaco(itemMenuDTO.getAptoCeliaco());

            itemMenuDAO.save(plato);

        } else {
            Bebida bebida = new Bebida();

            bebida.setNombre(itemMenuDTO.getNombre());
            bebida.setDescripcion(itemMenuDTO.getDescripcion());
            bebida.setCategoria(itemMenuDAO.findCatById(itemMenuDTO.getId_categoria()));

            if (bebida.getCategoria() == null) {
                System.out.println("No se encontró la categoría con el ID proporcionado.");
                throw new IllegalArgumentException("Categoría no válida: " + itemMenuDTO.getId_categoria());
            }

            bebida.setPrecio(itemMenuDTO.getPrecio());
            bebida.setVendedor(gestorDeVendedores.obtenerVendedorPorID(itemMenuDTO.getId_vendedor()));
            bebida.setGraduacionAlcoholica(itemMenuDTO.getGraduacionAlcoholica());
            bebida.setVolumen(itemMenuDTO.getVolumen());
            bebida.setEsGaseosa(itemMenuDTO.getEs_gaseosa());

            itemMenuDAO.save(bebida);

        }

    }

    @Transactional
    // Metodo usado para buscar los items menú que coincidan con los filtros de búsqueda ingresados:
    public List<ItemMenuDTO> buscarItemMenu(ItemMenuDTO itemMenuDTO) {

        List<ItemMenu> itemsEncontrados = itemMenuDAO.buscarPorFiltros(itemMenuDTO.getId_item_menu(),itemMenuDTO.getNombre(),
                                                                       itemMenuDTO.getId_vendedor(), itemMenuDTO.getTipo_item_menu(), itemMenuDTO.getId_categoria());

        // Convertimos todas las entidades de items menú encontradas a DTOs para trasnferirlos a la capa de presentación:
        List<ItemMenuDTO> itemMenuDTOS = new ArrayList<>();

        for (ItemMenu itemMenu : itemsEncontrados) {
            ItemMenuDTO itemDTOEncontrado = new ItemMenuDTO();

            itemDTOEncontrado.setId_item_menu(itemMenu.getId_item_menu());
            itemDTOEncontrado.setNombre(itemMenu.getNombre());
            itemDTOEncontrado.setDescripcion(itemMenu.getDescripcion());
            itemDTOEncontrado.setId_categoria(itemMenu.getCategoria().getId_categoria());
            itemDTOEncontrado.setNombreCategoria(itemMenu.getCategoria().getDescripcion_categoria());

            if (itemMenu.getCategoria() == null) {
                System.out.println("No se encontró la categoría con el ID proporcionado.");
                throw new IllegalArgumentException("Categoría no válida: " + itemMenuDTO.getId_categoria());
            }

            itemDTOEncontrado.setPrecio(itemMenu.getPrecio());
            itemDTOEncontrado.setId_vendedor(itemMenu.getVendedor().getId_vendedor());
            itemDTOEncontrado.setNombreVendedor(itemMenu.getVendedor().getNombre());

            if(itemMenu.getCategoria().getTipoItem() == TipoItem.COMIDA){

                Plato plato = (Plato) itemMenu;

                itemDTOEncontrado.setTipo_item_menu(plato.getCategoria().getTipoItem());
                itemDTOEncontrado.setPeso(plato.peso());
                itemDTOEncontrado.setCalorias(plato.getCalorias());
                itemDTOEncontrado.setAptoVegetariano(plato.getAptoVegetariano());
                itemDTOEncontrado.setAptoCeliaco(plato.getAptoCeliaco());

            } else {

                Bebida bebida = (Bebida) itemMenu;

                itemDTOEncontrado.setTipo_item_menu(bebida.getCategoria().getTipoItem());
                itemDTOEncontrado.setGraduacionAlcoholica(bebida.getGraduacionAlcoholica());
                itemDTOEncontrado.setVolumen(bebida.getVolumen());
                itemDTOEncontrado.setEs_gaseosa(bebida.getEsGaseosa());

            }

            itemMenuDTOS.add(itemDTOEncontrado);
        }

        return itemMenuDTOS;

    }

    // Metodo para contar el total de items menú en la base de datos (para poder mostrar en la interfaz: 'X items menú encontrados de Y totales').
    public long contarTotalItemsMenu() {
        return itemMenuDAO.totalItemsMenuEnBD();
    }

    public ItemMenu obtenerItemMenuPorID(int id_item_menu){
        return itemMenuDAO.findItemById(id_item_menu);
    }

    // Metodo para realizar la eliminación FÍSICA de un ítem menú:
    public void eliminarItemMenu(ItemMenuDTO itemMenuDTO) {

        try{
            itemMenuDAO.deleteById(itemMenuDTO.getId_item_menu());
        } catch (NoSuchElementException ex){
            throw new NoSuchElementException(ex.getMessage());
        }

    }

    // Metodo para modificar los datos de un ítem menú exsistente en la base de datos:
    public void modificarItemMenu(ItemMenuDTO itemMenuDTO) {

        try {
            // Validamos los datos del ítem menú
            validadorRegistro.validarModificarItemMenu(itemMenuDTO);

            // Buscamos el ítem menú en la base de datos por su ID
            ItemMenu itemMenu = itemMenuDAO.findItemById(itemMenuDTO.getId_item_menu());

            if (itemMenu == null) {
                throw new NoSuchElementException("No se encontró un Ítem menú con el ID: " + itemMenuDTO.getId_item_menu());
            }

            // Actualizamos los datos del ítem menú
            if(itemMenuDTO.getTipo_item_menu() == TipoItem.COMIDA){
                Plato plato = (Plato) itemMenu;

                plato.setNombre(itemMenuDTO.getNombre());
                plato.setDescripcion(itemMenuDTO.getDescripcion());

                plato.setPrecio(itemMenuDTO.getPrecio());
                plato.setVendedor(gestorDeVendedores.obtenerVendedorPorID(itemMenuDTO.getId_vendedor()));

                plato.setPeso(itemMenuDTO.getPeso());
                plato.setCalorias(itemMenuDTO.getCalorias());

                plato.setAptoVegetariano(itemMenuDTO.getAptoVegetariano());
                plato.setAptoCeliaco(itemMenuDTO.getAptoCeliaco());

                // Persistimos los cambios:
                itemMenuDAO.actualizarItemMenu(plato);

            } else {
                Bebida bebida = (Bebida) itemMenu;

                bebida.setNombre(itemMenuDTO.getNombre());
                bebida.setDescripcion(itemMenuDTO.getDescripcion());

                bebida.setPrecio(itemMenuDTO.getPrecio());
                bebida.setVendedor(gestorDeVendedores.obtenerVendedorPorID(itemMenuDTO.getId_vendedor()));
                bebida.setGraduacionAlcoholica(itemMenuDTO.getGraduacionAlcoholica());
                bebida.setVolumen(itemMenuDTO.getVolumen());
                bebida.setEsGaseosa(itemMenuDTO.getEs_gaseosa());

                // Persistimos los cambios:
                itemMenuDAO.actualizarItemMenu(bebida);

            }

        } catch (IllegalArgumentException e) { // Excepción para datos no válidos.
            throw new IllegalArgumentException(e.getMessage(), e);
        } catch (NoSuchElementException e) { // Excepción si el ítem menú no existe.
            throw new NoSuchElementException(e.getMessage(), e);
        }
    }

    // Metodo para obtener todas las categorias de la base de datos y poder mostrarlas en la interfaz de usuario para seleccionar:
    public List<CategoriaDTO> obtenerCategorias() {

        // Recuperamos de la base de datos todas las entidades de categorias que existan:
        List<Categoria> categorias = itemMenuDAO.findAllCategorias();

        // Convertimos las entidades en DTOs para transferirlas a la capa de presentación:
        List<CategoriaDTO> categoriaDTOS = new ArrayList<>();

        for (Categoria categoria : categorias) {
            CategoriaDTO categoriaDTO = new CategoriaDTO();
            categoriaDTO.setId_categoria(categoria.getId_categoria());
            categoriaDTO.setNombre_categoria(categoria.getDescripcion_categoria());
            categoriaDTOS.add(categoriaDTO);
        }

        return categoriaDTOS;
    }

    // Metodo para obtener la lista entera de los ítems asociados a un vendedor en la base de datos (para mostrar en la lista desplegable).
    @Transactional
    public List<ItemMenuDTO> obtenerItemMenuPorVendedor(PedidoDTO pedidoDTO) {

        // Recuperamos de la base de datos todas las entidades de categorias que existan:
        List<ItemMenu> itemsMenu = itemMenuDAO.findAllItemsPorVendedor(pedidoDTO.getIdVendedor());

        // Convertimos todas las entidades de items menú encontradas a DTOs para trasnferirlos a la capa de presentación:
        List<ItemMenuDTO> itemMenuDTOS = new ArrayList<>();

        for (ItemMenu itemMenu : itemsMenu) {
            ItemMenuDTO itemDTOEncontrado = new ItemMenuDTO();

            itemDTOEncontrado.setId_item_menu(itemMenu.getId_item_menu());
            itemDTOEncontrado.setNombre(itemMenu.getNombre());
            itemDTOEncontrado.setDescripcion(itemMenu.getDescripcion());
            itemDTOEncontrado.setId_categoria(itemMenu.getCategoria().getId_categoria());

            itemDTOEncontrado.setPrecio(itemMenu.getPrecio());
            itemDTOEncontrado.setId_vendedor(itemMenu.getVendedor().getId_vendedor());
            itemDTOEncontrado.setNombreVendedor(itemMenu.getVendedor().getNombre());

            if(itemMenu.getCategoria().getTipoItem() == TipoItem.COMIDA){

                Plato plato = (Plato) itemMenu;

                itemDTOEncontrado.setTipo_item_menu(plato.getCategoria().getTipoItem());
                itemDTOEncontrado.setPeso(plato.peso());
                itemDTOEncontrado.setCalorias(plato.getCalorias());
                itemDTOEncontrado.setAptoVegetariano(plato.getAptoVegetariano());
                itemDTOEncontrado.setAptoCeliaco(plato.getAptoCeliaco());

            } else {

                Bebida bebida = (Bebida) itemMenu;

                itemDTOEncontrado.setTipo_item_menu(bebida.getCategoria().getTipoItem());
                itemDTOEncontrado.setGraduacionAlcoholica(bebida.getGraduacionAlcoholica());
                itemDTOEncontrado.setVolumen(bebida.getVolumen());
                itemDTOEncontrado.setEs_gaseosa(bebida.getEsGaseosa());

            }

            itemMenuDTOS.add(itemDTOEncontrado);
        }

        return itemMenuDTOS;
    }

}