package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models;

import java.util.List;
import java.util.ArrayList;
import jakarta.persistence.*;

@Entity
@Table(name = "vendedores")
public class Vendedor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_vendedor;

    private String nombre;
    private String direccion;

    @Embedded
    private Coordenada coordenadas;

    @OneToMany(mappedBy = "vendedor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ItemMenu> itemsMenu = new ArrayList<>();

    // GETTERS Y SETTERS:
    public int getId_vendedor() {
        return id_vendedor;
    }

    public void setId_vendedor(int id_vendedor) {
        this.id_vendedor = id_vendedor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Coordenada getCoordenadas() {
        return coordenadas;
    }

    public void setCoordenadas(Coordenada coordenadas) {
        this.coordenadas = coordenadas;
    }

    public List<ItemMenu> getItemsMenu() {
        return itemsMenu;
    }

    public void setItemsMenu(List<ItemMenu> itemsMenu) {
        this.itemsMenu = itemsMenu;
    }

    // CONSTRUCTORES:
    public Vendedor() {
        this.itemsMenu = new ArrayList<>();
    }

    public Vendedor(int id_vendedor, String nombre, String direccion, Coordenada coordenadas) {
        this.id_vendedor = id_vendedor;
        this.nombre = nombre;
        this.direccion = direccion;
        this.coordenadas = coordenadas;
        this.itemsMenu = new ArrayList<>();
    }

    // METODOS DE NEGOCIO:

    public void agregarItem(ItemMenu item) {
        item.setVendedor(this); // Le asignamos al itemMenu agregado el respectivo vendedor que lo agregó.
        this.itemsMenu.add(item);
    }

    public double distancia(Cliente cliente) {
        final double R = 6371.0088; // Radio de la tierra en kilómetros.

        // Convertimos las latitudes y longitudes de grados a radianes.
        double lat1Rad = Math.toRadians(this.coordenadas.getLat());
        double lon1Rad = Math.toRadians(this.coordenadas.getLng());
        double lat2Rad = Math.toRadians(cliente.getCoordenadas().getLat());
        double lon2Rad = Math.toRadians(cliente.getCoordenadas().getLng());

        double dlon = lon2Rad - lon1Rad;
        double dlat = lat2Rad - lat1Rad;

        // Aplicamos la fórmula de Haversine:
        double a = Math.sin(dlat / 2) * Math.sin(dlat / 2) + Math.cos(lat1Rad) * Math.cos(lat2Rad) * Math.sin(dlon / 2) * Math.sin(dlon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        // Obtenemos la distancia en kilómetros:
        return R * c;
    }

    public ArrayList<ItemMenu> getListaBebidas() {
        ArrayList<ItemMenu> listaBebidas = new ArrayList<>();

        for (ItemMenu itemActual : this.itemsMenu) {
            if (itemActual.esBebida()) {
                listaBebidas.add(itemActual);
            }
        }

        return listaBebidas;
    }

    public ArrayList<ItemMenu> getListaComidas() {
        ArrayList<ItemMenu> listaComidas = new ArrayList<>();

        for (ItemMenu itemActual : this.itemsMenu) {
            if (itemActual.esComida()) {
                listaComidas.add(itemActual);
            }
        }

        return listaComidas;
    }

    public ArrayList<ItemMenu> getListaComidasVegetarianas() {
        ArrayList<ItemMenu> listaComidasVegetarianas = new ArrayList<>();

        for (ItemMenu itemActual : this.itemsMenu) {
            if (itemActual.esComida() && itemActual.aptoVegetariano()) {
                listaComidasVegetarianas.add(itemActual);
            }
        }

        return listaComidasVegetarianas;
    }

    public ArrayList<ItemMenu> getListaBebidasSinAlcohol() {
        ArrayList<ItemMenu> listaBebidasSinAlcohol = new ArrayList<>();

        for (ItemMenu itemActual : this.itemsMenu) {
            if (itemActual.esBebida() && ((Bebida) itemActual).getGraduacionAlcoholica() == 0) {
                listaBebidasSinAlcohol.add(itemActual);
            }
        }

        return listaBebidasSinAlcohol;
    }
}
