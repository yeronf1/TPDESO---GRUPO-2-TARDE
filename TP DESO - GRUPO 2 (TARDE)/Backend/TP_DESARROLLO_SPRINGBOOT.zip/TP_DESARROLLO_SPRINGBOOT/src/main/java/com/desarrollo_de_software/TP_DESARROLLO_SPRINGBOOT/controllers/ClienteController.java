package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.controllers;

import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.NoSuchElementException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.ClienteDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services.GestorDeClientes;

@RestController
@RequestMapping("/cliente")
public class ClienteController {

    private final GestorDeClientes gestorDeClientes;

    @Autowired
    public ClienteController(GestorDeClientes gestorDeClientes) {
        this.gestorDeClientes = gestorDeClientes;
    }

    @PostMapping("/registrar")
    public ResponseEntity<Map<String, String>> registrarCliente(@RequestBody ClienteDTO clienteDTO) {

        Map<String, String> response = new HashMap<>();

        try {

            gestorDeClientes.registrarCliente(clienteDTO);

            response.put("message", "Cliente registrado exitosamente.");
            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor."); // Por ejemplo, si no se conectó bien el front con el back.
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/buscar")
    public ResponseEntity<Map<String, Object>> buscarCliente(@RequestBody ClienteDTO clienteDTO) {

        Map<String, Object> response = new HashMap<>();

        try {
            // Obtenemos los clientes que coinciden con los filtros (si no hay filtros ingresados, se muestran todos los clientes de la base de datos):
            List<ClienteDTO> clientes = gestorDeClientes.buscarCliente(clienteDTO);

            // Obtenemos el total de clientes en la base de datos.
            long totalClientes = gestorDeClientes.contarTotalClientes();

            if (clientes.isEmpty()) {
                response.put("message", "No se encontraron clientes que coincidan con los filtros especificados.");
                response.put("totalResultados", totalClientes); // Incluimos el total de clientes aunque no haya resultados.
                return ResponseEntity.ok(response);
            }

            response.put("message", "Clientes encontrados exitosamente.");
            response.put("data", clientes);
            response.put("totalResultados", totalClientes); // Incluimos el total de clientes.

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @DeleteMapping("/eliminar")
    public ResponseEntity<Map<String, Object>> eliminarCliente(@RequestBody ClienteDTO clienteDTO) {

        Map<String, Object> response = new HashMap<>();

        try {

            gestorDeClientes.eliminarCliente(clienteDTO);

            response.put("message", "Cliente eliminado exitosamente.");
            return ResponseEntity.ok(response);

        } catch (NoSuchElementException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PutMapping("/modificar")
    public ResponseEntity<Map<String, Object>> modificarCliente(@RequestBody ClienteDTO clienteDTO) {

        Map<String, Object> response = new HashMap<>();

        try {

            gestorDeClientes.modificarCliente(clienteDTO);

            response.put("message", "Cliente modificado exitosamente.");
            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException | NoSuchElementException ex) { // Capturamos errores de validación con el mensaje específico según tipo de error:
            response.put("message", ex.getMessage());
            return ResponseEntity.badRequest().body(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/obtenerClientes") // Ruta específica para obtener la lista entera de los clientes en la base de datos (para mostrar en la lista desplegable).
    public ResponseEntity<Map<String, Object>> obtenerIDClientes() {

        Map<String, Object> response = new HashMap<>();

        try {

            List<ClienteDTO> clientes = gestorDeClientes.obtenerClientes();

            if (clientes.isEmpty()) {
                response.put("message", "No se encontraron clientes.");
                return ResponseEntity.ok(response);
            }

            response.put("message", "Clientes encontradas exitosamente.");
            response.put("data", clientes);
            return ResponseEntity.ok(response);

        } catch (Exception ex) { // Manejo de otros errores genéricos:
            ex.printStackTrace();
            response.put("message", "Error interno en el servidor.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

}