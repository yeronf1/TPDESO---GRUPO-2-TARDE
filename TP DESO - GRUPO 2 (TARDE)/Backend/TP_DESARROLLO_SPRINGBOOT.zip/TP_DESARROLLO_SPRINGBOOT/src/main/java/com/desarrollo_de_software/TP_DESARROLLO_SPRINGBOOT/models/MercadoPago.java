package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models;

import java.time.LocalDateTime;
import jakarta.persistence.Entity;
import jakarta.persistence.DiscriminatorValue;

@Entity
@DiscriminatorValue("MercadoPago")
public class MercadoPago extends Pago {

    private String alias;

    // GETTERS Y SETTERS:

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    // CONSTRUCTORES:

    public MercadoPago() {
        super();
    }

    public MercadoPago(int id, String alias) {
        super(id);
        this.alias = alias;
    }

    public MercadoPago(int id, LocalDateTime fechaPago, String alias) {
        super(id, fechaPago);
        this.alias = alias;
    }

    // METODOS DE CONSIGNA:

    @Override
    public double calcularRecargo(double total) {
        return total * 1.04; // Le aplicamos el 4% de recargo.
    }
}
