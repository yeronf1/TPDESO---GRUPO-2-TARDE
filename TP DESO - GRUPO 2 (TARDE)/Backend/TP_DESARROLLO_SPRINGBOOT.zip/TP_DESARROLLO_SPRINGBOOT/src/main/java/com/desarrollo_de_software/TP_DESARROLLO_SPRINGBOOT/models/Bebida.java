package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

@Entity
public class Bebida extends ItemMenu {

    @Column(name = "graduacion_alcoholica")
    private double graduacionAlcoholica;

    @Column(name = "es_gaseosa")
    private boolean esGaseosa;

    @Column(name = "volumen")
    private double volumen; // Volumen en ML.

    // GETTERS Y SETTERS:

    public double getGraduacionAlcoholica() {
        return graduacionAlcoholica;
    }

    public void setGraduacionAlcoholica(double graduacionAlcoholica) {
        this.graduacionAlcoholica = graduacionAlcoholica;
    }

    public boolean getEsGaseosa() {
        return esGaseosa;
    }

    public void setEsGaseosa(boolean esGaseosa) {
        this.esGaseosa = esGaseosa;
    }

    public double getVolumen() {
        return volumen;
    }

    public void setVolumen(double volumen) {
        this.volumen = volumen;
    }

    // CONSTRUCTORES:

    public Bebida() {
    }

    public Bebida(double graduacionAlcoholica, boolean esGaseosa, double volumen) {
        this.graduacionAlcoholica = graduacionAlcoholica;
        this.esGaseosa = esGaseosa;
        this.volumen = volumen;
    }

    public Bebida(int id_item_menu, Vendedor vendedor, String nombre, String descripcion, double precio, Categoria categoria, double graduacionAlcoholica, boolean esGaseosa, double volumen) {
        super(id_item_menu, vendedor, nombre, descripcion, precio, categoria);
        this.graduacionAlcoholica = graduacionAlcoholica;
        this.esGaseosa = esGaseosa;
        this.volumen = volumen;
    }

    // MÉTODOS DE CONSIGNA:

    @Override
    public double peso() {
        double peso = volumen;

        if (graduacionAlcoholica > 0) {
            peso *= 0.99;
        } else if (esGaseosa) {
            peso *= 1.04;
        }

        peso *= 1.2;

        BigDecimal bd = new BigDecimal(peso);
        bd = bd.setScale(2, RoundingMode.HALF_UP);

        return bd.doubleValue();
    }

    @Override
    public boolean esComida() {
        return false;
    }

    @Override
    public boolean esBebida() {
        return true;
    }

    @Override
    public boolean aptoVegetariano() {
        return true;
    }
}