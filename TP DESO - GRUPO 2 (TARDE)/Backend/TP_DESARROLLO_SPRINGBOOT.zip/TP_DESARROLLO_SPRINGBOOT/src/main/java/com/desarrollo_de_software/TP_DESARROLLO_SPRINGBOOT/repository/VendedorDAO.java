package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository;

import java.util.List;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Vendedor;

public interface VendedorDAO {

    Vendedor save (Vendedor vendedor);
    void actualizarVendedor(Vendedor vendedor);
    List<Vendedor> buscarPorFiltros(int id_vendedor, String nombre, String direccion);
    long totalVendedoresEnBD();
    Vendedor findById(int id);
    void deleteById(int id);
    List<Vendedor> findAll();

}
