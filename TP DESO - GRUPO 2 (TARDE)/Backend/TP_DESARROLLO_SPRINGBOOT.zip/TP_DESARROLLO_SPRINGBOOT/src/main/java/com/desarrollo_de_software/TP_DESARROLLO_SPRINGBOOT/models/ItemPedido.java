package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models;

import jakarta.persistence.*;

@Entity
@Table(name = "items_pedidos")
public class ItemPedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_item_pedido;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_pedido", nullable = false)
    private Pedido pedido;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_item_menu", nullable = false)
    private ItemMenu itemMenu;

    // Agregamos un atributo que permita contabilizar la cantidad de cada ítem menú elegido.
    @Column
    private int cantidad;

    // GETTERS Y SETTERS:

    public int getId_item_pedido() {
        return id_item_pedido;
    }

    public void setId_item_pedido(int id_item_pedido) {
        this.id_item_pedido = id_item_pedido;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public ItemMenu getItemMenu() {
        return itemMenu;
    }

    public void setItemMenu(ItemMenu itemMenu) {
        this.itemMenu = itemMenu;
    }

    public int getCantidad() {return cantidad;}

    public void setCantidad(int cantidad) {this.cantidad = cantidad;}

    // CONSTRUCTORES:

    public ItemPedido() {
    }

    public ItemPedido(int id_item_pedido, Pedido pedido, ItemMenu itemMenu) {
        this.id_item_pedido = id_item_pedido;
        this.pedido = pedido;
        this.itemMenu = itemMenu;
    }
}
