package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services;

import java.util.*;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.exceptions.EmailExistenteException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.ClienteDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Cliente;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.Coordenada;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.ClienteDAO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services.validationServices.ValidadorRegistro;

@Service
public class GestorDeClientes {

    private final ClienteDAO clienteDAO;
    private final ValidadorRegistro validadorRegistro;

    @Autowired
    public GestorDeClientes(ClienteDAO clienteDAO, ValidadorRegistro validadorRegistro) {
        this.clienteDAO = clienteDAO;
        this.validadorRegistro = validadorRegistro;
    }

    // Metodo para registrar un nuevo cliente en la base de datos:
    public void registrarCliente(ClienteDTO clienteDTO) {

        // Encapsulamos la lógica de validación de datos de entrada dentro del mismo metodo de registro de cliente:
        try {
            validadorRegistro.validarCliente(clienteDTO);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(e.getMessage());
        }

        // Creamos la entidad y le asignamos los respectivos datos:
        Cliente cliente = new Cliente();

        cliente.setNombre(clienteDTO.getNombre());
        cliente.setCuit(clienteDTO.getCuit());
        cliente.setEmail(clienteDTO.getCorreo_electronico());
        cliente.setDireccion(clienteDTO.getDireccion());

        Coordenada coordenadaAleatoria = generarCoordenadaAleatoria();
        cliente.setCoordenadas(coordenadaAleatoria);

        try {
            clienteDAO.save(cliente);
        } catch (DataIntegrityViolationException e) {
            throw new EmailExistenteException("Ya existe un cliente asociado a ese email o CUIT. Intente de nuevo.");
        }
    }

    // Lo ideal sería realizar una integración que permita, a raíz de una dirección, asociar las respectivas coordenadas mediante Google Maps.
    // Como eso no se puede hacer, realizamos un metodo que permite asignar coordenadas aleatorias dentro del rango de Argentina:
    private Coordenada generarCoordenadaAleatoria() {
        Random random = new Random();

        // Rango aproximado para latitud y longitud en Argentina:
        double latMin = -55.0;
        double latMax = -21.0;
        double lngMin = -74.0;
        double lngMax = -53.0;

        double lat = latMin + (latMax - latMin) * random.nextDouble();
        double lng = lngMin + (lngMax - lngMin) * random.nextDouble();

        // Redondeamos a 2 decimales:
        lat = Double.parseDouble(String.format(Locale.US, "%.3f", lat));
        lng = Double.parseDouble(String.format(Locale.US, "%.3f", lng));

        return new Coordenada(lat, lng);
    }

    // Metodo usado para buscar los clientes que coincidan con los filtros de búsqueda ingresados:
    public List<ClienteDTO> buscarCliente(ClienteDTO clienteDTO) {

        List<Cliente> clientesEncontrados = clienteDAO.buscarPorFiltros(clienteDTO.getId_cliente(),clienteDTO.getNombre(),clienteDTO.getCuit(),
                                                                        clienteDTO.getCorreo_electronico(),clienteDTO.getDireccion());

        // Convertimos todas las entidades de clientes encontradas a DTOs para trasnferirlos a la capa de presentación:
        List<ClienteDTO> clienteDTOs = new ArrayList<>();

        for (Cliente cliente : clientesEncontrados) {
            ClienteDTO clienteDTOEncontrado = new ClienteDTO();
            clienteDTOEncontrado.setId_cliente(cliente.getId_cliente());
            clienteDTOEncontrado.setNombre(cliente.getNombre());
            clienteDTOEncontrado.setCuit(cliente.getCuit());
            clienteDTOEncontrado.setCorreo_electronico(cliente.getEmail());
            clienteDTOEncontrado.setDireccion(cliente.getDireccion());

            Coordenada coordenadas = new Coordenada();
            coordenadas.setLat(cliente.getCoordenadas().getLat());
            coordenadas.setLng(cliente.getCoordenadas().getLng());
            clienteDTOEncontrado.setCoordenadas(coordenadas);

            clienteDTOs.add(clienteDTOEncontrado);
        }

        return clienteDTOs;

    }

    // Metodo para contar el total de clientes en la base de datos (para poder mostrar en la interfaz: 'X clientes encontrados de Y totales').
    public long contarTotalClientes() {
        return clienteDAO.totalClientesEnBD();
    }

    public Cliente obtenerClientePorID(int id_cliente){
        return clienteDAO.findById(id_cliente);
    }

    // Metodo para realizar la eliminación FÍSICA de un cliente:
    public void eliminarCliente(ClienteDTO clienteDTO) {

        try{
            clienteDAO.deleteById(clienteDTO.getId_cliente());
        } catch (NoSuchElementException ex){
            throw new NoSuchElementException(ex.getMessage());
        }

    }

    // Metodo para modificar los datos de un cliente exsistente en la base de datos:
    public void modificarCliente(ClienteDTO clienteDTO) {

        try {
            // Validamos los datos del cliente
            validadorRegistro.validarCliente(clienteDTO);

            // Buscamos el cliente en la base de datos por su ID
            Cliente cliente = clienteDAO.findById(clienteDTO.getId_cliente());

            if (cliente == null) {
                throw new NoSuchElementException("No se encontró un cliente con el ID: " + clienteDTO.getId_cliente());
            }

            // Actualizamos los datos del cliente
            cliente.setNombre(clienteDTO.getNombre());
            cliente.setCuit(clienteDTO.getCuit());
            cliente.setEmail(clienteDTO.getCorreo_electronico());
            cliente.setDireccion(clienteDTO.getDireccion());

            // Persistimos los cambios
            clienteDAO.actualizarCliente(cliente);

        } catch (IllegalArgumentException e) {
            // Excepción para datos no válidos
            throw new IllegalArgumentException(e.getMessage(), e);
        } catch (NoSuchElementException e) {
            // Excepción si el cliente no existe
            throw new NoSuchElementException(e.getMessage(), e);
        }
    }

    // Metodo para obtener todos los clientes de la base de datos y poder mostrarlos en la interfaz de usuario para seleccionar:
    public List<ClienteDTO> obtenerClientes() {

        // Recuperamos de la base de datos todas las entidades de clientes que existan:
        List<Cliente> clientes = clienteDAO.findAll();

        // Convertimos las entidades en DTOs para transferirlas a la capa de presentación:
        List<ClienteDTO> clienteDTOS = new ArrayList<>();

        for (Cliente cliente : clientes) {
            ClienteDTO clienteDTO = new ClienteDTO();
            clienteDTO.setId_cliente(cliente.getId_cliente());
            clienteDTO.setNombre(cliente.getNombre());
            clienteDTOS.add(clienteDTO);
        }

        return clienteDTOS;
    }

}