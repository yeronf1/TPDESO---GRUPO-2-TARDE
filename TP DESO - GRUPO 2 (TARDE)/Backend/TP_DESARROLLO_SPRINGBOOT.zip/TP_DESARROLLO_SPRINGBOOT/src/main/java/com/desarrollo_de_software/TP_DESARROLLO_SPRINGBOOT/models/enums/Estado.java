package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums;

public enum Estado {
    EN_PROCESO, RECIBIDO, EN_ENVIO, ENTREGADO
}
