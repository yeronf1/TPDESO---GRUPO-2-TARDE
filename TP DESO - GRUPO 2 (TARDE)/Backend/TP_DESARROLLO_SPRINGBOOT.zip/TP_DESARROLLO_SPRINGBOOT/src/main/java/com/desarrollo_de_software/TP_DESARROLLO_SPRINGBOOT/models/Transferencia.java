package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@DiscriminatorValue("Transferencia")
public class Transferencia extends Pago {

    private String cuit;
    private String cbu;

    // GETTERS Y SETTERS:

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public String getCbu() {
        return cbu;
    }

    public void setCbu(String cbu) {
        this.cbu = cbu;
    }

    // CONSTRUCTORES:

    public Transferencia() {
        super();
    }

    public Transferencia(String cuit, String cbu) {
        this.cuit = cuit;
        this.cbu = cbu;
    }

    public Transferencia(int id, String cuit, String cbu) {
        super(id);
        this.cuit = cuit;
        this.cbu = cbu;
    }

    public Transferencia(int id, LocalDateTime fechaPago, String cuit, String cbu) {
        super(id, fechaPago);
        this.cuit = cuit;
        this.cbu = cbu;
    }

    // MÉTODOS DE CONSIGNA:

    @Override
    public double calcularRecargo(double total){
        return total * 1.02; // Le aplicamos el 2% de recargo.
    }

}