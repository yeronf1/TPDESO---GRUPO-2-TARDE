package com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services;

import java.util.List;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.stream.Collectors;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.NoSuchElementException;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.*;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.models.enums.Estado;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.PedidoDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.ItemMenuDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.DTOs.ItemPedidoDTO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.repository.PedidoDAO;
import com.desarrollo_de_software.TP_DESARROLLO_SPRINGBOOT.services.validationServices.ValidadorRegistro;

@Service
public class GestorDePedidos {

    private final GestorDeClientes gestorDeClientes;
    private final GestorDeItemsMenu gestorDeItemsMenu;
    private final PedidoDAO pedidoDAO;
    private final ValidadorRegistro validadorRegistro;


    @Autowired
    public GestorDePedidos(GestorDeClientes gestorDeClientes, PedidoDAO pedidoDAO, ValidadorRegistro validadorRegistro, GestorDeItemsMenu gestorDeItemsMenu){
        this.gestorDeClientes = gestorDeClientes;
        this.pedidoDAO = pedidoDAO;
        this.validadorRegistro = validadorRegistro;
        this.gestorDeItemsMenu = gestorDeItemsMenu;
    }

    public void registrarPedido(PedidoDTO pedidoDTO) {

         try {
            validadorRegistro.validarPedido(pedidoDTO);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(e.getMessage());
        }

        Cliente cliente = gestorDeClientes.obtenerClientePorID(pedidoDTO.getIdCliente());
        Pedido pedido = new Pedido(pedidoDTO.getIdPedido(), cliente);

        String tipoPago = pedidoDTO.getFormaPago();

        if ("TRANSFERENCIA".equalsIgnoreCase(tipoPago)) {
            Transferencia transferencia = new Transferencia();
            transferencia.setCbu(pedidoDTO.getCbu());
            transferencia.setCuit(pedidoDTO.getCuit());

            pedido.setFormaDePago(transferencia); // JPA se encarga de persistir el pago en la tabla 'pagos' una vez que persiste el pedido.

        } else if ("MERCADO_PAGO".equalsIgnoreCase(tipoPago)) {
            MercadoPago mercadoPago = new MercadoPago();
            mercadoPago.setAlias(pedidoDTO.getAlias());

            pedido.setFormaDePago(mercadoPago); // JPA se encarga de persistir el pago en la tabla 'pagos' una vez que persiste el pedido.

        } else {
            throw new IllegalArgumentException("Elija una forma de pago.");
        }

        // Convertimos el detalle del pedido a DTO:
        List<ItemPedido> items = pedidoDTO.getDetalle().stream().map(itemDTO -> {
            ItemPedido item = new ItemPedido();

            ItemMenu itemMenu = gestorDeItemsMenu.obtenerItemMenuPorID(itemDTO.getIdItemMenu());
            if (itemMenu == null) {
                throw new IllegalArgumentException("No se encontró el ItemMenu con ID: " + itemDTO.getIdItemMenu());
            }

            item.setItemMenu(itemMenu);
            item.setCantidad(itemDTO.getCantidad());
            item.setPedido(pedido);
            return item;
        }).collect(Collectors.toList());

        double totalSinRecargo = items.stream()
                .mapToDouble(item -> (item.getItemMenu().getPrecio() * item.getCantidad()))
                .sum();

        pedido.setTotal(totalSinRecargo);
        double totalConRecargo = pedido.calcularTotal();
        pedido.setTotal(totalConRecargo);

        pedido.setEstadoPedido(Estado.RECIBIDO); // Elegida la forma de pago del producto (y, presuntamente pagado), seteamos su estado a recibido.
        pedido.setPedidosDetalle(items);
        pedidoDAO.save(pedido);

    }

    public List<PedidoDTO> buscarPedidos(PedidoDTO filtros) {

        List<Pedido> pedidos = pedidoDAO.buscarPorFiltros(
                filtros.getIdPedido(),
                filtros.getNombreCliente(),
                filtros.getEstadoPedido(),
                filtros.getIdVendedor()
        );

        return pedidos.stream()
                .map(this::convertirAPedidoDTO)
                .collect(Collectors.toList());
    }

    // Metodo para contar el total de pedidos en la base de datos (para poder mostrar en la interfaz: 'X pedidos encontrados de Y totales').
    public long contarTotalPedidos() {
        return pedidoDAO.totalPedidosEnBD();
    }

    private PedidoDTO convertirAPedidoDTO(Pedido pedido) {
        PedidoDTO dto = new PedidoDTO();
        dto.setIdPedido(pedido.getId_pedido());
        dto.setIdCliente(pedido.getCliente().getId_cliente());
        dto.setNombreCliente(pedido.getCliente().getNombre());

        if (pedido.getFormaDePago() != null) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy - HH:mm:ss");
            dto.setFechaPago(LocalDate.from(LocalDateTime.parse(pedido.getFormaDePago().getFechaPago(), formatter)));
        }

        dto.setTotal(pedido.getTotal());
        dto.setEstadoPedido(pedido.getEstadoPedido());
        dto.setDetalle(
                pedido.getPedidosDetalle().stream()
                        .map(this::convertirAItemPedidoDTO)
                        .collect(Collectors.toList())
        );
        return dto;
    }

    private ItemPedidoDTO convertirAItemPedidoDTO(ItemPedido itemPedido) {
        ItemPedidoDTO dto = new ItemPedidoDTO();

        dto.setIdItemPedido(itemPedido.getId_item_pedido());
        dto.setIdPedido(itemPedido.getPedido().getId_pedido());
        dto.setCantidad(itemPedido.getCantidad());

        ItemMenu itemMenu = itemPedido.getItemMenu();
        if (itemMenu != null) {
            ItemMenuDTO itemMenuDTO = new ItemMenuDTO();

            itemMenuDTO.setId_item_menu(itemMenu.getId_item_menu());
            itemMenuDTO.setNombre(itemMenu.getNombre());
            itemMenuDTO.setPrecio(itemMenu.getPrecio());
            itemMenuDTO.setId_vendedor(itemMenu.getVendedor().getId_vendedor());

            if (itemMenu instanceof Plato) {
                Plato plato = (Plato) itemMenu;
                itemMenuDTO.setPeso(plato.getPeso());
                itemMenuDTO.setCalorias(plato.getCalorias());
                itemMenuDTO.setAptoCeliaco(plato.getAptoCeliaco());
                itemMenuDTO.setAptoVegetariano(plato.getAptoVegetariano());
            } else if (itemMenu instanceof Bebida) {
                Bebida bebida = (Bebida) itemMenu;
                itemMenuDTO.setGraduacionAlcoholica(bebida.getGraduacionAlcoholica());
                itemMenuDTO.setEs_gaseosa(bebida.getEsGaseosa());
                itemMenuDTO.setVolumen(bebida.getVolumen());
            }

            dto.setItemMenuDTO(itemMenuDTO);
        }

        return dto;
    }

    // Metodo para realizar la eliminación FÍSICA de un pedido:
    public void eliminarPedido(PedidoDTO pedidoDTO) {
        try{
            pedidoDAO.deleteById(pedidoDTO.getIdPedido());
        } catch (NoSuchElementException ex){
            throw new NoSuchElementException(ex.getMessage());
        }
    }

    // Metodo para actualizar el estado de un pedido a EN_ENVIO:
    public void actualizarEstadoPedido(PedidoDTO pedidoDTO) {

        try {

            // Buscamos el pedido en la base de datos por su ID:
            Pedido pedido = pedidoDAO.findById(pedidoDTO.getIdPedido());

            if (pedido == null) {
                throw new NoSuchElementException("No se encontró un pedido con el ID: " + pedidoDTO.getIdPedido());
            }

            // Actualizamos el estado del pedido a EN_ENVIO:
            pedido.cambiarEstadoPedido();

            // Persistimos los cambios:
            pedidoDAO.actualizarPedido(pedido);

        } catch (IllegalArgumentException e) {
            // Excepción para datos no válidos
            throw new IllegalArgumentException(e.getMessage(), e);
        } catch (NoSuchElementException e) {
            // Excepción si el cliente no existe
            throw new NoSuchElementException(e.getMessage(), e);
        }

    }

    // Metodo para obtener la lista entera de los ítems asociados a un pedido en la base de datos (para mostrar en la lista desplegable).
    @Transactional
    public List<ItemPedidoDTO> verDetallePedido(PedidoDTO pedidoDTO) {

        // Recuperamos de la base de datos todas las entidades de items pedidos que existan:
        List<ItemPedido> itemsPorPedido = pedidoDAO.findAllItemsPorPedido(pedidoDTO.getIdPedido());

        // Convertimos todas las entidades de items pedidos encontradas a DTOs para trasnferirlos a la capa de presentación:
        List<ItemPedidoDTO> itemPedidoDTOS = new ArrayList<>();

        for (ItemPedido itemPedido : itemsPorPedido) {
            ItemPedidoDTO itemDTOEncontrado = new ItemPedidoDTO();

            itemDTOEncontrado.setIdItemPedido(itemPedido.getId_item_pedido());
            itemDTOEncontrado.setIdItemMenu(itemPedido.getItemMenu().getId_item_menu());
            itemDTOEncontrado.setNombre(itemPedido.getItemMenu().getNombre());
            itemDTOEncontrado.setPrecio(itemPedido.getItemMenu().getPrecio());
            itemDTOEncontrado.setCantidad(itemPedido.getCantidad());

            itemPedidoDTOS.add(itemDTOEncontrado);
        }

        return itemPedidoDTOS;
    }

}