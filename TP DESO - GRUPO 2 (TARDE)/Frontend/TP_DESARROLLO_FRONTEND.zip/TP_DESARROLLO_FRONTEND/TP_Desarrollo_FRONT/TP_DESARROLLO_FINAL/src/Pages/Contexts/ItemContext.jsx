import React, { createContext, useState } from 'react';

// Crear el contexto
export const ItemContext = createContext();

// Proveedor del contexto
export const ItemProvider = ({ children }) => {
    const [ItemSeleccionado, setItemSeleccionado] = useState(null);

    return (
        <ItemContext.Provider value={{ ItemSeleccionado, setItemSeleccionado }}>
            {children}
        </ItemContext.Provider>
    );
};