import React, {useContext, useState} from 'react';
import '/src/Pages/Cliente/ModificarCliente.css';
import {useNavigate} from "react-router-dom";
import {Header} from "../../Componentes/Header/Header.jsx";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faQuestionCircle} from "@fortawesome/free-regular-svg-icons";
import Modal from "react-modal";
import {ClienteContext} from "../Contexts/ClienteContext.jsx";

function ModificarCliente() {

    const navigate = useNavigate();
    const [error, setError] = useState(null);
    const [isOpen, setIsOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const {ClienteSeleccionado} = useContext(ClienteContext);

    // Variables del FORM

    //const [id_cliente, setId_cliente] = useState(ClienteSeleccionado.id_cliente);
    const [nombre, setNombre] = useState(ClienteSeleccionado.nombre);
    const [direccion, setDireccion] = useState(ClienteSeleccionado.direccion);
    const [correoElectronico, setCorreoElectronico] = useState(ClienteSeleccionado.correo_electronico);
    const [cuit, setCuit] = useState(ClienteSeleccionado.cuit);


    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('http://localhost:8080/cliente/modificar', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_cliente: ClienteSeleccionado.id_cliente,
                    nombre: nombre,
                    direccion: direccion,
                    correo_electronico: correoElectronico,
                    cuit: cuit,
                })
            });

            const data = await response.json(); // Lee la respuesta como JSON.

            if (!response.ok) {
                setError(data.message || 'Hubo un problema al comunicarse con el servidor');
                return;
            }

            setError(null);
            setSuccessMessage(data.message);
            setIsOpen(true); // Abre el modal.

            setTimeout(() => {
                setSuccessMessage('');
                setIsOpen(false);
                navigate("/BuscarCliente")
            }, 3000);

        } catch (error) {
            console.error("Error al verificar el client:", error);
            setError('Error de conexión con el servidor');
        }
    };


    const handleCancelClick = () => {
        setIsConfirmOpen(true); // Abre el modal de confirmación.
    };

    const handleConfirmCancel = () => {
        setIsConfirmOpen(false);
        navigate('/BuscarCliente'); // Redirige a la Busqueda de Vendedores.
    };

    const handleCancelClose = () => {
        setIsConfirmOpen(false); // Cierra el modal de confirmación.
    };

    const handleCloseModal = () => {
        setIsOpen(false);
    };


    return (
        <div className="padreMC">
            <Header />

            <div className="tarjetaTituloMC">
                <h2>MODIFICAR CLIENTE</h2>
            </div>

            <div className='contenedorFormularioMC'>

                <form className={"formRegBedelMC"} onSubmit={handleSubmit}>

                    <div className="formularioMC">

                        <div className={"tituloIdMC"}>
                            <h3>
                                {ClienteSeleccionado.nombre}{" - ID: "}{ClienteSeleccionado.id_cliente}
                            </h3>
                            <div className="line"></div>
                        </div>

                        <div className="hijoFormMC">
                            <div className={'fila1MC'}>

                                <div className="contenedorInputMC">
                                    <input
                                        className="inputFieldMC"
                                        type="text"
                                        placeholder='Nombre'
                                        value={nombre}
                                        onChange={(e) => setNombre(e.target.value)}
                                    />
                                </div>

                                <div className="contenedorInputMC">
                                    <input
                                        className="inputFieldMC"
                                        type="text"
                                        placeholder='CUIT'
                                        value={cuit}
                                        onChange={(e) => setCuit(e.target.value)}
                                    />
                                </div>

                            </div>

                            <div className={'fila2MC'}>

                                <div className="contenedorInputMC">
                                    <input
                                        className="inputFieldMC"
                                        type="text"
                                        placeholder='Email'
                                        value={correoElectronico}
                                        onChange={(e) => setCorreoElectronico(e.target.value)}
                                    />
                                </div>

                                <div className="contenedorInputMC">
                                    <input
                                        className="inputFieldMC"
                                        type="text"
                                        placeholder='Direccion'
                                        value={direccion}
                                        onChange={(e) => setDireccion(e.target.value)}
                                    />
                                </div>

                            </div>


                        </div>

                        <div className='MensajeErrorMC'>
                            {error && (
                                <div style={{color: '#E01414', display: 'flex', alignItems: 'center'}}>
                                    <FontAwesomeIcon icon={faQuestionCircle}
                                                     style={{color: '#E01414', marginRight: '8px'}}/>
                                    <h3>{error}</h3>
                                </div>
                            )}
                        </div>

                    </div>

                    <div className='btnFormMC'>
                        <button className="cancelarMC" type='button' onClick={handleCancelClick}>Cancelar</button>
                        <button className="guardarMC" type='submit'>Guardar</button>
                    </div>

                </form>

                {/* Modal de éxito */}
                <Modal isOpen={isOpen}
                       onRequestClose={handleCloseModal}
                       ariaHideApp={false}
                       overlayClassName="modal-overlayMC"
                       className="modal-contentMC"
                >
                    <p className={"successMessage"}>{successMessage}</p>

                </Modal>

                {/* Modal de confirmación de cancelación */}
                <Modal isOpen={isConfirmOpen}
                       onRequestClose={handleCancelClose}
                       ariaHideApp={false}
                       overlayClassName="modal-overlayMC"
                       className="modal-contentRB"
                >

                    <p>¿Seguro de que deseas cancelar?</p>

                    <div className={"btnCancelarMC"}>
                        <button className={"botonSiMC"} onClick={handleConfirmCancel}>Sí</button>
                        <button className={"botonNoMC"} onClick={handleCancelClose}>No</button>
                    </div>

                </Modal>
            </div>
        </div>
    );
}

export {ModificarCliente}