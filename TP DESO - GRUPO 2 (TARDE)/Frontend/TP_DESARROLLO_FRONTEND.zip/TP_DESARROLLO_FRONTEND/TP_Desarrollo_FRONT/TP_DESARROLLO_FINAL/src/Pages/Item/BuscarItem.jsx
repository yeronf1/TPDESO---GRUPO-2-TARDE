
import './BuscarItem.css';
import { Header } from "../../Componentes/Header/Header.jsx";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import Modal from "react-modal";
import {ItemContext} from "../Contexts/ItemContext.jsx";
import "../../Componentes/Tabla/Tabla.css"

const BuscarItem = () => {
    const navigate = useNavigate();
    const [idItem, setIdItem] = useState('');
    const [nombre, setNombre] = useState('');
    const [cat, setCat] = useState('');
    const [tipo_item, setTipo_item] = useState('COMIDA');
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading]= useState(false);
    const [filteredDatos, setFilteredDatos]= useState([]);
    const [isOpen, setIsOpen] = useState(false);
    const [successMessage, setSuccessMessage]= useState('');
    const { ItemSeleccionado, setItemSeleccionado } = useContext(ItemContext);
    const [selectedItemID, setSelectedItemID]= useState(null);
    const [abrirConfirmacion, setAbrirConfirmacion] = useState(false);
    const [categorias, setCategorias]= useState([]);
    const [vendedores, setVendedores]= useState ([]);
    const [vend, setVend]=useState();


    // Llama a la API cuando los filtros cambien.
    useEffect(() => {
        fetchFilteredItem();
    }, [idItem, nombre, tipo_item, cat, vend]);


    // Función para obtener item según nombre y turno.
    const fetchFilteredItem = async () => {
        setIsLoading(true); // Indica que los datos están siendo cargados
        setError(null); // Resetea cualquier mensaje de error previo

        try {
            const response = await fetch('http://localhost:8080/item_menu/buscar', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_item_menu: idItem,
                    nombre: nombre,
                    id_vendedor: vend,
                    id_categoria: cat,
                    tipo_item_menu: tipo_item

                })
            });

            if (!response.ok) throw new Error("Error al obtener los Items");

            const data = await response.json();

            if (data.data && Array.isArray(data.data)) {
                setFilteredDatos(data.data);
            }
            else {
                setFilteredDatos([]);
            }
        } catch (err) {
            console.error(err);
            setError("No se pudieron cargar los datos.");
            setFilteredDatos([]);
        } finally {
            setIsLoading(false);
        }
    };

    const fetchListaVendedores = async () => {
        try {
            const response = await fetch('http://localhost:8080/vendedor/obtenerVendedores', {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' },
            });

            if (!response.ok) throw new Error("Error al cargar los vendedores");

            const data = await response.json();

            console.log("Datos de vendedores:", data);
            setVendedores(data.data);

        } catch (err) {
            console.error("Error:", err);
        }
    };

    useEffect(() => {  // PARA ENCONTRAR TODOS LOS VENDEDORES
        fetchListaVendedores();
    }, []);

    const fetchListaCategorias = async () => {
        try {
            const response = await fetch('http://localhost:8080/item_menu/obtenerCategorias', {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' },
            });

            if (!response.ok) throw new Error("Error al cargar los vendedores");

            const data = await response.json();

            console.log("Datos de Categorias:", data);
            setCategorias(data.data);

        } catch (err) {
            console.error("Error:", err);
        }
    };

    useEffect(() => {  // PARA ENCONTRAR TODOS LOS VENDEDORES
        fetchListaCategorias();
    },[]);

    const deleteItem = async (idItem) => {
        setAbrirConfirmacion(false);
        setIsLoading(true);
        setIsOpen(true);

        try {
            const response = await fetch('http://localhost:8080/item_menu/eliminar', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_item_menu: idItem
                }),
            });

            if (!response.ok) throw new Error("Error al eliminar el item");

            setSuccessMessage("Item eliminado con éxito.");
        } catch (err) {
            console.error(err);
            setSuccessMessage("No se pudo eliminar el item.");
        }finally {
            setIsLoading(false);
            setIsOpen(true);
            setTimeout(() => {
                setIsOpen(false); // Cierra automáticamente después de 3 segundos
                setSuccessMessage('');
                fetchFilteredItem(); // Recarga los datos tras la operación
            }, 3000);

        }
    };

    console.log(ItemSeleccionado);


    const updateItem = (item) => {
        setItemSeleccionado(item);
        navigate(`/ModificarItem`);
    };


    const handleConfirmOpen = (idItem, event) => {
        event.preventDefault(); // Prevenir el comportamiento por defecto
        setSelectedItemID(idItem);
        setAbrirConfirmacion(true); // Abre el modal de confirmación
    };

    const handleConfirmClose = () => {
        setAbrirConfirmacion(false); // Cierra el modal de confirmación
    };


    const handleConfirmCancel = () => {
        navigate('/');
    };

    const handleTipoItemChange = (e) => {
        const selectedValue = e.target.value;
        setTipo_item(selectedValue === "" ? undefined : selectedValue);
    };

    return (
        <div className={"padreItem"}>
            <Header/>

            <div className="tarjetaTituloItem">
                <h2>BUSCAR ÍTEM</h2>
            </div>

            <form className={"formBusItem"}>
                <div className="bntCrearYFiltrosItem">


                    <div className="filtrosItem">
                        <div className="ContInputItem">
                            <input
                                className="inputItemID"
                                type="text"
                                placeholder='ID ítem'
                                value={idItem}
                                onChange={(e) => setIdItem(e.target.value)}
                            />
                        </div>

                        <div className="ContInputItem">
                            <input
                                className="inputItemNombre"
                                type="text"
                                placeholder='Nombre ítem'
                                value={nombre}
                                onChange={(e) => setNombre(e.target.value)}
                            />
                        </div>

                        <div className="ContInputItem">
                            <select className="inputCategoria" value={cat}
                                    onChange={(e) => setCat(e.target.value)}>
                                <option value="">Seleccionar categoría</option>
                                {categorias.map((categoria) => (
                                    <option key={categoria.id_categoria} value={categoria.id_categoria}>
                                        {categoria.nombre_categoria}
                                    </option>
                                ))}
                            </select>
                        </div>


                        <div className="ContInputItem">
                            <select
                                className="inputTipoItem"
                                value={tipo_item ?? ""}
                                onChange={handleTipoItemChange}
                            >
                                <option value="0">Comida</option>
                                <option value="1">Bebida</option>
                            </select>
                        </div>


                        <div className="ContInputItem">
                            <select className="inputTipoItem" value={vend}
                                    onChange={(e) => setVend(e.target.value)}>
                                <option value="">Seleccionar vendedor</option>
                                {vendedores.map((vendedor) => (
                                    <option key={vendedor.id_vendedor} value={vendedor.id_vendedor}>
                                        {vendedor.nombre}
                                    </option>
                                ))}
                            </select>
                        </div>

                    </div>
                    <div className={"ErrorItem"}>

                        <div className='MensajeErrorItem'>
                            {error && (
                                <div style={{color: '#E01414', display: 'flex', alignItems: 'center'}}>
                                <FontAwesomeIcon icon="question-circle"
                                                     style={{color: '#E01414', marginRight: '8px'}}/>
                                    <h3>{error}</h3>
                                </div>
                            )}
                        </div>
                    </div>

                </div>

                <div className={"padreContenedorTabla"}>

                    <div className={'contenedorTablaItem'} style={{maxHeight: '300px', overflowY: 'auto'}}>

                        <table>
                            <thead>
                            <tr className={"nombreColumnas"}>
                                <th className={"tablaID"}>ID</th>
                                <th>Nombre</th>
                                <th>Categoría</th>
                                <th>Descripción</th>
                                <th>Precio ($)</th>
                                <th>Grad. Alc. (%)</th>
                                <th>Volumen (ML)</th>
                                <th>Calorías (cal)</th>
                                <th>Peso (grs)</th>
                                <th>Apto vegano</th>
                                <th>Apto celíaco</th>
                                <th>Gaseosa</th>
                                <th className={"tdButtonsItem"}></th>
                                <th className={"tdButtonsItem"}></th>
                            </tr>
                            </thead>

                            <tbody>
                            {filteredDatos.length > 0 ? (
                                filteredDatos
                                    .slice() // Creamos una copia para evitar modificar el array original
                                    .sort((a, b) => a.id_item_menu - b.id_item_menu) // Ordenamos por idPedido en orden ascendente
                                    .map((item) => (
                                    <tr className={"filasItems"} key={item.id_item_menu}>
                                        <td className={"tablaID"}>{item.id_item_menu}</td>
                                        <td>{item.nombre}</td>
                                        <td>{item.nombreCategoria}</td>
                                        <td>{item.descripcion}</td>
                                        <td>{item.precio}</td>
                                        <td>{item.graduacionAlcoholica}</td>
                                        <td>{item.volumen}</td>
                                        <td>{item.calorias}</td>
                                        <td>{item.peso}</td>
                                        <td>{item.aptoCeliaco ? "Sí" : "No"}</td>
                                        <td>{item.aptoVegetariano ? "Sí" : "No"}</td>
                                        <td>{item.es_gaseosa ? "Sí" : "No"}</td>


                                        <td className="tdButtonsItem">
                                            <button type={"button"} className="modificarItem"
                                                    onClick={() => updateItem(item)}>
                                                Modificar
                                            </button>

                                        </td>
                                        <td className="tdButtonsItem">
                                            <button className="eliminarItem"
                                                    onClick={(event) => handleConfirmOpen(item.id_item_menu, event)}>Eliminar
                                            </button>
                                        </td>

                                    </tr>

                                ))
                            ) : (
                                <tr>
                                    <td colSpan="5" style={{textAlign: "center"}}>No hay resultados para la
                                        búsqueda
                                    </td>
                                </tr>
                            )}
                            </tbody>


                        </table>
                    </div>

                </div>

                <div className='btnFormItem'>
                    <button className="cancelarItem" type='button' onClick={handleConfirmCancel}>Cancelar</button>
                </div>

            </form>

            {/* Modal de mensajes */}
            <Modal
                isOpen={isOpen}
                onRequestClose={() => setIsOpen(false)}
                ariaHideApp={false}
                overlayClassName="modal-overlayItem"
                className="modal-contentItem"

            >
                {isLoading ? (
                    <p className={"loadingMessage"}>Cargando...</p>
                ) : (
                    <p className={"successMessage"}>{successMessage}</p>
                )}
            </Modal>

            {/*Modal de confirmación*/}
            <Modal
                isOpen={abrirConfirmacion}
                onRequestClose={handleConfirmClose} // Cierre manual
                ariaHideApp={false}
                overlayClassName="modal-overlayItem"
                className="modal-contentItem"

            >
                <p>¿Seguro de que deseas eliminar este Item?</p>
                <div className={"btnEliminarItem"}>
                    <button className={"botonSiItem"} onClick={() => deleteItem(selectedItemID)}>Sí</button>
                    <button className={"botonNoItem"} onClick={handleConfirmClose}>No</button>
                </div>
            </Modal>


        </div>
    )
        ;
};

export {BuscarItem};