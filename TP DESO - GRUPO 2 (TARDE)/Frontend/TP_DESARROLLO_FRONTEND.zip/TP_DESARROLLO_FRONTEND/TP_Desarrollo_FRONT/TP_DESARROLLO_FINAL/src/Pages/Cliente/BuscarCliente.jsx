
import './BuscarCliente.css';
import { Header } from "../../Componentes/Header/Header.jsx";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import Modal from "react-modal";
import {ClienteContext} from "../Contexts/ClienteContext.jsx";
import "../../Componentes/Tabla/Tabla.css"


const BuscarCliente = () => {
    const navigate = useNavigate();
    const [idCliente, setIdCliente] = useState('');
    const [nombre, setNombre] = useState('');
    const [direccion, setDireccion]= useState('');
    const [correoElectronico, setCorreoElectronico]= useState('');
    const [cuit, setCuit]= useState('');
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading]= useState(false);
    const [filteredDatos, setFilteredDatos]= useState([]);
    const [isOpen, setIsOpen] = useState(false);
    const [successMessage, setSuccessMessage]= useState('');
    const { ClienteSeleccionado, setClienteSeleccionado } = useContext(ClienteContext);
    const [selectedClienteID, setSelectedClienteID]= useState(null);
    const [abrirConfirmacion, setAbrirConfirmacion] = useState(false);


    //conexión base de datos

    // Llama a la API cuando los filtros cambien.
    useEffect(() => {
        fetchFilteredClientes();
    }, [idCliente, nombre, direccion, correoElectronico, cuit]);


    // Función para obtener clientes según nombre y turno.
    const fetchFilteredClientes = async () => {
        setIsLoading(true); // Indica que los datos están siendo cargados
        setError(null); // Resetea cualquier mensaje de error previo

        try {
            const response = await fetch('http://localhost:8080/cliente/buscar', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_cliente: idCliente,
                    nombre: nombre,
                    direccion: direccion,
                    correo_electronico: correoElectronico,
                    cuit: cuit
                })
            });

            if (!response.ok) throw new Error("Error al obtener los clientes");

            const data = await response.json();

            if (data.data && Array.isArray(data.data)) {
                setFilteredDatos(data.data);

            } else {
                setFilteredDatos([]);
            }
        } catch (err) {
            console.error(err);
            setError("No se pudieron cargar los datos.");
            setFilteredDatos([]);
        } finally {
            setIsLoading(false);
        }
    };

    const deleteCliente = async (idCliente) => {
        setAbrirConfirmacion(false);
        setIsLoading(true);
        setIsOpen(true);

        try {
            const response = await fetch('http://localhost:8080/cliente/eliminar', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_cliente: idCliente // Enviar el nombre de usuario en el cuerpo de la solicitud
                }),
            });

            if (!response.ok) throw new Error("Error al eliminar el Cliente");

            setSuccessMessage("cliente eliminado con éxito.");
        } catch (err) {
            console.error(err);
            setSuccessMessage("No se pudo eliminar el cliente.");
        }finally {
            setIsLoading(false);
            setIsOpen(true);
            setTimeout(() => {
                setIsOpen(false); // Cierra automáticamente después de 3 segundos
                setSuccessMessage('');
                fetchFilteredClientes(); // Recarga los datos tras la operación
            }, 3000);

        }
    };


    const updateCliente = (cliente) => {
        setClienteSeleccionado(cliente);
        navigate(`/ModificarCliente`);
    };



    const handleConfirmOpen = (idCliente, event) => {
        event.preventDefault(); // Prevenir el comportamiento por defecto
        setSelectedClienteID(idCliente);
        setAbrirConfirmacion(true); // Abre el modal de confirmación
    };

    const handleConfirmClose = () => {
        setAbrirConfirmacion(false); // Cierra el modal de confirmación
    };


    const handleConfirmCancel = () => {
        navigate('/');
    };
    return (
        <div className={"padreCliente"}>
            <Header/>

            <div className="tarjetaTituloCliente">
                <h2>BUSCAR CLIENTE</h2>
            </div>

            <form className={"formBusCliente"}>
                <div className="bntCrearYFiltrosCliente">


                    <div className="filtrosCliente">
                        <div className="ContInputCliente">
                            <input
                                className="inputClienteID"
                                type="text"
                                placeholder='ID cliente'
                                value={idCliente}
                                onChange={(e) => setIdCliente(e.target.value)}
                            />
                        </div>

                        <div className="ContInputCliente">
                            <input
                                className="inputClienteNombre"
                                type="text"
                                placeholder='Nombre cliente'
                                value={nombre}
                                onChange={(e) => setNombre(e.target.value)}
                            />
                        </div>

                        <div className="ContInputCliente">
                            <input
                                className="inputClienteDir"
                                type="text"
                                placeholder='Dirección cliente'
                                value={direccion}
                                onChange={(e) => setDireccion(e.target.value)}
                            />
                        </div>

                        <div className="ContInputCliente">
                            <input
                                className="inputClienteCorreo"
                                type="text"
                                placeholder='Correo electrónico cliente'
                                value={correoElectronico}
                                onChange={(e) => setCorreoElectronico(e.target.value)}
                            />
                        </div>

                        <div className="ContInputCliente">
                            <input
                                className="inputClienteCuit"
                                type="text"
                                placeholder='CUIT cliente'
                                value={cuit}
                                onChange={(e) => setCuit(e.target.value)}
                            />
                        </div>

                    </div>

                    <div className={"crearYError"}>
                        <div className="crearCliente">
                            <button className="btnCrearCliente"
                                    onClick={(e) => navigate('/CrearCliente')}
                            >Crear
                            </button>
                        </div>

                        <div className='MensajeErrorCliente'>
                        {error && (
                                <div style={{color: '#E01414', display: 'flex', alignItems: 'center'}}>
                                    <FontAwesomeIcon icon="question-circle"
                                                     style={{color: '#E01414', marginRight: '8px'}}/>
                                    <h3>{error}</h3>
                                </div>
                            )}
                        </div>
                    </div>


                </div>

                <div className={"padreContenedorTablaCliente"}>
                    <div className={'contenedorTablaCliente'} style={{maxHeight: '300px', overflowY: 'auto'}}>

                        <table>
                            <thead>
                            <tr className={"nombreColumnas"}>
                                <th>{"ID"}</th>
                                <th>{"Nombre"}</th>
                                <th>{"Dirección"}</th>
                                <th>{"Email"}</th>
                                <th>{"CUIT"}</th>
                                <th></th>
                                <th></th>
                            </tr>
                            </thead>

                            <tbody>
                            {filteredDatos.length > 0 ? (
                                filteredDatos.map((cliente) => (
                                    <tr key={cliente.id_cliente}>
                                        <td>{cliente.id_cliente}</td>
                                        <td>{cliente.nombre}</td>
                                        <td>{cliente.direccion}</td>
                                        <td>{cliente.correo_electronico}</td>
                                        <td>{cliente.cuit}</td>

                                        <td className="tdButtons">
                                            <button type={"button"} className="modificarCliente"
                                                    onClick={() => updateCliente(cliente)}>
                                                Modificar
                                            </button>

                                        </td>
                                        <td>
                                            <button className="eliminarCliente"
                                                    onClick={(event) => handleConfirmOpen(cliente.id_cliente, event)}>Eliminar
                                            </button>
                                        </td>
                                    </tr>

                                ))
                            ) : (
                                <tr>
                                    <td colSpan="5" style={{textAlign: "center"}}>No hay resultados para la búsqueda.
                                    </td>
                                </tr>
                            )}
                            </tbody>

                        </table>
                    </div>
                </div>

                <div className='btnFormCliente'>
                    <button className="cancelarCliente" type='button' onClick={handleConfirmCancel}>Cancelar</button>
                </div>

            </form>

            {/* Modal de mensajes */}
            <Modal
                isOpen={isOpen}
                onRequestClose={() => setIsOpen(false)}
                ariaHideApp={false}
                overlayClassName="modal-overlayCliente"
                className="modal-contentCliente"

            >
                {isLoading ? (
                    <p className={"loadingMessage"}>Cargando...</p>
                ) : (
                    <p className={"successMessage"}>{successMessage}</p>
                )}
            </Modal>

            {/*Modal de confirmación*/}
            <Modal
                isOpen={abrirConfirmacion}
                onRequestClose={handleConfirmClose} // Cierre manual
                ariaHideApp={false}
                overlayClassName="modal-overlayCliente"
                className="modal-contentCliente"

            >
                <p>¿Seguro de que deseas eliminar este ?</p>
                <div className={"btnEliminarCliente"}>
                    <button className={"botonSiCliente"} onClick={() => deleteCliente(selectedClienteID)}>Sí</button>
                    <button className={"botonNoCliente"} onClick={handleConfirmClose}>No</button>
                </div>
            </Modal>


        </div>
    )
        ;
};

export {BuscarCliente};
