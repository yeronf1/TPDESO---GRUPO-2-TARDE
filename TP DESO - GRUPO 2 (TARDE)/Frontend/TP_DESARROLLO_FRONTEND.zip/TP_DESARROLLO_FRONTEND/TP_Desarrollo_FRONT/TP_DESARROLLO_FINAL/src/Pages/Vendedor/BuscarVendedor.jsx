import '/src/Pages/Vendedor/BuscarVendedor.css';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import Modal from "react-modal";
import { VendedorContext } from "../Contexts/VendedorContext.jsx";
import {Header} from "../../Componentes/Header/Header.jsx"
import "../../Componentes/Tabla/Tabla.css"

const BuscarVendedor = () => {
    const navigate = useNavigate();

    // Estados
    const [idVendedor, setIdVendedor] = useState('');
    const [nombre, setNombre] = useState('');
    const [direccion, setDireccion] = useState('');
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [filteredDatos, setFilteredDatos] = useState([]);
    const [isOpen, setIsOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const { setVendedorSeleccionado } = useContext(VendedorContext);
    const [selectedVendedorID, setSelectedVendedorID] = useState(null);
    const [abrirConfirmacion, setAbrirConfirmacion] = useState(false);

    // Llama a la API cuando los filtros cambian
    useEffect(() => {
        fetchFilteredVendedores();
    }, [nombre, direccion, idVendedor]);

    // Función para obtener vendedores según filtros
    const fetchFilteredVendedores = async () => {
        setIsLoading(true);
        setError(null);

        try {
            const response = await fetch('http://localhost:8080/vendedor/buscar', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_vendedor: idVendedor,
                    nombre: nombre,
                    direccion: direccion
                })
            });

            if (!response.ok) throw new Error("Error al obtener los vendedores");

            const data = await response.json();
            setFilteredDatos(Array.isArray(data.data) ? data.data : []);
        } catch (err) {
            console.error(err);
            setError("No se pudieron cargar los datos.");
            setFilteredDatos([]);
        } finally {
            setIsLoading(false);
        }
    };

    // Función para eliminar un vendedor
    const deleteVendedor = async (id_Vendedor) => {
        setAbrirConfirmacion(false);
        setIsLoading(true);

        try {
            const response = await fetch('http://localhost:8080/vendedor/eliminar', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_vendedor: id_Vendedor})
            });

            if (!response.ok) throw new Error("Error al eliminar el vendedor");

            setSuccessMessage("Vendedor eliminado con éxito.");
        } catch (err) {
            console.error(err);
            setSuccessMessage("No se pudo eliminar el vendedor.");
        } finally {
            setIsLoading(false);
            setIsOpen(true);
            setTimeout(() => {
                setIsOpen(false);
                setSuccessMessage('');
                fetchFilteredVendedores();
            }, 3000);
        }
    };

    // Función para actualizar un vendedor
    const updateVendedor = (vendedor) => {
        setVendedorSeleccionado(vendedor);
        navigate(`/ModificarVendedor`);
    };

    // Funciones para crear un item o pedido
    const crearItem = (vendedor) => {
        setVendedorSeleccionado(vendedor);
        navigate(`/CrearItem`);
    };

    const crearPedido = (vendedor) => {
        setVendedorSeleccionado(vendedor);
        navigate(`/CrearPedido`);
    };

    // Función para abrir el modal de confirmación
    const handleConfirmOpen = (id) => {
        setSelectedVendedorID(id);
        setAbrirConfirmacion(true);
    };

    const handleConfirmClose = () => {
        setAbrirConfirmacion(false);
    };

    const handleConfirmCancel = () => {
        navigate('/');
    };

    return (
        <div className="padreVendedor">
            <Header />

            <div className="tarjetaTituloVendedor">
                <h2>BUSCAR VENDEDOR</h2>
            </div>

            <form className="formBusVendedor">
                <div className="bntCrearYFiltros">
                    <div className="filtrosVendedor">
                        <div className={"contenedorInputVendedor"}>
                            <input
                                className="inputVendedorID"
                                type="text"
                                placeholder="ID vendedor"
                                value={idVendedor}
                                onChange={(e) => setIdVendedor(e.target.value)}
                            />
                        </div>

                        <div className={"contenedorInputVendedor"}>
                            <input
                                className="inputVendedorNombre"
                                type="text"
                                placeholder="Nombre vendedor"
                                value={nombre}
                                onChange={(e) => setNombre(e.target.value)}
                            />
                        </div>

                        <div className={"contenedorInputVendedor"}>
                            <input
                                className="inputVendedorDir"
                                type="text"
                                placeholder="Dirección vendedor"
                                value={direccion}
                                onChange={(e) => setDireccion(e.target.value)}
                            />
                        </div>
                    </div>
                    <div className={"crearYErrorVendedor"}>
                        <div className="crearVendedor">
                            <button className="btnCrearVendedor"
                                    onClick={(e) => navigate('/CrearVendedor')}
                            >Crear
                            </button>
                        </div>

                        <div className='MensajeErrorVendedor'>
                            {error && (
                                <div style={{color: '#E01414', display: 'flex', alignItems: 'center'}}>
                                    <FontAwesomeIcon icon="question-circle"
                                                     style={{color: '#E01414', marginRight: '8px'}}/>
                                    <h3>{error}</h3>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                <div className={"padreContenedorTablaVendedor"}>
                    <div className="contenedorTablaVendedor" style={{maxHeight: '300px', overflowY: 'auto'}}>
                        <table>
                            <thead>
                            <tr className="nombreColumnas">
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Dirección</th>
                                <th>Coordenadas</th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            {filteredDatos.length > 0 ? (
                                filteredDatos.map((vendedor) => (
                                    <tr key={vendedor.id_vendedor}>
                                        <td>{vendedor.id_vendedor}</td>
                                        <td>{vendedor.nombre}</td>
                                        <td>{vendedor.direccion}</td>
                                        <td>{vendedor.coordenadas ? `Lat: ${vendedor.coordenadas.lat}, Lng: ${vendedor.coordenadas.lng}` : 'Sin Coordenadas'}</td>
                                        <td>
                                            <button className={"modificarVendedor"} type={"button"} onClick={() => updateVendedor(vendedor)}>Modificar
                                            </button>

                                        </td>
                                        <td>
                                            <button className={"eliminarVendedor"} type={"button"}
                                                    onClick={() => handleConfirmOpen(vendedor.id_vendedor)}>Eliminar
                                            </button>
                                        </td>
                                        <td>
                                            <button className={"crearPedido"} type={"button"} onClick={() => crearPedido(vendedor)}>Crear pedido
                                            </button>
                                        </td>
                                        <td>
                                            <button className={"crearItem"} type={"button"} onClick={() => crearItem(vendedor)}>Crear ítem
                                            </button>

                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan="6" style={{textAlign: 'center'}}>No hay resultados para la búsqueda.
                                    </td>
                                </tr>
                            )}
                            </tbody>
                        </table>
                    </div>

                </div>
                <div className={"btnFormCliente"}>
                    <button className="cancelarVendedor" type="button" onClick={handleConfirmCancel}>
                        Cancelar
                    </button>
                </div>

            </form>

            {/* Modal de mensajes */}
            <Modal isOpen={isOpen} ariaHideApp={false} overlayClassName="modal-overlayVendedor"
                   className="modal-contentVendedor">
                {isLoading ? <p>Cargando...</p> : <p>{successMessage}</p>}
            </Modal>

            {/* Modal de confirmación */}
            <Modal isOpen={abrirConfirmacion} ariaHideApp={false} overlayClassName="modal-overlayVendedor"
                   className="modal-contentVendedor">
                <p>¿Seguro de que deseas eliminar este vendedor?</p>
                <div className={"btnEliminarVendedor"}>
                    <button className={"botonSiVendedor"} type={"button"} onClick={(e) => deleteVendedor(selectedVendedorID)}>Sí</button>
                    <button className={"botonNoVendedor"} onClick={handleConfirmClose}>No</button>
                </div>
            </Modal>
        </div>
    );
};

export {BuscarVendedor};
