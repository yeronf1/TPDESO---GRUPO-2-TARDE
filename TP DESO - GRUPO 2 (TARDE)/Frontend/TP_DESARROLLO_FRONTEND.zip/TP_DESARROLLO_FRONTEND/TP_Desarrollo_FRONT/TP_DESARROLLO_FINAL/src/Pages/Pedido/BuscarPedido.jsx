
import './BuscarPedido.css';
import { Header } from "../../Componentes/Header/Header.jsx";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import Modal from "react-modal";
import {PedidoContext} from "../Contexts/PedidoContext.jsx";
import "../../Componentes/Tabla/Tabla.css"


const BuscarPedido = () => {
    const navigate = useNavigate();
    const [idPedido, setIdPedido] = useState('');
    const [nombreVendedor, setNombreVendedor] = useState('');
    const [nombreCliente, setNombreCliente] = useState('');
    const [vendedores, setVendedores]=useState([
        { id_vendedor: 1, nombre: 'Juan Pérez' },
        { id_vendedor: 2, nombre: 'Ana Gómez' },
        { id_vendedor: 3, nombre: 'Carlos Rodríguez' },
        { id_vendedor: 4, nombre: 'María Fernández' },
        { id_vendedor: 5, nombre: 'Pedro Sánchez' }
    ]
);
    const [vendedor, setVendedor]=useState(null);
    const [estado, setEstado]= useState();
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading]= useState(false);
    const [filteredDatos, setFilteredDatos]= useState([]);
    const [isOpen, setIsOpen] = useState(false);
    const [successMessage, setSuccessMessage]= useState('');
    const { PedidoSeleccionado, setPedidoSeleccionado } = useContext(PedidoContext);
    const [selectedPedidoID, setSelectedPedidoID]= useState(null);
    const [abrirConfirmacion, setAbrirConfirmacion] = useState(false);
    const [abrirConfirmacionEstado, setAbrirConfirmacionEstado] = useState(false);
    const [selectedPedidoEstado, setSelectedPedidoEstado]=useState('');


        //conexión base de datos



    const fetchListaVendedores = async () => {
        try {
            const response = await fetch('http://localhost:8080/vendedor/obtenerVendedores', {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' },
            });

            if (!response.ok) throw new Error("Error al cargar los vendedores");

            const data = await response.json();

            console.log("Datos de vendedores:", data);
            setVendedores(data.data);

        } catch (err) {
            console.error("Error:", err);
        }
    };

    useEffect(() => {  // PARA ENCONTRAR TODOS LOS VENDEDORES
        fetchListaVendedores();
    }, []);

    // Función para obtener pedidos según nombre y turno.
    const fetchFilteredPedidos = async () => {
        setIsLoading(true); // Indica que los datos están siendo cargados
        setError(null); // Resetea cualquier mensaje de error previo

        try {
            const response = await fetch('http://localhost:8080/pedido/buscar', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    idPedido: idPedido,
                    idVendedor: vendedor,
                    nombreCliente: nombreCliente,
                    estadoPedido: estado

                })
            });

            if (!response.ok) throw new Error("Error al obtener los pedidos");

            const data = await response.json();

            if (data.data && Array.isArray(data.data)) {
                setFilteredDatos(data.data);

            } else {
                setFilteredDatos([]);
            }
        } catch (err) {
            console.error(err);
            setError("No se pudieron cargar los datos.");
            setFilteredDatos([]);
        } finally {
            setIsLoading(false);
        }
    };

    // Llama a la API cuando los filtros cambien.
    useEffect(() => {
        fetchFilteredPedidos();
    }, [ nombreCliente, idPedido, estado, vendedor]);

    const cambiarEstadoPedidoBD = async (e, estado) => {
        e.preventDefault();
        setAbrirConfirmacionEstado(false); // Cierra el modal de confirmación
        setIsLoading(true); // Activa el estado de carga
        setIsOpen(true); // Abre el modal

        try {
            const response = await fetch('http://localhost:8080/pedido/actualizarEstado', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    idPedido: selectedPedidoID,

                }),
            });

            const data = await response.json();

            if (!response.ok) {
                setSuccessMessage(data.message || 'Hubo un problema al comunicarse con el servidor');
                return;
            }

            setSuccessMessage(null);
            setSuccessMessage(data.message || 'Estado cambiado exitosamente.');
        } catch (error) {
            console.error("Error al cambiar el estado del pedido:", error);
            setError('Error de conexión con el servidor');
        } finally {
            setIsLoading(false); // Desactiva el estado de carga
            setTimeout(() => {
                setIsOpen(false); // Cierra el modal automáticamente después de 3 segundos
                setSuccessMessage('');
                fetchFilteredPedidos(); // Recarga los datos tras la operación
            }, 3000);
        }
    };


    const deletePedidos = async (idPedido) => {
        setAbrirConfirmacion(false);
        setIsLoading(true);
        setIsOpen(true);

        try {
            const response = await fetch('http://localhost:8080/pedido/eliminar', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    idPedido: idPedido // Enviar el nombre de usuario en el cuerpo de la solicitud
                }),
            });

            if (!response.ok) throw new Error("Error al eliminar el pedido");

            setSuccessMessage("pedido eliminado con éxito.");
        } catch (err) {
            console.error(err);
            setSuccessMessage("No se pudo eliminar el pedido.");
        }finally {
            setIsLoading(false);
            setIsOpen(true);
            setTimeout(() => {
                setIsOpen(false); // Cierra automáticamente después de 3 segundos
                setSuccessMessage('');
                fetchFilteredPedidos(); // Recarga los datos tras la operación
            }, 3000);

        }
    };


    const verDetallePedido = (idPedido) => {
        setPedidoSeleccionado(idPedido);
        navigate(`/ModificarPedido`);
    };



    const handleConfirmOpen = (idPedido, event) => {
        event.preventDefault(); // Prevenir el comportamiento por defecto
        setSelectedPedidoID(idPedido);
        setAbrirConfirmacion(true); // Abre el modal de confirmación
    };

    const cambiarEstado = (estadoPedido, idPedido, event) => {
        event.preventDefault();
        setSelectedPedidoID(idPedido);
        setSelectedPedidoEstado(estadoPedido);
        setAbrirConfirmacionEstado(true);
    };


    const cerrarCambiarEstado = () => {
        setAbrirConfirmacionEstado(false); // Cierra el modal de confirmación
    };

    const handleConfirmClose = () => {
        setAbrirConfirmacion(false);
        setAbrirConfirmacionEstado(false);// Cierra el modal de confirmación
    };

    const handleTipoItemChange = (e) => {
        const selectedValue = e.target.value;
        setEstado(selectedValue === "" ? undefined : selectedValue);
    };

    const handleConfirmCancel = () => {
        navigate('/');
    };
    return (
        <div className={"padrePedido"}>
            <Header/>

            <div className="tarjetaTituloPedido">
                <h2>BUSCAR PEDIDO</h2>
            </div>

            <form className={"formBusPedidos"}>
                <div className="errorYFiltrosPedidos">


                    <div className="filtrosPedidos">
                        <div className="ContInputPedido">
                            <input
                                className="inputPedidosID"
                                type="text"
                                placeholder='ID pedido'
                                value={idPedido}
                                onChange={(e) => setIdPedido(e.target.value)}
                            />
                        </div>

                        <div className="ContInputPedido">
                            <input
                                className="inputPedidoNombre"
                                type="text"
                                placeholder='Nombre cliente'
                                value={nombreCliente}
                                onChange={(e) => setNombreCliente(e.target.value)}
                            />
                        </div>


                        <div className="ContInputItem">
                            <select
                                className="inputTipoItem"
                                value={vendedor}
                                onChange={(e) => setVendedor(e.target.value)}
                            >
                                <option value="">Seleccionar vendedor</option>
                                {vendedores.map((vendedor) => (
                                    <option key={vendedor.id_vendedor} value={vendedor.id_vendedor}>
                                        {vendedor.nombre}
                                    </option>
                                ))}
                            </select>
                        </div>


                        <div className="ContInputPedido">
                            <select className="inputPedidoEstado" value={estado ?? ""}
                                    onChange={handleTipoItemChange}>
                                <option value="">Seleccionar estado</option>
                                <option value="1">Recibido</option>
                                <option value="2">En envío</option>

                            </select>
                        </div>

                    </div>

                    <div className={"ErrorPedidos"}>

                        <div className='MensajeErrorPedido'>
                            {error && (
                                <div style={{color: '#E01414', display: 'flex', alignItems: 'center'}}>
                                    <FontAwesomeIcon icon="question-circle"
                                                     style={{color: '#E01414', marginRight: '8px'}}/>
                                    <h3>{error}</h3>
                                </div>
                            )}
                        </div>
                    </div>


                </div>

                <div className={"padreContenedorTabla"}>
                    <div className={'contenedorTablaPedidos'} style={{maxHeight: '300px', overflowY: 'auto'}}>

                        <table>
                            <thead>
                            <tr className={"nombreColumnasPedidos"}>
                                <th>ID</th>
                                <th>Cliente</th>
                                <th>Fecha de pago</th>
                                <th>Costo total (+ recargo)</th>
                                <th>Estado</th>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            </thead>

                            <tbody>
                            {filteredDatos.length > 0 ? (
                                filteredDatos
                                    .slice() // Creamos una copia para evitar modificar el array original
                                    .sort((a, b) => a.idPedido - b.idPedido) // Ordenamos por idPedido en orden ascendente
                                    .map((pedido) => (
                                        <tr key={pedido.idPedido}>
                                            <td>{pedido.idPedido}</td>
                                            <td>{pedido.nombreCliente}</td>
                                            <td>{pedido.fechaPago}</td>
                                            <td>{"$" + pedido.total}</td>
                                            <td>{pedido.estadoPedido}</td>

                                            <td className="tdButtons">
                                                <button
                                                    className="cambiarEstadoPedido"
                                                    onClick={(e) => cambiarEstado(pedido.estadoPedido, pedido.idPedido, e)}
                                                >
                                                    Actualizar estado
                                                </button>
                                            </td>

                                            <td>
                                                <button type="button" className="modificarPedidos" onClick={() => verDetallePedido(pedido.idPedido)}>
                                                    Ver detalle
                                                </button>
                                            </td>

                                            <td className="eliminarcont">
                                                <button
                                                    className="eliminarPedido"
                                                    onClick={(event) => handleConfirmOpen(pedido.idPedido, event)}
                                                >
                                                    Eliminar
                                                </button>
                                            </td>
                                        </tr>
                                    ))
                            ) : (
                                <tr>
                                    <td colSpan="5" style={{ textAlign: "center" }}>
                                        No hay resultados para la búsqueda.
                                    </td>
                                </tr>
                            )}

                            </tbody>

                        </table>
                    </div>
                </div>

                <div className='btnFormPedido'>
                    <button className="cancelarPedido" type='button' onClick={handleConfirmCancel}>Cancelar</button>
                </div>

            </form>

            {/* Modal de mensajes */}
            <Modal
                isOpen={isOpen}
                onRequestClose={() => setIsOpen(false)}
                ariaHideApp={false}
                overlayClassName="modal-overlayPedido"
                className="modal-contentPedido"

            >
                {isLoading ? (
                    <p className={"loadingMessage"}>Cargando...</p>
                ) : (
                    <p className={"successMessage"}>{successMessage}</p>
                )}
            </Modal>

            {/*Modal de confirmación*/}
            <Modal
                isOpen={abrirConfirmacion}
                onRequestClose={handleConfirmClose} // Cierre manual
                ariaHideApp={false}
                overlayClassName="modal-overlayPedido"
                className="modal-contentPedido"

            >
                <div className={"contenidoModal"}>
                    <p>¿Seguro de que deseas eliminar este pedido?</p>
                    <div className={"btnEliminarPedido"}>
                        <button
                            className={"botonsiPedido"}
                            onClick={() => deletePedidos(selectedPedidoID)}
                        >
                            Sí
                        </button>


                        <button className={"botonNoPedido"} onClick={handleConfirmClose}>No</button>
                    </div>
                </div>
            </Modal>

            {/*Modal de confirmación Cambio de Estado*/}

            <Modal
                isOpen={abrirConfirmacionEstado}
                onRequestClose={cerrarCambiarEstado}
                ariaHideApp={false}
                overlayClassName="modal-overlayPedido"
                className="modal-contentPedido"
            >
                {selectedPedidoEstado === "EN_ENVIO" ? (
                    <div className={"modalNoCambiarEstado"}>
                        <p>El pedido ya está en estado EN ENVIO, no se puede modificar.</p>
                    </div>
                ) : (
                    <div className={"modalCambiarEstado"}>
                        <p>¿Seguro que desea modificar el estado del pedido a EN ENVÍO?</p>
                        <div className={"btnModificarEstado"}>
                            <button className={"botonsiPedido"}
                                    onClick={(e) => cambiarEstadoPedidoBD(e, "EN_ENVIO")}>
                                Sí
                            </button>
                            <button className={"botonNoPedido"} onClick={cerrarCambiarEstado}>No</button>
                        </div>
                    </div>
                )}
            </Modal>


        </div>
    )
        ;
};

export {BuscarPedido};
