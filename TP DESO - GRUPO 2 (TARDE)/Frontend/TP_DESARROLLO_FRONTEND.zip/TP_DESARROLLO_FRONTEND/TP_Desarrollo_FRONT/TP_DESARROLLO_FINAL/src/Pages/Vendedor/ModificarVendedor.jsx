import React, {useContext, useEffect, useState} from 'react';
import '/src/Pages/Vendedor/ModificarVendedor.css';
import Modal from 'react-modal';
import { useNavigate } from 'react-router-dom';
import {Header} from "../../Componentes/Header/Header.jsx";
import {VendedorContext} from "../Contexts/VendedorContext.jsx";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faQuestionCircle} from "@fortawesome/free-regular-svg-icons";

function ModificarVendedor() {
    const navigate = useNavigate();
    const [error, setError] = useState(null);
    const [isOpen, setIsOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const {VendedorSeleccionado} = useContext(VendedorContext);

    // Variables del FORM

    const [idVendedor, setIdVendedor] = useState(VendedorSeleccionado.id_vendedor);
    const [nombre, setNombre] = useState(VendedorSeleccionado.nombre);
    const [direccion, setDireccion] = useState(VendedorSeleccionado.direccion);


    useEffect(() => {
        if (!VendedorSeleccionado) {
            navigate('/BuscarVendedor');
        }
    }, [VendedorSeleccionado, navigate]);

    if (!VendedorSeleccionado) {
        return null; // Mostrar nada mientras se redirige
    }

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('http://localhost:8080/vendedor/modificar', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_vendedor: idVendedor,
                    nombre: nombre,
                    direccion: direccion,
                }),
            });

            const data = await response.json();

            if (!response.ok) {
                setError(data.message || 'Hubo un problema al comunicarse con el servidor');
                return;
            }

            setError(null);
            setSuccessMessage(data.message);
            setIsOpen(true);

            setTimeout(() => {
                setSuccessMessage('');
                setIsOpen(false);
                navigate("/BuscarVendedor");
            }, 3000);
        } catch (error) {
            console.error("Error al verificar el Vendedor:", error);
            setError('Error de conexión con el servidor');
        }
    };

    //Manejo de ventanas

    const handleCancelClick = () => {
        setIsConfirmOpen(true);
    };

    const handleConfirmCancel = () => {
        setIsConfirmOpen(false);
        navigate('/BuscarVendedor'); // Redirige a la Busqueda de Vendedores.
    };

    const handleCancelClose = () => {
        setIsConfirmOpen(false);
    };

    const handleCloseModal = () => {
        setIsOpen(false);
    }


    return (
        <div className="padreMV">
            <Header />

            <div className="tarjetaTituloMV">
                <h2>MODIFICAR VENDEDOR</h2>
            </div>

            <div className='contenedorFormularioMV'>

                <form className={"formRegBedelMV"} onSubmit={handleSubmit}>

                    <div className="formularioMV">

                        <div className={"tituloIdMV"}>
                            <h3>
                                {VendedorSeleccionado.nombre}{" - ID: "}{VendedorSeleccionado.id_vendedor}
                            </h3>
                            <div className="line"></div>
                        </div>

                        <div className="hijoFormMV">
                            <div className={'fila1MV'}>

                                <div className="contenedorInputMV">
                                    <input
                                        className="inputFieldMV"
                                        type="text"
                                        placeholder='Nombre'
                                        value={nombre}
                                        onChange={(e) => setNombre(e.target.value)}
                                    />
                                </div>

                                <div className="contenedorInputMV">
                                    <input
                                        className="inputFieldMV"
                                        type="text"
                                        placeholder='Direccion'
                                        value={direccion}
                                        onChange={(e) => setDireccion(e.target.value)}
                                    />
                                </div>

                            </div>

                        </div>

                        <div className='MensajeErrorMV'>
                            {error && (
                                <div style={{color: '#E01414', display: 'flex', alignItems: 'center'}}>
                                    <FontAwesomeIcon icon={faQuestionCircle}
                                                     style={{color: '#E01414', marginRight: '8px'}}/>
                                    <h3>{error}</h3>
                                </div>
                            )}
                        </div>

                    </div>

                    <div className='btnFormMV'>
                        <button className="cancelarMV" type='button' onClick={handleCancelClick}>Cancelar</button>
                        <button className="guardarMV" type='submit'>Guardar</button>
                    </div>

                </form>

                {/* Modal de éxito */}
                <Modal isOpen={isOpen}
                       onRequestClose={handleCloseModal}
                       ariaHideApp={false}
                       overlayClassName="modal-overlayMV"
                       className="modal-contentMV"
                >
                    <p className={"successMessage"}>{successMessage}</p>

                </Modal>

                {/* Modal de confirmación de cancelación */}
                <Modal isOpen={isConfirmOpen}
                       onRequestClose={handleCancelClose}
                       ariaHideApp={false}
                       overlayClassName="modal-overlayMV"
                       className="modal-contentMV"
                >

                    <p>¿Seguro de que deseas cancelar?</p>

                    <div className={"btnCancelarMV"}>
                        <button className={"botonSiMV"} onClick={handleConfirmCancel}>Sí</button>
                        <button className={"botonNoMV"} onClick={handleCancelClose}>No</button>
                    </div>

                </Modal>
            </div>
        </div>
    );
}

export {ModificarVendedor}