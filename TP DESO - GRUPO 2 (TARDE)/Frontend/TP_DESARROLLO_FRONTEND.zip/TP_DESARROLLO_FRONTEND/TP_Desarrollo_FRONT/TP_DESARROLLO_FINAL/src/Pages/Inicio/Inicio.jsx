import './Inicio.css'
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
//import { faUser, faChevronDown, faArrowRightFromBracket } from '@fortawesome/free-solid-svg-icons';
import React, { useEffect, useState } from "react";
import Modal from "react-modal";
import { HeaderInicio } from "../../Componentes/Header/HeaderInicio.jsx";


function Inicio() {
    const navigate = useNavigate();
    const [showLogOut, setLogOut] = useState(false);
    const [isOpen, setIsOpen] = useState(false); // Modal de confirmación
    const [username, setUsername] = useState('');

    useEffect(() => {
        // Recuperamos el nombre de usuario desde localStorage:
        const storedUsername = localStorage.getItem('username');
        setUsername(storedUsername || 'Usuario');
    }, []);

    const handleBuscarCliente = () => {
        navigate('/BuscarCliente'); // Redirige a la página de registrar bedel.
    };

    const handleBuscarItems = () => {
        navigate('/BuscarItem'); // Redirige a la página de buscar bedel.
    };

    const handleBuscarPedido = () => {
        navigate('/BuscarPedido'); // Redirige a la página de buscar bedel.
    };

    const handleBuscarVendedor = () => {
        navigate('/BuscarVendedor'); // Redirige a la página de buscar bedel.
    };


    return (
        <div className="padreInicio">
            <HeaderInicio/>
            <div className="tarjetasInicioUNO">
                <div className="cardInicio">
                    <div className="imagenInicio">
                        <img src="/assets/Vendedor.png"/>
                    </div>
                    <div className="botonNavegarInicio">
                        <button className="BtnRegistrarInicio" onClick={handleBuscarVendedor}>Vendedores</button>
                    </div>
                </div>

                <div className="cardInicio">
                    <div className="imagenInicio">
                        <img src="/assets/descarga.png"/>
                    </div>
                    <div className="botonNavegarInicio">
                        <button className="BtnRegistrarInicio" onClick={handleBuscarCliente}>Clientes</button>
                    </div>
                </div>
            </div>

            <div className="tarjetasInicioDOS">
                <div className="cardInicio">
                    <div className="imagenInicio">
                        <img src="/assets/Pedidos.png"/>
                    </div>
                    <div className="botonNavegarInicio">
                        <button className="BtnRegistrarInicio" onClick={handleBuscarPedido}>Pedidos</button>
                    </div>
                </div>

                <div className="cardInicio">
                    <div className="imagenInicio">
                        <img src="/assets/Items.png"/>
                    </div>
                    <div className="botonNavegarInicio">
                        <button className="BtnRegistrarInicio" onClick={handleBuscarItems}>Items</button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export {Inicio};