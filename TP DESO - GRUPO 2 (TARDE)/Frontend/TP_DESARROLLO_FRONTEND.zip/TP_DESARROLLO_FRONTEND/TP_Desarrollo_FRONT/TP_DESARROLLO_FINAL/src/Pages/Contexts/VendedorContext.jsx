import React, { createContext, useState } from 'react';

// Crear el contexto
export const VendedorContext = createContext();

// Proveedor del contexto
export const VendedorProvider = ({ children }) => {
    const [VendedorSeleccionado, setVendedorSeleccionado] = useState(null);

    return (
        <VendedorContext.Provider value={{ VendedorSeleccionado, setVendedorSeleccionado }}>
            {children}
        </VendedorContext.Provider>
    );
};