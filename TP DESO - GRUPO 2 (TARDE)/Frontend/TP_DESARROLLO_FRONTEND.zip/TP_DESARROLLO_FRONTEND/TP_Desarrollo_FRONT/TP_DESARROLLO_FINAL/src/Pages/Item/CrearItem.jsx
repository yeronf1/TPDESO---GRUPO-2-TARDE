import React, {useContext, useEffect, useState} from 'react';
import '/src/Pages/Item/CrearItem.css';
import {useNavigate} from "react-router-dom";
import {VendedorContext} from "../Contexts/VendedorContext.jsx";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faQuestionCircle} from "@fortawesome/free-regular-svg-icons";
import {Header} from "../../Componentes/Header/Header.jsx";
import Modal from "react-modal";

function CrearItem() {
    const navigate = useNavigate();
    const [error, setError] = useState(null);
    const [isOpen, setIsOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const [isLoading, setIsLoading] = useState(false);


    // Variables del Vendedor

    const {VendedorSeleccionado} = useContext(VendedorContext);

    useEffect(() => {
        if (!VendedorSeleccionado) {
            navigate('/BuscarVendedor');
        }
    }, [VendedorSeleccionado, navigate]);

    if (!VendedorSeleccionado) {
        return null; // Mostrar nada mientras se redirige
    }
    let idVendedor = VendedorSeleccionado.id_vendedor
    console.log( VendedorSeleccionado.id_vendedor)

    // Variables del Items

    const [nombre, setNombre] = useState("");
    const [categoria, setCategoria] = useState("");
    const [descripcion, setDescripcion] = useState("");
    const [precio, setPrecio] = useState("");
    const [calorias, setCalorias] = useState("");
    const [peso, setPeso] = useState("");
    const [aptoVegetariano, setAptoVegetariano] = useState(false);
    const [aptoCeliaco, setAptoCeliaco] = useState(false);
    const [gradAlcoholica, setGradAlcoholica] = useState("");
    const [volumen, setVolumen] = useState("");
    const [esGaseosa, setEsGaseosa] = useState(false);
    const [tipoItem, setTipoItem] = useState("COMIDA");
    const [categorias, setCategorias]= useState([]);


    // Enviar el ITEM creado al back

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('http://localhost:8080/item_menu/registrar', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    nombre: nombre,
                    id_categoria: categoria,
                    descripcion: descripcion,
                    precio: precio,
                    calorias: calorias,
                    peso: peso,
                    aptoVegetariano: aptoVegetariano,
                    aptoCeliaco: aptoCeliaco,
                    graduacionAlcoholica: gradAlcoholica,
                    es_gaseosa: esGaseosa,
                    volumen: volumen,
                    id_vendedor: idVendedor,
                    tipo_item_menu: tipoItem
                })
            });
            console.log(`tipoItem ${tipoItem}`)
            console.log(`nombre ${nombre}`);
            console.log(`descripcion ${descripcion}`);
            console.log(`precio ${precio}`);
            console.log(`calorias ${calorias}` );
            console.log(`peso ${peso}` );
            console.log(`aptoCeliaco ${aptoCeliaco}` );
            console.log(`aptoVegetariano ${aptoVegetariano}` );
            console.log(`gradAlcoholica ${gradAlcoholica}` );
            console.log(`esGaseosa ${esGaseosa}` );
            console.log(`volumen ${volumen}`);
            console.log(`idVendedor, ${idVendedor}`);

            const data = await response.json(); // Lee la respuesta como JSON.

            if (!response.ok) {
                setError(data.message || 'Hubo un problema al comunicarse con el servidor');
                return;
            }

            setError(null);
            setSuccessMessage(data.message);
            setIsOpen(true); // Abre el modal.

            setTimeout(() => {
                setSuccessMessage('');
                setIsOpen(false);

            }, 3000);

        } catch (error) {
            console.error("Error al verificar el Item:", error);
            setError('Error de conexión con el servidor');
        }
    };


    const fetchListaCategorias = async () => {
        try {
            const response = await fetch('http://localhost:8080/item_menu/obtenerCategorias', {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' },
            });

            if (!response.ok) throw new Error("Error al cargar los vendedores");

            const data = await response.json();

            console.log("Datos de vendedores:", data);
            setCategorias(data.data);

        } catch (err) {
            console.error("Error:", err);
        }
    };

    useEffect(() => {  // PARA ENCONTRAR TODOS LOS VENDEDORES
        fetchListaCategorias();
    },[]);


    const handleCancelClick = () => {
        setIsConfirmOpen(true); // Abre el modal de confirmación.
    };

    const handleConfirmCancel = () => {
        setIsConfirmOpen(false);
        navigate('/BuscarVendedor'); // Redirige a la Busqueda de Vendedores.
    };

    const handleCancelClose = () => {
        setIsConfirmOpen(false); // Cierra el modal de confirmación.
    };

    const handleCloseModal = () => {
        setIsOpen(false);
    };


    return (
        <div className="padreCI">
            <Header />

            <div className="tarjetaTituloCI">
                <h2>CREAR ITEM</h2>
            </div>

            <div className='contenedorFormularioCI'>

                <form className={"formCI"} onSubmit={handleSubmit}>

                    <div className="formularioCI" style={{maxHeight:'90vw', overflow: 'auto'}} >

                        <div className="hijoFormCI" >

                            <div className={'fila1CI'}>
                                <div className="contenedorInputCI">
                                    <input
                                        className="inputFieldCI"
                                        type="text"
                                        placeholder='Nombre'
                                        value={nombre}
                                        onChange={(e) => setNombre(e.target.value)}
                                    />
                                </div>
                            </div>

                            <div className={'fila1CI'}>

                                <div className="contenedorInputCI">
                                    <select className="inputFieldCI"
                                            value={tipoItem}
                                            onChange={(e) => setTipoItem(e.target.value)}
                                    >
                                        <option value="COMIDA">
                                        Comida
                                        </option>

                                        <option value="BEBIDA">
                                            Bebida
                                        </option>

                                    </select>
                                </div>

                                <div className="contenedorInputCI">
                                    <select className="inputFieldCI" value={categoria}
                                            onChange={(e) => setCategoria(e.target.value)}>
                                        <option value="">Seleccionar categoría</option>
                                        {categorias.map((categoria) => (
                                            <option key={categoria.id_categoria} value={categoria.id_categoria}>
                                                {categoria.nombre_categoria}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                </div>

                                <div className={'fila2CI'}>

                                    <div className="contenedorInputCI">
                                        <input
                                            className="inputFieldCI"
                                            type="text"
                                            placeholder='Descripción'
                                            value={descripcion}
                                            onChange={(e) => setDescripcion(e.target.value)}
                                        />
                                    </div>

                                    <div className="contenedorInputCI">
                                        <input
                                            className="inputFieldCI"
                                            type="text"
                                            placeholder='Precio'
                                            value={precio}
                                            onChange={(e) => setPrecio(e.target.value)}
                                        />
                                    </div>

                                </div>

                                {(tipoItem === "COMIDA") && (
                                    <div>
                                        <div className={'fila2CI'}>

                                            <div className="contenedorInputCI">
                                                <input
                                                    className="inputFieldCI"
                                                    type="text"
                                                    placeholder='Calorías'
                                                    value={calorias}
                                                    onChange={(e) => setCalorias(e.target.value)}
                                                />
                                            </div>

                                            <div className="contenedorInputCI">
                                                <input
                                                    className="inputFieldCI"
                                                    type="text"
                                                    placeholder='Peso'
                                                    value={peso}
                                                    onChange={(e) => setPeso(e.target.value)}
                                                />
                                            </div>

                                        </div>

                                        <div className={'fila2CI'}>

                                            <div className="contenedorInputCI">
                                                <label className={'inputFieldCI'}>
                                                    <input
                                                        type="checkbox"
                                                        checked={aptoVegetariano} // Controla si está seleccionado
                                                        onChange={() => setAptoVegetariano(!aptoVegetariano)} // Maneja el cambio
                                                    />
                                                    Apto vegetariano
                                                </label>
                                            </div>

                                            <div className="contenedorInputCI">
                                                <label className={'inputFieldCI'}>
                                                    <input
                                                        type="checkbox"
                                                        checked={aptoCeliaco} // Controla si está seleccionado
                                                        onChange={() => setAptoCeliaco(!aptoCeliaco)} // Maneja el cambio
                                                    />
                                                    Apto celíaco
                                                </label>
                                            </div>

                                        </div>
                                    </div>
                                )}

                                {(tipoItem === "BEBIDA") && (
                                    <div>
                                        <div className={'fila2CI'}>

                                            <div className="contenedorInputCI">
                                                <input
                                                    className="inputFieldCI"
                                                    type="text"
                                                    placeholder='Graduación Alcohólica (%)'
                                                    value={gradAlcoholica}
                                                    onChange={(e) => setGradAlcoholica(e.target.value)}
                                                />
                                            </div>

                                            <div className="contenedorInputCI">
                                                <input
                                                    className="inputFieldCI"
                                                    type="text"
                                                    placeholder='Volumen'
                                                    value={volumen}
                                                    onChange={(e) => setVolumen(e.target.value)}
                                                />
                                            </div>


                                        </div>

                                        <div className={'fila2CI'}>
                                            <div className="contenedorInputCI">
                                                <label className={'inputFieldCI'}>
                                                    <input
                                                        type="checkbox"
                                                        checked={esGaseosa} // Controla si está seleccionado
                                                        onChange={() => setEsGaseosa(!esGaseosa)} // Maneja el cambio
                                                    />
                                                    Gaseosa
                                                </label>
                                            </div>
                                        </div>

                                    </div>
                                )}


                        </div>

                        <div className='MensajeErrorCI'>
                            {error && (
                                <div style={{color: '#E01414', display: 'flex', alignItems: 'center'}}>
                                    <FontAwesomeIcon icon={faQuestionCircle}
                                                     style={{color: '#E01414', marginRight: '8px'}}/>
                                    <h3>{error}</h3>
                                </div>
                            )}
                        </div>

                    </div>

                    <div className='btnFormCI'>
                    <button className="cancelarCI" type='button' onClick={handleCancelClick}>Cancelar</button>
                        <button className="guardarCI" type='submit'>Guardar</button>
                    </div>

                </form>

                {/* Modal de éxito */}
                <Modal isOpen={isOpen}
                       onRequestClose={handleCloseModal}
                       ariaHideApp={false}
                       overlayClassName="modal-overlay"
                       className="modal-content"
                >
                    <p className={"successMessage"}>{successMessage}</p>

                </Modal>

                {/* Modal de confirmación de cancelación */}
                <Modal isOpen={isConfirmOpen}
                       onRequestClose={handleCancelClose}
                       ariaHideApp={false}
                       overlayClassName="modal-overlayCI"
                       className="modal-contentCI"
                >

                    <p>¿Seguro de que deseas cancelar?</p>

                    <div className={"btnCancelarCI"}>
                        <button className={"botonSiCI"} onClick={handleConfirmCancel}>Sí</button>
                        <button className={"botonNoCI"} onClick={handleCancelClose}>No</button>
                    </div>

                </Modal>
            </div>
        </div>
    );


}

export {CrearItem}


