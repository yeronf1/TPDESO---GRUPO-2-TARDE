import React, { createContext, useState } from 'react';

// Crear el contexto
export const ClienteContext = createContext();

// Proveedor del contexto
export const ClienteProvider = ({ children }) => {
    const [ClienteSeleccionado, setClienteSeleccionado] = useState(null);

    return (
        <ClienteContext.Provider value={{ ClienteSeleccionado, setClienteSeleccionado }}>
            {children}
        </ClienteContext.Provider>
    );
};