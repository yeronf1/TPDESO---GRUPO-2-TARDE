import React, { useState } from 'react';
import '/src/Pages/Vendedor/CrearVendedor.css';
import {useNavigate} from "react-router-dom";
import {Header} from "../../Componentes/Header/Header.jsx";
import Modal from "react-modal";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faQuestionCircle} from "@fortawesome/free-regular-svg-icons";

function CrearVendedor() {

    const navigate = useNavigate();
    const [error, setError] = useState(null);
    const [isOpen, setIsOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);

    // Variables del FORM

    const [nombre, setNombre] = useState("");
    const [direccion, setDireccion] = useState("");


    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('http://localhost:8080/vendedor/registrar', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    nombre: nombre,
                    direccion: direccion,
                })
            });

            const data = await response.json(); // Lee la respuesta como JSON.

            if (!response.ok) {
                setError(data.message || 'Hubo un problema al comunicarse con el servidor');
                return;
            }

            setError(null);
            setSuccessMessage(data.message);
            setIsOpen(true); // Abre el modal.

            setTimeout(() => {
                setSuccessMessage('');
                setIsOpen(false);
                navigate("/BuscarVendedor")
            }, 3000);

        } catch (error) {
            console.error("Error al verificar el Vendedor:", error);
            setError('Error de conexión con el servidor');
        }
    };


    const handleCancelClick = () => {
        setIsConfirmOpen(true); // Abre el modal de confirmación.
    };

    const handleConfirmCancel = () => {
        setIsConfirmOpen(false);
        navigate('/BuscarVendedor'); // Redirige a la Busqueda de Vendedores.
    };

    const handleCancelClose = () => {
        setIsConfirmOpen(false); // Cierra el modal de confirmación.
    };

    const handleCloseModal = () => {
        setIsOpen(false);
    };


    return (
        <div className="padreCV">
            <Header />

            <div className="tarjetaTituloCV">
                <h2>CREAR VENDEDOR</h2>
            </div>

            <div className='contenedorFormularioCV'>

                <form className={"formRegBedelCV"} onSubmit={handleSubmit}>

                    <div className="formularioCV">

                        <div className="hijoFormCV">
                            <div className={'fila1CV'}>

                                <div className="contenedorInputCV">
                                    <input
                                        className="inputFieldCV"
                                        type="text"
                                        placeholder='Nombre'
                                        value={nombre}
                                        onChange={(e) => setNombre(e.target.value)}
                                    />
                                </div>

                                <div className="contenedorInputCV">
                                    <input
                                        className="inputFieldCV"
                                        type="text"
                                        placeholder='Direccion'
                                        value={direccion}
                                        onChange={(e) => setDireccion(e.target.value)}
                                    />
                                </div>

                            </div>

                        </div>

                        <div className='MensajeErrorCV'>
                            {error && (
                                <div style={{color: '#E01414', display: 'flex', alignItems: 'center'}}>
                                    <FontAwesomeIcon icon={faQuestionCircle}
                                                     style={{color: '#E01414', marginRight: '8px'}}/>
                                    <h3>{error}</h3>
                                </div>
                            )}
                        </div>

                    </div>

                    <div className='btnFormCV'>
                        <button className="cancelarCV" type='button' onClick={handleCancelClick}>Cancelar</button>
                        <button className="guardarCV" type='submit'>Guardar</button>
                    </div>

                </form>

                {/* Modal de éxito */}
                <Modal isOpen={isOpen}
                       onRequestClose={handleCloseModal}
                       ariaHideApp={false}
                       overlayClassName="modal-overlayCV"
                       className="modal-contentCV"
                >
                    <p className={"successMessage"}>{successMessage}</p>

                </Modal>

                {/* Modal de confirmación de cancelación */}
                <Modal isOpen={isConfirmOpen}
                       onRequestClose={handleCancelClose}
                       ariaHideApp={false}
                       overlayClassName="modal-overlayCV"
                       className="modal-contentCV"
                >

                    <p>¿Seguro de que deseas cancelar?</p>

                    <div className={"btnCancelarCV"}>
                        <button className={"botonSiCV"} onClick={handleConfirmCancel}>Sí</button>
                        <button className={"botonNoCV"} onClick={handleCancelClose}>No</button>
                    </div>

                </Modal>
            </div>
        </div>
    );
}

export {CrearVendedor}