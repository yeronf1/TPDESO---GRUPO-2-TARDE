import React, { createContext, useState } from 'react';

// Crear el contexto
export const PedidoContext = createContext();

// Proveedor del contexto
export const PedidoProvider = ({ children }) => {
    const [PedidoSeleccionado, setPedidoSeleccionado] = useState(null);

    return (
        <PedidoContext.Provider value={{ PedidoSeleccionado, setPedidoSeleccionado }}>
            {children}
        </PedidoContext.Provider>
    );
};