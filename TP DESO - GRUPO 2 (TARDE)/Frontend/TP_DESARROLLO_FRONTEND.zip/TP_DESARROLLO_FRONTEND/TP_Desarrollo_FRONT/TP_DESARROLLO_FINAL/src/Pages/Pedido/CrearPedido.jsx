import React, { useContext, useEffect, useState } from 'react';
import '/src/Pages/Pedido/CrearPedido.css';
import { useNavigate } from "react-router-dom";
import { VendedorContext } from "../Contexts/VendedorContext.jsx";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faQuestionCircle } from "@fortawesome/free-regular-svg-icons";
import { Header } from "../../Componentes/Header/Header.jsx";
import Modal from "react-modal";

function CrearPedido() {
    const navigate = useNavigate();
    const [error, setError] = useState(null);
    const [isOpen, setIsOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [formaPago, setFormaPago] = useState('');
    const [alias, setAlias] = useState('');
    const [CBU, setCBU] = useState('');
    const [CUIT, setCUIT] = useState('');
    let cant;

    // Variables de Items
    const [itemsSeleccionados, setItemsSeleccionados] = useState([]);

    // Variables del Vendedor
    const { VendedorSeleccionado } = useContext(VendedorContext);

    useEffect(() => {
        if (!VendedorSeleccionado) {
            navigate('/BuscarVendedor');
        }
    }, [VendedorSeleccionado, navigate]);

    if (!VendedorSeleccionado) {
        return null; // Mostrar nada mientras se redirige
    }

    const [idVendedor, setIdVendedor] = useState(VendedorSeleccionado.id_vendedor);
    const [itemsVendedor, setItemsVendedor] = useState([]);

    // Variables del cliente
    const [listaClientes, setListaClientes] = useState([]);
    const [cliente, setCliente] = useState('');

    // MANEJAR LA SELECCIÓN DE ITEMS
    const handleSeleccionItem = (idItem) => {
        setItemsSeleccionados((prev) => {
            const existe = prev.some((item) => item.idItemMenu === idItem);

            if (existe) {
                // Si ya existe, lo eliminamos
                return prev.filter((item) => item.idItemMenu !== idItem);
            } else {
                // Si no existe, lo agregamos con cantidad inicial 1
                return [...prev, { idItemMenu: idItem, cantidad: 1}];
            }
        });
    };

    const handleCambioCant = (idItem, cantidad) => {
        setItemsSeleccionados((prev) =>
            prev.map((item) =>
                item.idItemMenu === idItem ? { ...item, cantidad } : item
            )
        );
    };


    const handleCantidadItem = (item, e) => {
        // Le cambia la cantidad del item de la lista de items (no los seleccionados)
        item.cantidad = e.target.value;
    };


    console.log(cliente);
    // Enviar el PEDIDO creado al back
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('http://localhost:8080/pedido/registrar', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    idCliente: cliente,
                    detalle: itemsSeleccionados,
                    formaPago: formaPago,
                    cuit: CUIT,
                    cbu: CBU,
                    alias: alias,
                })

            });

            const data = await response.json();

            if (!response.ok) {
                setError(data.message || 'Hubo un problema al comunicarse con el servidor');
                return;
            }

            setError(null);
            setSuccessMessage(data.message);
            setIsOpen(true);

            setTimeout(() => {
                setSuccessMessage('');
                setIsOpen(false);
                navigate("/BuscarPedido");
            }, 3000);

        } catch (error) {
            console.error("Error al verificar el Vendedor:", error);
            setError('Error de conexión con el servidor');
        }
    };

    // FETCH PARA TRAER LOS ITEMS ASOCIADOS AL VENDEDOR
    const fetchItemsVendedor = async () => {
        setIsLoading(true);
        setError(null);

        try {
            const response = await fetch('http://localhost:8080/item_menu/verMenu', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ idVendedor: idVendedor })
            });

            if (!response.ok) throw new Error("Error al obtener los Items");

            const data = await response.json();

            if (data.data && Array.isArray(data.data)) {
                setItemsVendedor(data.data);
            } else {
                setItemsVendedor([]);
            }
        } catch (err) {
            console.error(err);
            setError("No se pudieron cargar los datos.");
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchItemsVendedor();
    }, [idVendedor]);

    // FETCH PARA TRAER CLIENTES
    const fetchListaClientes = async () => {
        try {
            const response = await fetch('http://localhost:8080/cliente/obtenerClientes', {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' },
            });

            if (!response.ok) throw new Error("Error al cargar los clientes");

            const data = await response.json();
            setListaClientes(data.data);

        } catch (err) {
            console.error("Error:", err);
        }
    };

    useEffect(() => {
        fetchListaClientes();
    }, []);

    const handleCancelClick = () => {
        setIsConfirmOpen(true);
    };

    const handleConfirmCancel = () => {
        setIsConfirmOpen(false);
        navigate('/BuscarVendedor');
    };

    const handleCancelClose = () => {
        setIsConfirmOpen(false);
    };

    const handleCloseModal = () => {
        setIsOpen(false);
    };

    return (
        <div className="padreCP">
            <Header />

            <div className="tarjetaTituloCP">
                <h2>CREAR PEDIDO</h2>
            </div>

            <div className="contenedorFormularioCP">
                <form className="formRegBedelCP" onSubmit={handleSubmit}>
                    <div className="formularioCP">
                        <div className="hijoFormCP">

                            <div className="fila2CP">
                                <div className="contenedorInputCP">
                                    <select
                                        className="inputFieldCP"
                                        value={cliente}
                                        onChange={(e) => setCliente(e.target.value)}
                                    >
                                        <option value="">Seleccionar Cliente</option>
                                        {listaClientes.map((c) => (
                                            <option key={c.id_cliente} value={c.id_cliente}>
                                                {c.nombre}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                <div className="contenedorInputCP">
                                    <select
                                        className="inputFieldCP"
                                        value={formaPago}
                                        onChange={(e) => setFormaPago(e.target.value)}
                                    >
                                        <option value="">Seleccionar método de Pago</option>
                                        <option value="MERCADO_PAGO">Mercado Pago</option>
                                        <option value="TRANSFERENCIA">Transferencia</option>
                                    </select>
                                </div>

                                {(formaPago === 'MERCADO_PAGO') && (
                                    <div className={'fila2CP'}>
                                        <div className="contenedorInputCP">
                                            <input
                                                className="inputFieldCP"
                                                type="text"
                                                placeholder='Alias'
                                                value={alias}
                                                onChange={(e) => setAlias(e.target.value)}
                                            />
                                        </div>
                                        <div className={'contenedorInputCP'}>

                                        </div>
                                    </div>
                                )}
                                {(formaPago === 'TRANSFERENCIA') && (
                                    <div className={'fila1CP'}>
                                        <div className="contenedorInputCP">
                                            <input
                                                className="inputFieldCP"
                                                type="text"
                                                placeholder='CBU'
                                                value={CBU}
                                                onChange={(e) => setCBU(e.target.value)}
                                            />
                                        </div>
                                        <div className="contenedorInputCP">
                                            <input
                                                className="inputFieldCP"
                                                type="text"
                                                placeholder='CUIT'
                                                value={CUIT}
                                                onChange={(e) => setCUIT(e.target.value)}
                                            />
                                        </div>
                                    </div>
                                )}

                            </div>

                            <div className="fila1CP">
                                <table>
                                    <thead>
                                    <tr className={"nombreColumnas"}>
                                        <th>ID Item</th>
                                        <th>Nombre</th>
                                        <th>Precio</th>
                                        <th>Estado</th>
                                        <th>Cantidad</th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    {itemsVendedor.length > 0 ? (
                                        itemsVendedor.map((item) => {
                                            const seleccionado = itemsSeleccionados.some(
                                                (selected) => selected.idItemMenu === item.id_item_menu
                                            );

                                            return (
                                                <tr key={item.id}>
                                                    <td>{item.id_item_menu}</td>
                                                    <td>{item.nombre}</td>
                                                    <td>{item.precio}</td>
                                                    <td className="tdButtons">

                                                        <button
                                                            type="button"
                                                            className={seleccionado ? "eliminarItemCP" : "agregarItemCP"}
                                                            onClick={() => handleSeleccionItem(item.id_item_menu)}
                                                            style={{
                                                                backgroundColor: seleccionado ? "#F0F2F9" : "#2169AC"
                                                            }}
                                                        >
                                                            {seleccionado ? "Eliminar" : "Agregar"}
                                                        </button>
                                                    </td>

                                                    <td>
                                                        <div className={"contenedorInputTablaCP"}>
                                                            <input
                                                                className={"inputCantidadCP"}
                                                                type="text"
                                                                disabled={!seleccionado}
                                                                value={
                                                                    seleccionado
                                                                        ? (itemsSeleccionados.find((i) => i.idItemMenu === item.id_item_menu)?.cantidad || '')
                                                                        : ''
                                                                }
                                                                onChange={(e) => handleCambioCant(item.id_item_menu, parseInt(e.target.value, 10) || 0)}
                                                            />
                                                        </div>
                                                    </td>
                                                </tr>
                                            );
                                        })
                                    ) : (
                                        <tr>
                                            <td colSpan="5" style={{textAlign: "center"}}>No hay resultados para la
                                                búsqueda
                                            </td>
                                        </tr>
                                    )}
                                    </tbody>
                                </table>
                            </div>


                        </div>

                        <div className="MensajeErrorCP">
                            {error && (
                                <div style={{color: '#E01414', display: 'flex', alignItems: 'center'}}>
                                    <FontAwesomeIcon icon={faQuestionCircle}
                                                     style={{color: '#E01414', marginRight: '8px'}}/>
                                    <h3>{error}</h3>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="btnFormCP">
                        <button className="cancelarCP" type="button" onClick={handleCancelClick}>Cancelar</button>
                        <button className="guardarCP" type="submit">Guardar</button>
                    </div>
                </form>

                {/* Modal de éxito */}
                <Modal
                    isOpen={isOpen}
                    onRequestClose={handleCloseModal}
                    ariaHideApp={false}
                    overlayClassName="modal-overlay"
                    className="modal-content"
                >
                    <p className="successMessage">{successMessage}</p>
                </Modal>

                {/* Modal de confirmación de cancelación */}
                <Modal
                    isOpen={isConfirmOpen}
                    onRequestClose={handleCancelClose}
                    ariaHideApp={false}
                    overlayClassName="modal-overlayCP"
                    className="modal-contentCP"
                >
                    <p>¿Seguro de que deseas cancelar?</p>

                    <div className="btnCancelarCP">
                        <button className="botonSiCP" onClick={handleConfirmCancel}>Sí</button>
                        <button className="botonNoCP" onClick={handleCancelClose}>No</button>
                    </div>
                </Modal>
            </div>
        </div>
    );
}

export { CrearPedido };
