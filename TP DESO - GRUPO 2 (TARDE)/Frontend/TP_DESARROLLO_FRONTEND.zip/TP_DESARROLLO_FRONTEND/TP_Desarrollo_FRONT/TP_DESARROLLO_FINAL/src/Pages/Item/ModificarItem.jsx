import React, {useContext, useEffect, useState} from 'react';
import '/src/Pages/Item/ModificarItem.css';
import { useNavigate } from 'react-router-dom';
import {ItemContext} from "../Contexts/ItemContext.jsx";
import {Header} from "../../Componentes/Header/Header.jsx";
import Modal from "react-modal";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faQuestionCircle} from "@fortawesome/free-regular-svg-icons";


function ModificarItem() {
    const navigate = useNavigate();
    const [error, setError] = useState(null);
    const [isOpen, setIsOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const {ItemSeleccionado} = useContext(ItemContext);
    const [isChecked, setIsChecked] = useState(false);

    // Variables del FORM

    useEffect(() => {
        if (!ItemSeleccionado) {
            navigate('/BuscarItem');
        }
    }, [ItemSeleccionado, navigate]);

    if (!ItemSeleccionado) {
        return null; // Mostrar nada mientras se redirige
    }

    const [nombre, setNombre] = useState(ItemSeleccionado.nombre);
    const [categoria, setCategoria] = useState(ItemSeleccionado.id_categoria);
    const [descripcion, setDescripcion] = useState(ItemSeleccionado.descripcion);
    const [precio, setPrecio] = useState(ItemSeleccionado.precio);
    const [calorias, setCalorias] = useState(ItemSeleccionado.calorias);
    const [peso, setPeso] = useState(ItemSeleccionado.peso);
    const [aptoVegetariano, setAptoVegetariano] = useState(ItemSeleccionado.aptoVegetariano);
    const [aptoCeliaco, setAptoCeliaco] = useState(ItemSeleccionado.aptoCeliaco);
    const [gradAlcoholica, setGradAlcoholica] = useState(ItemSeleccionado.graduacionAlcoholica);
    const [volumen, setVolumen] = useState(ItemSeleccionado.volumen);
    const [esGaseosa, setEsGaseosa] = useState(ItemSeleccionado.es_gaseosa);


    console.log(`nombre ${nombre}`);
    console.log(`descripcion ${descripcion}`);
    console.log(`categoria ${categoria}`);
    console.log(`precio ${precio}`);
    console.log(`calorias ${calorias}`);
    console.log(`peso ${peso}`);
    console.log(`apto_vegetariano ${aptoVegetariano}`);
    console.log(`apto_celiaco ${aptoVegetariano}`);
    console.log(`graduacion_alcoholica ${gradAlcoholica}`);
    console.log(`volumen ${volumen}`);
    console.log(` es_gaseosa ${esGaseosa}`);
    console.log(`id_categoria ${ItemSeleccionado.categoria}`);
    console.log(`id_vendedor ${ItemSeleccionado.id_vendedor}`);

console.log(ItemSeleccionado);

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('http://localhost:8080/item_menu/modificar', {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    id_item_menu: ItemSeleccionado.id_item_menu,
                    nombre: nombre,
                    descripcion: descripcion,
                    tipo_item_menu: ItemSeleccionado.tipo_item_menu,
                    precio: precio,
                    calorias: calorias,
                    peso: peso,
                    aptoVegetariano: aptoVegetariano,
                    aptoCeliaco: aptoCeliaco,
                    graduacionAlcoholica: gradAlcoholica,
                    volumen: volumen,
                    es_gaseosa: esGaseosa,
                    id_categoria: ItemSeleccionado.categoria,
                    id_vendedor: ItemSeleccionado.id_vendedor,
                }),
            });



            const data = await response.json();

            if (!response.ok) {
                setError(data.message || 'Hubo un problema al comunicarse con el servidor');
                return;
            }

            setError(null);
            setSuccessMessage(data.message);
            setIsOpen(true);

            setTimeout(() => {
                setSuccessMessage('');
                setIsOpen(false);
                navigate("/BuscarItem");
            }, 3000);
        } catch (error) {
            console.error("Error al verificar el Item:", error);
            setError('Error de conexión con el servidor');
        }
    };

    //Manejo de ventanas

    const handleCancelClick = () => {
        setIsConfirmOpen(true);
    };

    const handleConfirmCancel = () => {
        setIsConfirmOpen(false);
        navigate('/BuscarItem'); // Redirige a la Busqueda de Items.
    };

    const handleCancelClose = () => {
        setIsConfirmOpen(false);
    };

    const handleCloseModal = () => {
        setIsOpen(false);
    }


    return (
        <div className="padreMI">
            <Header />

            <div className="tarjetaTituloMI">
                <h2>MODIFICAR ITEM</h2>
            </div>

            <div className='contenedorFormularioMI'>

                <form className={"formRegBedelMI"} onSubmit={handleSubmit}>

                    <div className="formularioMI">

                        <div className={"tituloIdMI"}>
                            <h3>
                                {ItemSeleccionado.nombre}{" - ID "}{ItemSeleccionado.id_item_menu}
                            </h3>
                            <div className="line"></div>
                        </div>

                        <div className="hijoFormMI">
                            <div className={'fila1MI'}>

                                <div className="contenedorInputMI">
                                    <input
                                        className="inputFieldMI"
                                        type="text"
                                        placeholder='Nombre'
                                        value={nombre}
                                        onChange={(e) => setNombre(e.target.value)}
                                    />
                                </div>

                                <div className="contenedorInputMI">
                                    <input
                                        className="inputFieldMI"
                                        type="text"
                                        placeholder='Descripcion'
                                        value={descripcion}
                                        onChange={(e) => setDescripcion(e.target.value)}
                                    />
                                </div>

                                <div className="contenedorInputMI">
                                    <input
                                        className="inputFieldMI"
                                        type="text"
                                        placeholder='Precio'
                                        value={precio}
                                        onChange={(e) => setPrecio(e.target.value)}
                                    />
                                </div>

                            </div>

                            {(ItemSeleccionado.tipo_item_menu === "COMIDA") && (
                                <div className={"fila1MI"}>
                                    <div className={'fila2MI'}>

                                        <div className="contenedorInputMI">
                                            <input
                                                className="inputFieldMI"
                                                type="text"
                                                placeholder='Calorias'
                                                value={calorias}
                                                onChange={(e) => setCalorias(e.target.value)}
                                            />
                                        </div>

                                        <div className="contenedorInputMI">
                                            <input
                                                className="inputFieldMI"
                                                type="text"
                                                placeholder='Peso'
                                                value={peso}
                                                onChange={(e) => setPeso(e.target.value)}
                                            />
                                        </div>

                                        <div className="contenedorInputMI">
                                            <label className={"inputFieldMI"}>
                                                <input
                                                    type="checkbox"
                                                    checked={aptoVegetariano} // Controla si está seleccionado
                                                    onChange={() => setAptoVegetariano(!aptoVegetariano)} // Maneja el cambio
                                                />
                                                Apto Veg.
                                            </label>
                                        </div>

                                        <div className="contenedorInputMI">
                                            <label className={"inputFieldMI"}>
                                                <input
                                                    type="checkbox"
                                                    checked={aptoCeliaco} // Controla si está seleccionado
                                                    onChange={() => setAptoCeliaco(!aptoCeliaco)} // Maneja el cambio
                                                />
                                                Apto Celiaco
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {(ItemSeleccionado.tipo_item_menu === "BEBIDA") && (
                                <div className={"fila1MI"}>
                                    <div className={'fila2MI'}>

                                        <div className="contenedorInputMI">
                                            <input
                                                className="inputFieldMI"
                                                type="text"
                                                placeholder='Graduación Alcohólica (%)'
                                                value={gradAlcoholica}
                                                onChange={(e) => setGradAlcoholica(e.target.value)}
                                            />
                                        </div>

                                        <div className="contenedorInputMI">
                                            <input
                                                className="inputFieldMI"
                                                type="text"
                                                placeholder='Volumen'
                                                value={volumen}
                                                onChange={(e) => setVolumen(e.target.value)}
                                            />
                                        </div>

                                        <div className="contenedorInputMI">
                                            <label>
                                                <input
                                                    type="checkbox"
                                                    checked={esGaseosa} // Controla si está seleccionado
                                                    onChange={() => setEsGaseosa(!esGaseosa)} // Maneja el cambio
                                                />
                                                Es Gaseosa
                                            </label>
                                        </div>

                                    </div>
                                </div>
                            )}


                        </div>

                        <div className='MensajeErrorMI'>
                            {error && (
                                <div style={{color: '#E01414', display: 'flex', alignItems: 'center'}}>
                                    <FontAwesomeIcon icon={faQuestionCircle}
                                                     style={{color: '#E01414', marginRight: '8px'}}/>
                                    <h3>{error}</h3>
                                </div>
                            )}
                        </div>

                    </div>

                    <div className='btnFormMI'>
                        <button className="cancelarMI" type='button' onClick={handleCancelClick}>Cancelar</button>
                        <button className="guardarMI" type='submit'>Guardar</button>
                    </div>

                </form>

                {/* Modal de éxito */}
                <Modal isOpen={isOpen}
                       onRequestClose={handleCloseModal}
                       ariaHideApp={false}
                       overlayClassName="modal-overlayMI"
                       className="modal-contentMI"
                >
                    <p className={"successMessage"}>{successMessage}</p>

                </Modal>

                {/* Modal de confirmación de cancelación */}
                <Modal isOpen={isConfirmOpen}
                       onRequestClose={handleCancelClose}
                       ariaHideApp={false}
                       overlayClassName="modal-overlayMI"
                       className="modal-contentMI"
                >

                    <p>¿Seguro de que deseas cancelar?</p>

                    <div className={"btnCancelarMI"}>
                        <button className={"botonSiMI"} onClick={handleConfirmCancel}>Sí</button>
                        <button className={"botonNoMI"} onClick={handleCancelClose}>No</button>
                    </div>

                </Modal>
            </div>
        </div>
    );
}

export {ModificarItem}