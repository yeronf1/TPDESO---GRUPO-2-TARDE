import React, {useContext, useEffect, useState} from 'react';
import '/src/Pages/Pedido/ModificarPedido.css';
import {PedidoContext} from "../Contexts/PedidoContext.jsx";
import {useNavigate} from "react-router-dom";
import {Header} from "../../Componentes/Header/Header.jsx";
import Modal from "react-modal";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";


// VER DETALLE
function ModificarPedido() {
    const navigate = useNavigate();
    const [error, setError] = useState(null);
    const [isOpen, setIsOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    // Variables del Vendedor

    const {PedidoSeleccionado} = useContext(PedidoContext);

    useEffect(() => {
        if (!PedidoSeleccionado) {
            navigate('/BuscarPedido');
        }
    }, [PedidoSeleccionado, navigate]);

    if (!PedidoSeleccionado) {
        return null; // Mostrar nada mientras se redirige
    }

    //const [detalle, setDetalle] = useState(PedidoSeleccionado?.detalle || []);
    const [idPedido, setIdPedido] = useState(PedidoSeleccionado);
    const [itemsMenu, setItemMenu] = useState([]);

    console.log(PedidoSeleccionado);


    const fetchTraerPedidoEntero = async () => {
        console.log(PedidoSeleccionado);
        try {
            const response = await fetch('http://localhost:8080/pedido/verDetalle', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    idPedido: idPedido
                })
            });

            if (!response.ok) throw new Error("Error al cargar los vendedores");

            const data = await response.json();

            console.log("Datos de vendedores:", data);
            setItemMenu(data.data);

        } catch (err) {
            console.error("Error:", err);
        }
    };

    useEffect(() => {  // PARA ENCONTRAR TODOS LOS VENDEDORES
        fetchTraerPedidoEntero();
    }, []);


    // Variables de Items

    const [isChecked, setIsChecked] = useState(false);
    const [itemsSeleccionados, setItemsSeleccionados] = useState(PedidoSeleccionado.detalle)

    const [itemsPedido, setIitemsPedido] = useState([PedidoSeleccionado.detalle])

    // Enviar el PEDIDO creado al back

    const handleCancelClick = () => {
        setIsConfirmOpen(true); // Abre el modal de confirmación.
    };

    const handleConfirmCancel = () => {
        setIsConfirmOpen(false);
        navigate('/BuscarPedido'); // Redirige a la Busqueda de Vendedores.
    };

    const handleCancelClose = () => {
        setIsConfirmOpen(false); // Cierra el modal de confirmación.
    };

    const handleCloseModal = () => {
        setIsOpen(false);
    };


    return (
        <div className="padreMP">
            <Header />

            <div className="tarjetaTituloMP">
                <h2>DETALLE PEDIDO</h2>
            </div>

            <div className='contenedorFormularioMP'>

                <div className={"formRegMP"}>

                    <div className="formularioMP">

                        <div className={"tituloIdMP"}>
                            <h3>
                                {"Detalle del pedido - ID: "}{PedidoSeleccionado}
                            </h3>
                            <div className="line"></div>
                        </div>

                        <div className="hijoFormMP">
                            <div className={'fila1MP'}>

                                <table>
                                    <thead>
                                    <tr className={"nombreColumnas"}>
                                        <th>ID Item</th>
                                        <th>Nombre</th>
                                        <th>Precio Unitario</th>
                                        <th>Cantidad</th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    {itemsMenu.length > 0 ? (
                                        itemsMenu.map((item) => {
                                            return (
                                                <tr key={item.id}>
                                                    <td>{item.idItemMenu}</td>
                                                    <td>{item.nombre}</td>
                                                    <td>{item.precio}</td>
                                                    <td>{item.cantidad}</td>
                                                </tr>
                                            );
                                        })
                                    ) : (
                                        <tr>
                                            <td colSpan="5" style={{textAlign: "center"}}>No hay resultados para la búsqueda </td>
                                        </tr>
                                    )}
                                    </tbody>
                                </table>

                            </div>
                        </div>

                        <div className='MensajeErrorMP'>
                            {error && (
                                <div style={{color: '#E01414', display: 'flex', alignItems: 'center'}}>
                                    <FontAwesomeIcon icon={faQuestionCircle}
                                                     style={{color: '#E01414', marginRight: '8px'}}/>
                                    <h3>{error}</h3>
                                </div>
                            )}
                        </div>

                    </div>

                    <div className='btnFormMP'>
                        <button className="cancelarMP" type='button' onClick={handleCancelClick}>Cancelar</button>
                    </div>

                </div>

                {/* Modal de éxito */}
                <Modal isOpen={isOpen}
                       onRequestClose={handleCloseModal}
                       ariaHideApp={false}
                       overlayClassName="modal-overlay"
                       className="modal-content"
                >
                    <p className={"successMessage"}>{successMessage}</p>

                </Modal>

                {/* Modal de confirmación de cancelación */}
                <Modal isOpen={isConfirmOpen}
                       onRequestClose={handleCancelClose}
                       ariaHideApp={false}
                       overlayClassName="modal-overlayRB"
                       className="modal-contentRB"
                >

                    <p>¿Seguro de que deseas cancelar?</p>

                    <div className={"btnCancelarMP"}>
                        <button className={"botonSiMP"} onClick={handleConfirmCancel}>Sí</button>
                        <button className={"botonNoMP"} onClick={handleCancelClose}>No</button>
                    </div>

                </Modal>
            </div>
        </div>
    );
}

export {ModificarPedido}