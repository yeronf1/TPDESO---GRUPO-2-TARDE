
import React from 'react';
import './HeaderInicio.css'

const HeaderInicio = () => {
    return(

        <div className='padreHeaderInicio'>
            <div className='headerInicio'>
            </div>

            <div className="barra">
                <img src="/assets/Frame.png" alt="Barra" className="img"/>
            </div>
        </div>

    )
}

export {HeaderInicio}