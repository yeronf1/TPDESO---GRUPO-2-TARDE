import React from "react";
import { NavLink } from "react-router-dom";
import './NavBar.css';


const NavBar = () => {
    return (
        <nav className="NavContainer">
            <ul>
                <li>
                    <NavLink to='/'>Inicio</NavLink>
                </li>
                <li>
                    <NavLink to='/BuscarVendedor'>Vendedores</NavLink>
                </li>
                <li>
                    <NavLink to='/BuscarCliente'>Clientes</NavLink>
                </li>
                <li>
                    <NavLink to='/BuscarItem'>Ítems Menu</NavLink>
                </li>
                <li>
                    <NavLink to='/BuscarPedido'>Pedidos</NavLink>
                </li>
            </ul>
        </nav>
    );
};

export {NavBar};