import React from 'react';
import { NavBar } from '../NavBar/NavBar.jsx';
import './Header.css'



const Header = () => {
    return(

        <div className='padreHeader'>
            <div className='header'>
                <NavBar/>
            </div>

            <div className="barra">
                <img src="/assets/Frame.png" alt="Barra" className="img"/>
            </div>
        </div>

    )
}

export {Header}