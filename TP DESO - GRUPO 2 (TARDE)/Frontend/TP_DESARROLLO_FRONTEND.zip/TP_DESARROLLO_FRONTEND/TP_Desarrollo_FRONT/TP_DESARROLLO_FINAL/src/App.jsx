import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';

import { Inicio } from "./Pages/Inicio/Inicio.jsx";
import { ModificarVendedor } from "./Pages/Vendedor/ModificarVendedor.jsx";
import { CrearVendedor } from "./Pages/Vendedor/CrearVendedor.jsx";
import { BuscarVendedor } from "./Pages/Vendedor/BuscarVendedor.jsx";
import { ModificarPedido } from "./Pages/Pedido/ModificarPedido.jsx";
import { CrearPedido } from "./Pages/Pedido/CrearPedido.jsx";
import { BuscarPedido } from "./Pages/Pedido/BuscarPedido.jsx";
import { ModificarItem } from "./Pages/Item/ModificarItem.jsx";
import { CrearItem } from "./Pages/Item/CrearItem.jsx";
import { BuscarItem } from "./Pages/Item/BuscarItem.jsx";
import { ModificarCliente } from "./Pages/Cliente/ModificarCliente.jsx";
import { CrearCliente } from "./Pages/Cliente/CrearCliente.jsx";
import { BuscarCliente } from "./Pages/Cliente/BuscarCliente.jsx";

import { VendedorProvider } from './Pages/Contexts/VendedorContext.jsx';
import { PedidoProvider } from './Pages/Contexts/PedidoContext.jsx';
import { ItemProvider } from './Pages/Contexts/ItemContext.jsx';
import { ClienteProvider } from './Pages/Contexts/ClienteContext.jsx';

function App() {
    return (

        <BrowserRouter>
            <ItemProvider>
            <ClienteProvider>
            <PedidoProvider>
            {/* Envuelve las rutas de vendedores en el contexto */}
            <VendedorProvider>

                <Routes>

                    <Route path="/" element={<Inicio />} />

                    <Route path="/ModificarVendedor" element={<ModificarVendedor />} />
                    <Route path="/CrearVendedor" element={<CrearVendedor />} />
                    <Route path="/BuscarVendedor" element={<BuscarVendedor />} />

                    <Route path="/ModificarPedido" element={<ModificarPedido />} />
                    <Route path="/CrearPedido" element={<CrearPedido />} />
                    <Route path="/BuscarPedido" element={<BuscarPedido />} />

                    <Route path="/ModificarItem" element={<ModificarItem />} />
                    <Route path="/CrearItem" element={<CrearItem />} />
                    <Route path="/BuscarItem" element={<BuscarItem />} />

                    <Route path="/ModificarCliente" element={<ModificarCliente />} />
                    <Route path="/CrearCliente" element={<CrearCliente />} />
                    <Route path="/BuscarCliente" element={<BuscarCliente />} />
                </Routes>

            </VendedorProvider>
            </PedidoProvider>
            </ClienteProvider>
            </ItemProvider>
        </BrowserRouter>
    );
}

export default App;
